package com.podevs.android.pokeman.pokeinfo;

import android.util.SparseArray;

import androidx.annotation.NonNull;

import com.aggrx.scaffold.AggrxMaps;
import com.podevs.android.pokeman.pokeinfo.InfoFiller.FillerByte;

import java.util.ArrayList;
import java.util.Arrays;

public class MoveInfo extends GenInfo {
    static boolean effectsloaded = false;
    static boolean zeffectsloaded = false;
    static boolean pploaded = false;
    static boolean accuracyloaded = false;
    static boolean powerloaded = false;
    static boolean zpowerloaded = false;
    static boolean typeloaded = false;
    // private static int thisSubGen = 6;
    static boolean damageClassloaded = false;
    static boolean targetsloaded = false;
    static boolean flagsloaded = false;
    static boolean genmovelistloaded = false;
    private static ArrayList<Move> moveNames = null;
    private static SparseArray<String> moveMessages = null;
    private static Short[] allMoves = null;

    public static void newGen() {
        moveNames = null; // Because 0 will not overwrite, i.e. type Normal (0) will not overwrite already saved type Fairy (17).
        testLoad();
        pploaded = false;
        damageClassloaded = false;
        powerloaded = false;
        typeloaded = false;
        accuracyloaded = false;
        effectsloaded = false;
        targetsloaded = false;
        flagsloaded = false;
        genmovelistloaded = false;
    }

    private static void testLoad() {
        if (moveNames == null) {
            loadPokeMoves();
        }
    }

    private static void loadPokeMoves() {
        moveNames = new ArrayList<>();
        String path;
        path = PokemonStorage.getMovePath();
        InfoFiller.fill(path, (i, b, o) -> moveNames.add(new Move(b)));
    }

    public static void forceSetGen(int Gen, int SubGen) {
        testLoad();
        PokemonStorage.thisGen = Gen;
        //thisSubGen = SubGen;
    }

    public static String zName(int num, boolean zmove) {
        String ret = "";
        Move move = AggrxMaps.get(moveNames, (num), null);
        if (move == null) {
            return ret;
        }
        ret = move.name;

        if (zmove && num != 0 && (power(num) == 0 || num == 693 || num == 382)) { //Extreme Evoboost and Me First
            ret = "Z-" + ret;
        }

        return ret;
    }

    public static byte power(int num) {
        loadPokePowers();
        Move move = AggrxMaps.get(moveNames, (num), null);
        if (move == null) {
            return 0;
        }
        return move.power;
    }

    private static void loadPokePowers() {
        if (powerloaded) {
            return;
        }
        testLoad();
        powerloaded = true;
        String path = PokemonStorage.getGenpowerPath();
        InfoFiller.fill(path, new FillerByte() {
            @Override
            void fillByte(int i, byte b, String o) {
                Move move = AggrxMaps.get(moveNames, i, null);
                if (move != null) {
                    move.power = b;
                }
            }
        });
    }

    public static int indexOf(String s) {
        testLoad();
        for (int i = 0; i < moveNames.size(); i++) {
            Move move = AggrxMaps.get(moveNames, i, null);
            if (move != null && move.name.equals(s)) {
                return i;
            }
        }
        return 0;
    }

    public static byte damageClass(int num) {
        loadDamageClasses();
        Move move = AggrxMaps.get(moveNames, (num), null);
        if (move == null) {
            return 0;
        }
        return move.damageClass;
    }

    private static void loadDamageClasses() {
        if (damageClassloaded) {
            return;
        }
        testLoad();
        damageClassloaded = true;
        String path = PokemonStorage.getGendamage_classPath();
        InfoFiller.fill(path, new FillerByte() {
            @Override
            void fillByte(int i, byte b, String o) {
                Move move = AggrxMaps.get(moveNames, i, null);
                if (move != null) {
                    move.damageClass = b;
                }
            }
        });
    }

    public static byte type(int num) {
        loadPokeTypes();
        Move move = AggrxMaps.get(moveNames, (num), null);
        if (move == null) {
            return 0;
        }
        return move.type;
    }

    private static void loadPokeTypes() {
        if (typeloaded) {
            return;
        }
        testLoad();
        typeloaded = true;
        String path = PokemonStorage.getGenType();
        InfoFiller.fill(path, new FillerByte() {
            @Override
            void fillByte(int i, byte b, String o) {
                Move move = AggrxMaps.get(moveNames, i, null);
                if (move != null) {
                    move.type = b;
                }
            }
        });
    }

    public static byte pp(int num) {
        loadPokePPs();
        Move move = AggrxMaps.get(moveNames, (num), null);
        if (move == null) {
            return 0;
        }
        return move.pp;
    }

    private static void loadPokePPs() {
        if (pploaded) {
            return;
        }
        testLoad();
        pploaded = true;
        String path = getGenPp();
        InfoFiller.fill(path, new FillerByte() {
            @Override
            void fillByte(int i, byte b, String o) {
                Move move = AggrxMaps.get(moveNames, i, null);
                if (move != null) {
                    move.pp = b;
                }
            }
        });
    }

    @NonNull
    private static String getGenPp() {
        return "db/moves/" + PokemonStorage.thisGen + "G/pp.txt";
    }

    public static String accuracyString(int num) {
        return accuracyToString(accuracy(num));
    }

    public static byte accuracy(int num) {
        loadPokeAccuracies();
        Move move = AggrxMaps.get(moveNames, (num), null);
        if (move == null) {
            return 0;
        }
        return move.accuracy;
    }

    private static void loadPokeAccuracies() {
        if (accuracyloaded) {
            return;
        }
        testLoad();
        accuracyloaded = true;
        String path = PokemonStorage.getGenAccuracyPath();
        InfoFiller.fill(path, new FillerByte() {
            @Override
            void fillByte(int i, byte b, String o) {
                Move move = AggrxMaps.get(moveNames, i, null);
                if (move != null) {
                    move.accuracy = b;
                }
            }
        });
    }

    public static String accuracyToString(int acc) {
        if (acc == 101) {
            return "--";
        } else {
            return String.valueOf(acc);
        }
    }

    public static byte zPower(int num) {
        loadPokeZPowers();
        Move move = AggrxMaps.get(moveNames, (num), null);
        if (move == null) {
            return 0;
        }
        return move.zpower;
    }

    private static void loadPokeZPowers() {
        if (zpowerloaded) {
            return;
        }
        testLoad();
        zpowerloaded = true;
        String path = PokemonStorage.getGenZPowerPath();
        InfoFiller.fill(path, new FillerByte() {
            @Override
            void fillByte(int i, byte b, String o) {
                Move move = AggrxMaps.get(moveNames, i, null);
                if (move != null) {
                    move.zpower = b;
                }
            }
        });
    }

    public static String powerString(int num) {
        return powerToString(power(num));
    }

    public static String powerToString(int pow) {
        if (pow == 0) {
            return "--";
        } else if (pow == 1) {
            return "???";
        } else {
            return String.valueOf(pow >= 0 ? pow : (pow + 256));
        }
    }

    public static String effect(int num) {
        loadPokeEffects();

        String effect = "";
        Move move = AggrxMaps.get(moveNames, (num), null);
        if (move == null) {
            return effect;
        }
        effect = move.effect;
        return effect == null ? "" : effect;
    }

    private static void loadPokeEffects() {
        if (effectsloaded) {
            return;
        }
        testLoad();
        effectsloaded = true;
        String path;

        path = PokemonStorage.getGenEffectString();
        InfoFiller.fill(path, (i, s, o) -> {
            Move move = AggrxMaps.get(moveNames, i, null);
            if (move != null) {
                move.effect = s;
            }
        });
    }

    public static String zDescription(int num) {
        loadZEffects();

        String zeffect = "";
        Move move = AggrxMaps.get(moveNames, (num), null);
        if (move == null) {
            return zeffect;
        }
        zeffect = move.zeffect;
        return zeffect == null ? "" : zeffect;
    }

    private static void loadZEffects() {
        if (zeffectsloaded) {
            return;
        }
        testLoad();
        zeffectsloaded = true;
        String path = PokemonStorage.getGenzeffectPath();
        InfoFiller.fill(path, (i, s, o) -> {
            Move move = AggrxMaps.get(moveNames, i, null);
            if (move != null) {
                move.zeffect = s;
            }
        });
    }

    public static String targetString(int num) {
        return targetToString(target(num));
    }

    public static Target target(int num) {
        loadTargets();

        Move move = AggrxMaps.get(moveNames, (num), null);
        if (move == null) {
            return null;
        }
        return move.range;
    }

    private static void loadTargets() {
        if (targetsloaded) {
            return;
        }
        testLoad();
        targetsloaded = true;
        String path = PokemonStorage.getGenrangePath();
        InfoFiller.fill(path, new FillerByte() {
            @Override
            void fillByte(int i, byte b, String o) {
                Move move = AggrxMaps.get(moveNames, i, null);
                if (move != null) {
                    move.range = Target.values()[b];
                }
            }
        });
    }

    public static String targetToString(Target t) {
        switch (t) {
            case ChosenTarget:
            case MeFirstTarget:
                return "Single Target";
            case PartnerOrUser:
                return "Self or Ally";
            case Partner:
                return "Single Ally";
            case AllButSelf:
                return "All But Self";
            case Opponents:
                return "Adjacent Foes";
            case TeamParty:
                return "User's Team";
            case User:
            case IndeterminateTarget:
                return "Self";
            case All:
                return "All";
            case RandomTarget:
                return "Random";
            case Field:
                return "Field";
            case OpposingTeam:
                return "All Foes";
            case TeamSide:
                return "All Allies";
            default:
                return "---";
        }
    }

    public static int flags(int num) {
        loadFlags();

        Move move = AggrxMaps.get(moveNames, (num), null);
        if (move == null) {
            return 0;
        }
        return move.flags;
    }

    private static void loadFlags() {
        if (flagsloaded) {
            return;
        }
        testLoad();
        flagsloaded = true;
        String path = getGenflagsPath();
        InfoFiller.fill(path, new InfoFiller.FillerInt() {
            @Override
            void fillInt(int i, int b) {
                Move move = AggrxMaps.get(moveNames, i, null);
                if (move != null) {
                    move.flags = b;
                }
            }
        });
    }

    @NonNull
    private static String getGenflagsPath() {
        return "db/moves/" + PokemonStorage.thisGen + "G/flags.txt";
    }

    public static String message(int num, int part) {
        if (moveMessages == null) {
            loadMoveMessages();
        }

        String[] parts = moveMessages.get(num, "").split("\\|");
        try {
            return parts[part];
        } catch (ArrayIndexOutOfBoundsException ex) {
            return "";
        }
    }

    private static void loadMoveMessages() {
        moveMessages = new SparseArray<>();
        String path;
        path = PokemonStorage.getMoveMessagePath();
        InfoFiller.fill(path, (i, b, o) -> moveMessages.put(i, b));
    }

    private static void loadPokePowers(String path) {
        InfoFiller.fill(path, new FillerByte() {
            @Override
            void fillByte(int i, byte b, String o) {
                Move move = AggrxMaps.get(moveNames, i, null);
                if (move != null) {
                    move.power = b;
                }
            }
        });
    }

    public static Short[] getAllMoves() {
        if (!genmovelistloaded) {
            testLoad();
            fillAllMoves();
        }
        return allMoves;
    }

    private static void fillAllMoves() {
        if (genmovelistloaded) {
            return;
        }
        allMoves = new Short[moveNames.size()];

        for (int i = 0; i <= allMoves.length - 1; i++) {
            allMoves[i] = (short) 0;
        }

        InfoFiller.plainFill(PokemonStorage.getGenMovesPath(), (i, s, o) -> {
            if (i >= 0 && i < allMoves.length) {
                allMoves[i] = (short) i;
            }
        });

        allMoves = trim(allMoves);

        java.util.Arrays.sort(allMoves, (lhs, rhs) -> name(lhs).compareToIgnoreCase(name(rhs)));

        genmovelistloaded = true;
    }

    public static String name(int num) {
        Move move = AggrxMaps.get(moveNames, num, null);
        if (move != null) {
            return move.name;
        }
        return "";
    }

    private static Short[] trim(Short[] shorts) {
        int i = shorts.length - 1;
        while (i >= 0 && shorts[i] == 0) {
            --i;
        }

        return Arrays.copyOf(shorts, i + 1);
    }

    public static ArrayList<String> makeList(short[] input) {
        ArrayList<String> nameList = new ArrayList<>(input.length);
        for (int i : input) {
            nameList.add(name(i));
        }
        return nameList;
    }

    public static ArrayList<String> makeList(Short[] input) {
        ArrayList<String> nameList = new ArrayList<>(input.length);
        for (int i : input) {
            nameList.add(name(i));
        }
        return nameList;
    }

    public enum Target {
        ChosenTarget, //0
        PartnerOrUser, //1
        Partner, //2
        MeFirstTarget, //3
        AllButSelf, //4
        Opponents, //5
        TeamParty, //6
        User, //7
        All, //8
        RandomTarget, //9
        Field, //10
        OpposingTeam, //11
        TeamSide, //12
        IndeterminateTarget //13
    }

    public enum Flags {
        ContactFlag(1), // Is the move a contact move
        ChargeFlag(2), // Is the move a charging move? not used by PO yet
        RechargeFlag(4), // Is the move a recharging move? not used by PO yet
        ProtectableFlag(8), //Can the move be protected against
        MagicCoatableFlag(16), //Can the move be magic coated
        SnatchableFlag(32), //Can the move be snatched
        MemorableFlag(64), //Can the move be mirror moves
        PunchFlag(128), //Is the move boosted with Iron Fist
        SoundFlag(256), //Is the move blocked with SoundProof
        FlyingFlag(512), //Is the move an invulnerable move (shadow force/...)? not used by PO yet
        UnthawingFlag(1024), // Does the user of this move unthaw when frozen?
        FarReachFlag(2048), // Can this move reach targets far across in triples?
        HealingFlag(4096), //Can this move be blocked with Heal Block
        MischievousFlag(8192), // Can this move bypass substitute?
        BiteFlag(16384),//Strong jaw moves
        PowderFlag(32768), //Powder moves
        BallFlag(65536), //Ball moves for Bulletproof
        LaunchFlag(131072), //Moves that get boosted by Mega Launcher
        DanceFlag(262144) // Dancing moves for ability Dancer
        ;

        final int value;

        Flags(int num) {
            this.value = num;
        }

        public int getValue() {
            return value;
        }
    }

    public static class Move {
        public final String name;
        byte damageClass = 0;
        byte type = 0;
        byte pp = 5;
        byte accuracy = 0;
        byte power = 0;
        byte zpower = 0;
        int flags = 0;
        String effect = null;
        String zeffect = null;
        Target range = Target.ChosenTarget;

        Move(String name) {
            this.name = name;
        }
    }
}
