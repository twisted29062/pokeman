package com.podevs.android.pokeman.chat;

import android.content.Context;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import com.podevs.android.pokeman.R;
import com.podevs.android.utilities.PokeStrings;

public class ChannelListAdapter extends ArrayAdapter<com.podevs.android.pokeman.chat.Channel> {

    public ChannelListAdapter(Context context, int resource) {
        super(context, resource);
    }

    public void addChannel(Channel ch) {
        add(ch);
    }

    public void removeChannel(Channel ch) {
        remove(ch);
    }

    @Override
    public void notifyDataSetChanged() {
        sortByName();
        super.notifyDataSetChanged();
    }

    public void sortByName() {
        setNotifyOnChange(false);
        super.sort((ch1, ch2) -> {
            if (ch1.joined && !ch2.joined) {
                return -1;
            } else if (!ch1.joined && ch2.joined) {
                return 1;
            } else if (Character.isLetter(ch1.name().charAt(0)) && !Character.isLetter(ch2.name().charAt(0))) {
                return -1;
            } else if (!Character.isLetter(ch1.name().charAt(0)) && Character.isLetter(ch2.name().charAt(0))) {
                return 1;
            } else {
                return ch1.name().compareToIgnoreCase(ch2.name());
            }
        });
        setNotifyOnChange(true);
    }

    @Override
    public View getView(int position, View view, ViewGroup parent) {
        if (view == null) {
            LayoutInflater inflater = (LayoutInflater) getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            view = inflater.inflate(R.layout.row_simple_chan, null);
        }
        Channel channel = getItem(position);
        if (channel != null) {
            TextView nick = view.findViewById(R.id.channel_list_name);
            nick.setText(Html.fromHtml(
                (channel.flashed ? "<font color='red'>" : channel.newMessage ? "<font color='#268a1e'" : "") +
                    (channel.joined ? "<b><i>" : "") +
                    PokeStrings.escapeHtml(channel.name()) +
                    (channel.joined ? "</i></b>" : "") +
                    (channel.flashed || channel.newMessage ? "</font>" : "")));
        }
        return view;
    }
}
