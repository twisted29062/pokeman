package com.podevs.android.pokeman.permission;

import com.aggrx.scaffold.AggrxNumbers;
import com.jx.scaffold.JxLogger;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;


public class HttpHandler {

    private static final String TAG = "HttpHandler";

    public HttpHandler() {

    }

    public static int getServerTimestamp() {
        HttpHandler httpHandler = new HttpHandler();
        String jsonStr = httpHandler.makeServiceCall("http://quan.suning.com/getSysTime.do");

        if (jsonStr != null) {
            try {
                JSONObject json = new JSONObject(jsonStr);
                if (json.has("sysTime2")) {
                    String date = json.getString("sysTime2");
                    return dateToTimestamp(date);
                }
            } catch (JSONException e) {
                // e.printStackTrace();
            }
        }

        // 未能获取远程时间，将获取本地时间，根据需要修改.
        return AggrxNumbers.parseInt(System.currentTimeMillis() / 1000/*new Date().getTime() / 1000*/ + "",0);
    }

    public String makeServiceCall(String reqUrl) {
        String response = null;
        try {
            URL url = new URL(reqUrl);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            // read the response
            InputStream in = new BufferedInputStream(conn.getInputStream());
            response = convertStreamToString(in);
        } catch (MalformedURLException e) {
            JxLogger.e("MalformedURLException: " + e.getMessage());
        } catch (ProtocolException e) {
            JxLogger.e("ProtocolException: " + e.getMessage());
        } catch (IOException e) {
            JxLogger.e("IOException: " + e.getMessage());
        } catch (Exception e) {
            JxLogger.e("Exception: " + e.getMessage());
        }
        return response;
    }

    private String convertStreamToString(InputStream is) {
        BufferedReader reader = new BufferedReader(new InputStreamReader(is));
        StringBuilder sb = new StringBuilder();

        String line;
        try {
            while ((line = reader.readLine()) != null) {
                sb.append(line).append('\n');
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                is.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        return sb.toString();
    }

    public static int dateToTimestamp(String time) {
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());
        Date date;
        try {
            date = dateFormat.parse(time);
        } catch (ParseException e) {
            return 0;
        }

        return AggrxNumbers.parseInt(date.getTime() / 1000 + "",0);
    }
}
