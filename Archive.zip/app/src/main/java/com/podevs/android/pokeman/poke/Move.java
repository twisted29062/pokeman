package com.podevs.android.pokeman.poke;


public interface Move {
    int num();
}
