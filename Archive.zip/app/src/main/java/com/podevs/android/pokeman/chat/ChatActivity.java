package com.podevs.android.pokeman.chat;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.NotificationManager;
import android.app.ProgressDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.content.res.Configuration;
import android.os.Bundle;
import android.os.IBinder;
import android.preference.PreferenceManager;
import android.text.Html;
import android.text.InputType;
import android.text.SpannableStringBuilder;
import android.text.TextUtils;
import android.view.ContextMenu;
import android.view.ContextMenu.ContextMenuInfo;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver.OnGlobalLayoutListener;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.widget.PopupMenu;
import androidx.viewpager.widget.PagerAdapter;
import androidx.viewpager.widget.ViewPager;

import com.aggrx.scaffold.AggrxNumbers;
import com.jx.scaffold.JxLogger;
import com.jx.scaffold.JxThreadPool;
import com.podevs.android.pokeman.Command;
import com.podevs.android.pokeman.IncomingChallenge;
import com.podevs.android.pokeman.MessageListAdapter;
import com.podevs.android.pokeman.NetworkService;
import com.podevs.android.pokeman.R;
import com.podevs.android.pokeman.Tier;
import com.podevs.android.pokeman.app.BaseActivity;
import com.podevs.android.pokeman.battle.ChallengeEnums;
import com.podevs.android.pokeman.battle.ChallengeEnums.ChallengeDesc;
import com.podevs.android.pokeman.battle.ChallengeEnums.Clauses;
import com.podevs.android.pokeman.battle.ChallengeEnums.Mode;
import com.podevs.android.pokeman.player.PlayerInfo;
import com.podevs.android.pokeman.player.PlayerInfo.TierStanding;
import com.podevs.android.pokeman.player.UserInfo;
import com.podevs.android.pokeman.pms.PrivateMessageActivity;
import com.podevs.android.pokeman.registry.RegistryActivity;
import com.podevs.android.pokeman.settings.SetPreferenceActivity;
import com.podevs.android.utilities.Baos;
import com.podevs.android.utilities.PokeStrings;
import com.podevs.android.utilities.TwoViewsArrayAdapter;

import java.util.ArrayList;
import java.util.Enumeration;
import java.util.LinkedList;
import java.util.ListIterator;
import java.util.Set;
import java.util.concurrent.ScheduledThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

//import androidx.viewpager.widget.ViewPager;

public class ChatActivity extends BaseActivity {

    static final String TAG = "ChatActivity";

    private static final String PACK_NAME = "com.podevs.android.poAndroid";
    public ProgressDialog progressDialog;
    // public final static int SWIPE_TIME_THRESHOLD = 100;
    View playersLayout, chatLayout, channelsLayout;
    String challengedTier = "";
    boolean registering = false;
    private PlayerListAdapter playerAdapter = null;
    private ChannelListAdapter channelAdapter = null;
    private MessageListAdapter messageAdapter = null;
    private ChatListView players;
    private ListView channels;
    private NetworkService netServ = null;
    private ListView chatView;
    private EditText chatInput;
    private ViewPager chatViewSwitcher;
    private PlayerInfo lastClickedPlayer;
    private Channel lastClickedChannel;
    private boolean loading = true;
    private SharedPreferences prefs;
    private boolean isChangingNames = false;
    private String newNickname = null;
    private boolean cancelScroll = false;
    private boolean connected = false;
    private final ServiceConnection connection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName className, IBinder service) {
            netServ = ((NetworkService.LocalBinder) service).getService();
            connected = true;

            updateTitle();
            netServ.chatActivity = ChatActivity.this;
            if (netServ.joinedChannels.peek() != null && !netServ.joinedChannels.isEmpty()) {
                populateUI(false);
                if (progressDialog.isShowing()) {
                    progressDialog.dismiss();
                    setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_USER);
                }
                loading = false;
            }
            checkAskForServerPass();
            checkChallenges();
            checkAskForPass();
            checkFailedConnection();
            ScheduledThreadPoolExecutor executor = new ScheduledThreadPoolExecutor(1);
            executor.schedule(() -> netServ.loadJoinedChannelSettings(), 5, TimeUnit.SECONDS);
            invalidateOptionsMenu();
        }

        @Override
        public void onServiceDisconnected(ComponentName className) {
            netServ.chatActivity = null;
            netServ = null;
        }
    };
    private ViewRankingGroup activeViewRanking;
    private ControlPanelGroup activeControlPanel;
    private String controlUser = "";

    /**
     * Called when the activity is first created.
     */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        if (loading) {
            showLoading("Loading. Please wait...", true);
        }

        super.onCreate(savedInstanceState);

        chatViewSwitcher = new ViewPager(this);
        LayoutInflater inflater = getLayoutInflater();

        chatLayout = inflater.inflate(R.layout.chat, null);
        channelsLayout = inflater.inflate(R.layout.channellist, null);
        playersLayout = inflater.inflate(R.layout.playerlist, null);

        chatView = chatLayout.findViewById(R.id.chatView);
        chatViewSwitcher.setAdapter(new MyAdapter());

        setupFindBattleButton();
        setContentView(chatViewSwitcher);

        setupChatView();
        chatViewSwitcher.setCurrentItem(1);

        //Player List Stuff**
        setupPlayerList();

        //Channel List Stuff**
        setupChannelList();

        Intent serviceIntent = new Intent(ChatActivity.this, NetworkService.class);

        startService(serviceIntent);
        bindService(serviceIntent, connection, BIND_AUTO_CREATE);
        setupChatInput();
    }

    private void showLoading(String message, boolean cancelable) {
        progressDialog = ProgressDialog.show(ChatActivity.this, "", message, true);
        progressDialog.setCancelable(cancelable);
        progressDialog.setOnCancelListener(dialog -> disconnect());
        int currentOrientation = getResources().getConfiguration().orientation;
        if (currentOrientation == Configuration.ORIENTATION_LANDSCAPE) {
            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE);
        } else {
            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT);
        }
    }

    private void disconnect() {
        JxLogger.i("disconnect");
        JxThreadPool.shared().post("disconnect", this, activity -> {
            JxLogger.i("disconnect background");
            if (netServ != null) {
                netServ.disconnect();
            }
            activity.runOnUiThread(() -> {
                JxLogger.i("disconnect ui thread");

                if (progressDialog != null) {
                    networkDismissDialog();
                }

                Intent intent = new Intent(activity, RegistryActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                intent.putExtra("sticky", true);

                if (netServ == null || netServ.socket == null) {
                    intent.putExtra("failedConnect", true);
                }
                finish();
                startActivity(intent);
            });
        });

//        new Thread(() -> {
//            JxLogger.i("disconnect background");
//            if (netServ != null) {
//                netServ.disconnect();
//            }
//
//            runOnUiThread(new Runnable() {
//                @Override public void run() {
//                    JxLogger.i("disconnect ui thread");
//
//                    if (progressDialog != null) {
//                        networkDismissDialog();
//                    }
//
//                    Intent intent = new Intent(ChatActivity.this, RegistryActivity.class);
//                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
//                    intent.putExtra("sticky", true);
//
//                    if (netServ == null || netServ.socket == null) {
//                        intent.putExtra("failedConnect", true);
//                    }
//                    finish();
//                    startActivity(intent);
//                }
//            });
//        });
    }

    public void networkDismissDialog() {
        progressDialog.dismiss();
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_USER);
    }

    @SuppressLint("ClickableViewAccessibility")
    private void setupChatInput() {
        chatInput = chatLayout.findViewById(R.id.chatInput);
        // Hide the soft-keyboard when the activity is created
        chatInput.setInputType(InputType.TYPE_NULL);
        chatInput.setOnTouchListener((v, event) -> {
            chatInput.setInputType(InputType.TYPE_CLASS_TEXT);
            chatInput.onTouchEvent(event);
            return true;
        });

        chatInput.setOnKeyListener((v, keyCode, event) -> {
            // If the event is a key-down event on the "enter" button
            // and the socket is connected
            if ((event.getAction() == KeyEvent.ACTION_DOWN) && (keyCode == KeyEvent.KEYCODE_ENTER)) {
                // netServ != null && netServ.socket != null  && netServ.socket.isConnected() 耗时太长
                if (connected) {
                    // Perform action on key press
                    Baos b = new Baos();
                    b.write(1); //channel message
                    b.write(0); //no html
                    b.putInt(currentChannel().id);
                    b.putString(chatInput.getText().toString());
                    try {
                        netServ.socket.sendMessage(b, Command.SendMessage);
                    } catch (Exception e) {
                        JxLogger.i("%s", e.toString());
                    }
                    chatInput.getText().clear();
                    return true;
                }
            }
            return false;
        });
    }

    private void setupChannelList() {
        channels = channelsLayout.findViewById(R.id.channelListing);
        channelAdapter = new ChannelListAdapter(this, 0);
        // registerForContextMenu(channels);
        channels.setOnItemLongClickListener((parent, view, position, id) -> {
            JxLogger.i("");

            PopupMenu popup = new PopupMenu(ChatActivity.this, view);
            setupChannelListContextMenu(popup.getMenu(), position);
            popup.setOnMenuItemClickListener(this::onContextItemSelected);

            popup.show();
            return true;
        });

        channels.setOnItemClickListener((parent, view, position, id) -> {
            Channel clicked = channelAdapter.getItem(position);
            if (netServ != null && netServ.joinedChannels.contains(clicked)) {
                // XXX remove is implemented as O(N) we could do it O(1) if we really had to
                netServ.joinedChannels.remove(clicked);
                netServ.joinedChannels.addFirst(clicked);
                if (clicked.flashed || clicked.newMessage) {
                    clicked.flashed = false;
                    clicked.newMessage = false;
                }
                populateUI(true);
            }
        });
    }

    private void setupChannelListContextMenu(@androidx.annotation.NonNull Menu menu, int position) {
        String cName = "Default";
        if (channelAdapter == null) {
            return;
        }
        try {
            lastClickedChannel = channelAdapter.getItem(position);
            if (lastClickedChannel != null) {
                cName = lastClickedChannel.name;
            }
        } catch (IndexOutOfBoundsException e) {
            cName = "Error: " + position + " " + channelAdapter.getCount();
            if (netServ != null) {
                lastClickedChannel = netServ.joinedChannels.getFirst();
            }
        }

        if (lastClickedChannel == null) {
            return;
        }

        if (netServ.joinedChannels.contains(lastClickedChannel)) {
            menu.add(Menu.NONE, ChatContext.LeaveChannel.ordinal(), 0, getString(R.string.label_level_channel) + cName);
            menu.add(Menu.NONE, ChatContext.ChannelEvent.ordinal(), 0, R.string.label_channel_event).setCheckable(true);
            menu.findItem(ChatContext.ChannelEvent.ordinal()).setChecked(lastClickedChannel.channelEvents);
        } else {
            menu.add(Menu.NONE, ChatContext.JoinChannel.ordinal(), 0, "Join " + cName);
        }
    }

    public void populateUI(boolean clear) {
        Channel currentChannel = currentChannel();
        if (currentChannel != null) {
            // Populate the player list
            if (clear) {
                playerAdapter = new PlayerListAdapter(ChatActivity.this, 0);
                channelAdapter = new ChannelListAdapter(ChatActivity.this, 0);
            }
            messageAdapter = new MessageListAdapter(currentChannel, ChatActivity.this);
            Enumeration<PlayerInfo> e = currentChannel.players.elements();
            playerAdapter.setNotifyOnChange(false);
            while (e.hasMoreElements()) {
                playerAdapter.add(e.nextElement());
            }
            playerAdapter.sortByNick();
            playerAdapter.setNotifyOnChange(true);
            // Populate the Channel list
            Enumeration<Channel> c = netServ.channels.elements();
            channelAdapter.setNotifyOnChange(false);
            while (c.hasMoreElements()) {
                channelAdapter.addChannel(c.nextElement());
            }
            channelAdapter.sortByName();
            channelAdapter.setNotifyOnChange(true);
            // Load scrollback
            runOnUiThread(() -> {
                players.setAdapter(playerAdapter);
                channels.setAdapter(channelAdapter);
                chatView.setAdapter(messageAdapter);
                playerAdapter.notifyDataSetChanged();
                channelAdapter.notifyDataSetChanged();
                messageAdapter.notifyDataSetChanged();
                chatView.setSelection(messageAdapter.getCount() - 1);
                chatViewSwitcher.invalidate();
            });
        }
    }

    /**
     * Gives the current channel
     *
     * @return the current channel as a {@link Channel} object
     */
    public Channel currentChannel() {
        /* Maybe later instead of this hack, use onSavedInstanceState properly ? */
        return netServ.joinedChannels.peek();
    }

    private void setupPlayerList() {
        players = playersLayout.findViewById(R.id.playerListing);

        playerAdapter = new PlayerListAdapter(ChatActivity.this, 0);
        // registerForContextMenu(players);
        players.setOnItemLongClickListener((parent, view, position, id) -> {
            JxLogger.i("");

            PopupMenu popup = new PopupMenu(ChatActivity.this, view);
            setupPlayerContextMenu(popup.getMenu(), position);
            popup.setOnMenuItemClickListener(this::onContextItemSelected);

            popup.show();
            return true;
        });

        players.setOnItemClickListener((parent, view, position, id) -> {
            PlayerInfo clicked = playerAdapter.getItem(position);
            if (netServ != null && NetworkService.pmedPlayers.contains(clicked.id)) {
                netServ.pms.createPM(clicked);
                Intent intent = new Intent(ChatActivity.this, PrivateMessageActivity.class);
                intent.putExtra("playerId", clicked.id);
                startActivity(intent);
            }
        });
    }

    private void setupPlayerContextMenu(@NonNull Menu menu, int position) {
        if (playerAdapter == null) {
            return;
        }
        lastClickedPlayer = playerAdapter.getItem(position);

        if (lastClickedPlayer == null) {
            return;
        }
        String pName = lastClickedPlayer.nick();


        menu.add(Menu.NONE, ChatContext.ChallengePlayer.ordinal(), 0, getString(R.string.challenge) + " " + pName);
        menu.add(Menu.NONE, ChatContext.ViewPlayerInfo.ordinal(), 0, getString(R.string.view_player_info));
        menu.add(Menu.NONE, ChatContext.ViewRanking.ordinal(), 0, R.string.view_ranking);
        if (netServ != null) {
            if (netServ.myid != lastClickedPlayer.id) {
                menu.add(Menu.NONE, ChatContext.PrivateMessage.ordinal(), 0, getString(R.string.pm));
            }
            for (Integer battleId : lastClickedPlayer.battles) {
                menu.add(Menu.NONE, ChatContext.WatchBattle.ordinal(), 0, getString(R.string.watch_battle) + " " +
                        netServ.playerName(netServ.battle(battleId).opponent(lastClickedPlayer.id)))
                        .setIntent(new Intent().putExtra("battle", battleId));
            }
            if (netServ.me.auth > 0) {
                menu.add(Menu.NONE, ChatContext.ControlPanel.ordinal(), 0, "Control Panel");
            }
        }
        menu.add(Menu.NONE, ChatContext.IgnorePlayer.ordinal(), 0, getString(R.string.ignorePlayer));
        menu.findItem(ChatContext.IgnorePlayer.ordinal()).setCheckable(true);
        menu.findItem(ChatContext.IgnorePlayer.ordinal()).setChecked(netServ.ignoreList.contains(lastClickedPlayer.id));
    }

    private void setupChatView() {
        prefs = getPreferences(MODE_PRIVATE);
        if (PreferenceManager.getDefaultSharedPreferences(getBaseContext()).getBoolean("shouldTryTapMenu", false)) {
            chatView.setOnItemLongClickListener((parent, view, position, id) -> {
                String test = ((TextView) chatView.getItemAtPosition(position)).getText().toString();
                AlertDialog.Builder builder = new AlertDialog.Builder(ChatActivity.this);
                builder.setMessage(test)
                        .setNegativeButton("Copy", (dialog, which) -> {
                            ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                            ClipData clip = ClipData.newPlainText("simple text", test);
                            clipboard.setPrimaryClip(clip);
                        }).setNeutralButton("Name", (dialog, which) -> {
                    ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                    String toCopy = test.substring(test.indexOf(") ") + 1, test.indexOf(":")); // .*\) (.*?):
                    if (toCopy.charAt(0) == '+') {
                        toCopy = toCopy.substring(1);
                    }
                    ClipData clip = ClipData.newPlainText("simple text", toCopy);
                    clipboard.setPrimaryClip(clip);
                });
                if (netServ.me.auth > 0) {
                    builder.setPositiveButton("Auth", (dialog, which) -> {
                        String toCopy = test.substring(test.indexOf(") ") + 1, test.indexOf(":")); // .*\) (.*?):
                        if (toCopy.charAt(0) == '+') {
                            toCopy = toCopy.substring(1);
                        }
                        controlUser = toCopy;
                        showDialog(ChatDialog.ControlPanel.ordinal());

                    });
                }
                builder.create().show();
                return false;
            });
        }
    }

    private void setupFindBattleButton() {
        ImageButton findBattleButton = chatLayout.findViewById(R.id.findBattle);
        findBattleButton.setOnClickListener(v -> dealWithFindBattle());
    }

    private void dealWithFindBattle() {
        if (connected/*netServ.socket.isConnected()*/) {
            if (netServ.findingBattle) {
                netServ.findingBattle = false;
                netServ.socket.sendMessage(
                        constructChallenge(ChallengeDesc.Cancelled.ordinal(), 0, 0, "", "", Clauses.SleepClause.mask(), Mode.Singles.ordinal()),
                        Command.ChallengeStuff);
                Toast.makeText(this, "Find battle request cancelled", Toast.LENGTH_SHORT).show();
            } else {
                showDialog(ChatDialog.FindBattle.ordinal());
            }
        }
    }

    private Baos constructChallenge(int desc, int opp, int team, String srcTier, String destTier, int clauses, int mode) {
        Baos challenge = new Baos();
        challenge.write(desc);
        challenge.putInt(opp);
        challenge.putInt(clauses);
        challenge.write(mode);
        challenge.write(team);
        challenge.putBaos(netServ.meLoginPlayer.team.gen);
        challenge.putString(srcTier);
        challenge.putString(destTier);
        return challenge;
    }

    @Override
    public void onResume() {
        super.onResume();
        chatViewSwitcher.setCurrentItem(1);
        if (netServ != null) {
            netServ.checkBattlesToEnd();
        }
        checkAskForServerPass();
        checkChallenges();
        checkAskForPass();
        checkFailedConnection();
    }

    private void checkChallenges() {
        if (netServ != null) {
            IncomingChallenge challenge = netServ.challenges.peek();
            if (challenge != null) {
                showDialog(ChatDialog.Challenge.ordinal());
                ((NotificationManager) getSystemService(NOTIFICATION_SERVICE)).cancel(IncomingChallenge.note);
            }
        }
    }

    private void checkAskForServerPass() {
        if (netServ != null && netServ.askedForServerPass) {
            showDialog(ChatDialog.AskForServerPass.ordinal());
        }
    }

    private void checkAskForPass() {
        if (netServ != null && netServ.askedForPass) {
            showDialog(ChatDialog.AskForPass.ordinal());
        }
    }

    private void checkFailedConnection() {
        if (netServ != null && netServ.failedConnect) {
            disconnect();
        }
    }

    @Override
    public void onConfigurationChanged(@NonNull Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        chatViewSwitcher.getViewTreeObserver().addOnGlobalLayoutListener(new OnGlobalLayoutListener() {
            @Override
            public void onGlobalLayout() {
                chatViewSwitcher.getViewTreeObserver().removeOnGlobalLayoutListener(this);
                chatViewSwitcher.setCurrentItem(1);
                if (messageAdapter != null) {
                    chatView.setSelection(messageAdapter.getCount() - 1);
                }
            }
        });
    }

    @Override
    public void onDestroy() {
        unbindService(connection);
        super.onDestroy();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        super.onCreateOptionsMenu(menu);
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.chatoptions, menu);
        if (netServ != null) {
            menu.findItem(R.id.openPM).setVisible(netServ.pms.count() != 0);
        }
        return true;
    }

    @Override
    public boolean onPrepareOptionsMenu(Menu menu) {
        MenuItem findbattle = menu.findItem(R.id.findBattle);
        if (netServ != null && netServ.findingBattle) {
            findbattle.setTitle(R.string.cancel_find_battle);
        } else {
            findbattle.setTitle(R.string.find_a_battle);
        }

        if (netServ != null && netServ.me != null) {
            menu.findItem(R.id.idle).setChecked(netServ.me.isAway);
        } else {
            menu.findItem(R.id.idle).setChecked(getSharedPreferences("clientOptions", MODE_PRIVATE).getBoolean("idle", false));
        }

        if (netServ != null) {
            menu.findItem(R.id.register).setVisible(!netServ.registered);
            menu.findItem(R.id.controlpanel).setVisible(netServ.me.auth > 0);
            menu.findItem(R.id.openPM).setVisible(netServ.pms.count() != 0);
        }

        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int itemId = item.getItemId();
        if (itemId == R.id.chat_disconnect) {
            showDialog(ChatDialog.ConfirmDisconnect.ordinal());
        } else if (itemId == R.id.findBattle) {
            dealWithFindBattle();
        } else if (itemId == R.id.preferences) {//TODO: Make actual preferences menu
            // Launch Preference activity
            //Toast.makeText(ChatActivity.this, "Preferences not Implemented Yet",
            //        Toast.LENGTH_SHORT).show();
            showDialog(ChatDialog.TierSelection.ordinal());
        } else if (itemId == R.id.idle) {
            boolean checked = !item.isChecked();

            getSharedPreferences("clientOptions", MODE_PRIVATE).edit().putBoolean("idle", checked).apply();
            netServ.socket.sendMessage(new Baos().putFlags(new boolean[]{netServ.me.hasLadderEnabled, checked}), Command.OptionsChanged);
        } else if (itemId == R.id.register) {
            if (netServ != null) {
                registering = true;
                netServ.socket.sendMessage(new Baos(), Command.Register);
            }
        } else if (itemId == R.id.changeName) {/*
				String all = chatInput.getText().toString();
				if (all.length() > 3) {
					String s = all;
					if (s.contains(" ")) {
						s = chatInput.getText().toString().split(" (?!.* )")[1];
						if (s.length() < 4) {
							break;
						}
					}
					Collection<PlayerInfo> players = currentChannel().players.values();
					ArrayList<String> nicks = new ArrayList<String>();
					String regex = "(?i)^" + s + ".*";
					for (PlayerInfo p : players) {
						if (p.nick.matches(regex)) {
							nicks.add(p.nick());
						}
					}
					players = null;
					if (nicks.size() == 1) {
						all = all.replaceFirst(regex, nicks.get(0));
						chatInput.setText(all);
						chatInput.setSelection(all.length()-1);
					} else {
						// Add pop-out listview to choose from end results larger than 1
						all = all.replaceFirst(regex, nicks.get(0));
						chatInput.setText(all);
						chatInput.setSelection(all.length()-1);
					}
				} else {
					break;
				}
				*/
            showDialog(ChatDialog.AskForName.ordinal());
        } else if (itemId == R.id.settings) {
            startActivity(new Intent(ChatActivity.this, SetPreferenceActivity.class));
        } else if (itemId == R.id.loadteam) {
            showDialog(ChatDialog.LoadTeam.ordinal());
        } else if (itemId == R.id.controlpanel) {
            controlUser = "";
            showDialog(ChatDialog.ControlPanel.ordinal());
        } else if (itemId == R.id.openPM) {
            if (netServ == null) {
                Toast.makeText(this, R.string.no_netserv, Toast.LENGTH_SHORT).show();
            } else {
                if (netServ.pms.count() > 0) {
                    Intent intent = new Intent(this, PrivateMessageActivity.class);
                    intent.putExtra("playerId", -2);
                    startActivity(intent);
                }
            }
        }
        return true;
    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenuInfo menuInfo) {
        AdapterView.AdapterContextMenuInfo aMenuInfo = (AdapterView.AdapterContextMenuInfo) menuInfo;
        int id = v.getId();
        if (id == R.id.playerListing) {
            lastClickedPlayer = playerAdapter.getItem(aMenuInfo.position);
            String pName = lastClickedPlayer.nick();
            menu.setHeaderTitle(pName);
            menu.add(Menu.NONE, ChatContext.ChallengePlayer.ordinal(), 0, getString(R.string.challenge) + " " + pName);
            menu.add(Menu.NONE, ChatContext.ViewPlayerInfo.ordinal(), 0, getString(R.string.view_player_info));
            menu.add(Menu.NONE, ChatContext.ViewRanking.ordinal(), 0, "View Ranking");
            if (netServ != null) {
                if (netServ.myid != lastClickedPlayer.id) {
                    menu.add(Menu.NONE, ChatContext.PrivateMessage.ordinal(), 0, getString(R.string.pm));
                }
                for (Integer battleid : lastClickedPlayer.battles) {
                    menu.add(Menu.NONE, ChatContext.WatchBattle.ordinal(), 0, getString(R.string.watch_battle) + " " +
                            netServ.playerName(netServ.battle(battleid).opponent(lastClickedPlayer.id)))
                            .setIntent(new Intent().putExtra("battle", battleid));
                }
                if (netServ.me.auth > 0) {
                    menu.add(Menu.NONE, ChatContext.ControlPanel.ordinal(), 0, "Control Panel");
                }
            }
            menu.add(Menu.NONE, ChatContext.IgnorePlayer.ordinal(), 0, getString(R.string.ignorePlayer));
            menu.findItem(ChatContext.IgnorePlayer.ordinal()).setCheckable(true);
            menu.findItem(ChatContext.IgnorePlayer.ordinal()).setChecked(netServ.ignoreList.contains(lastClickedPlayer.id));
        } else if (id == R.id.channelListing) {
            String cName = "Default";
            try {
                lastClickedChannel = channelAdapter.getItem(aMenuInfo.position);
                if (lastClickedChannel != null) {
                    cName = lastClickedChannel.name;
                }
            } catch (IndexOutOfBoundsException e) {
                cName = "Error: " + aMenuInfo.position + " " + channelAdapter.getCount();
                lastClickedChannel = netServ.joinedChannels.getFirst();
            }
            menu.setHeaderTitle(cName);
            if (netServ.joinedChannels.contains(lastClickedChannel)) {
                menu.add(Menu.NONE, ChatContext.LeaveChannel.ordinal(), 0, "Leave " + cName);
                menu.add(Menu.NONE, ChatContext.ChannelEvent.ordinal(), 0, "Channel Event").setCheckable(true);
                menu.findItem(ChatContext.ChannelEvent.ordinal()).setChecked(lastClickedChannel.channelEvents);
            } else {
                menu.add(Menu.NONE, ChatContext.JoinChannel.ordinal(), 0, "Join " + cName);
            }
        }
    }

    @Override
    public boolean onContextItemSelected(MenuItem item) {
        switch (ChatContext.values()[item.getItemId()]) {
            case IgnorePlayer:
                Integer id = lastClickedPlayer.id;
                if (netServ.ignoreList.contains(id)) {
                    netServ.ignoreList.remove(id);
                    Toast.makeText(ChatActivity.this, "Unignored " + netServ.playerName(id) + ".", Toast.LENGTH_LONG).show();
                } else {
                    netServ.ignoreList.add(id);
                    Toast.makeText(ChatActivity.this, "Ignored " + netServ.playerName(id) + ".", Toast.LENGTH_LONG).show();
                }
                break;
            case ChallengePlayer:
                showDialog(ChatDialog.ChooseTierMode.ordinal());
                break;
            case ViewPlayerInfo:
                showDialog(ChatDialog.PlayerInfo.ordinal());
                break;
            case WatchBattle:
                int battleid = item.getIntent().getIntExtra("battle", 0);
                if (battleid != 0) {
                    Baos watch = new Baos();
                    watch.putInt(battleid);
                    watch.putBool(true); // watch, not leaving
                    netServ.socket.sendMessage(watch, Command.SpectateBattle);
                }
                break;
            case JoinChannel:
                Baos join = new Baos();
                join.putString(lastClickedChannel.name);
                if (connected/*netServ != null && netServ.socket != null && netServ.socket.isConnected()*/) {
                    netServ.socket.sendMessage(join, Command.JoinChannel);
                }
                break;
            case LeaveChannel:
                try {
                    Baos leave = new Baos();
                    leave.putInt(lastClickedChannel.id);
                    if (connected/*netServ != null && netServ.socket != null && netServ.socket.isConnected()*/) {
                        netServ.socket.sendMessage(leave, Command.LeaveChannel);
                    }
                    break;
                } catch (Exception e) {
                    //blah blah blah
                }
            case PrivateMessage:
                if (netServ == null) {
                    Toast.makeText(this, R.string.no_netserv, Toast.LENGTH_SHORT).show();
                } else {
                    netServ.createPM(lastClickedPlayer.id);

                    Intent intent = new Intent(this, PrivateMessageActivity.class);
                    intent.putExtra("playerId", lastClickedPlayer.id);
                    startActivity(intent);
                }
                break;
            case ChannelEvent:
                channelAdapter.getItem(channelAdapter.getPosition(lastClickedChannel)).channelEvents = !lastClickedChannel.channelEvents;
                break;
            case ControlPanel:
                controlUser = lastClickedPlayer.nick();
                showDialog(ChatDialog.ControlPanel.ordinal());
                break;
            case ViewRanking:
                showDialog(ChatDialog.ViewRanking.ordinal());
                break;
        }
        return true;
    }

    @Override
    protected Dialog onCreateDialog(int id) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        LayoutInflater inflater = (LayoutInflater) getSystemService(LAYOUT_INFLATER_SERVICE);
        switch (ChatDialog.values()[id]) {
            case Challenge: {
                if (netServ == null) {
                    return null;
                }
                IncomingChallenge challenge = netServ.challenges.poll();
                View challengedLayout = inflater.inflate(R.layout.player_info_dialog, findViewById(R.id.player_info_dialog));
                PlayerInfo opp = netServ.players.get(challenge.opponent);

                /* Like when activity resumed after a long time */
                if (opp == null) {
                    return null;
                }

                TextView oppInfo, oppName, challInfo;
                builder.setView(challengedLayout)
                        .setCancelable(false)
                        .setNegativeButton(getString(R.string.decline), (dialog, which) -> {
                            // Decline challenge
                            if (connected/*netServ.socket.isConnected()*/) {
                                netServ.socket.sendMessage(
                                        constructChallenge(ChallengeDesc.Refused.ordinal(),
                                                challenge.opponent,
                                                0,
                                                challenge.srcTier,
                                                challenge.destTier,
                                                challenge.clauses,
                                                challenge.mode),
                                        Command.ChallengeStuff);
                            }
                            removeDialog(id);
                            checkChallenges();
                        })
                        .setPositiveButton(getString(R.string.accept), (dialog, which) -> {
                            // Accept challenge
                            if (connected/*netServ.socket.isConnected()*/) {
                                netServ.socket.sendMessage(
                                        constructChallenge(ChallengeDesc.Accepted.ordinal(),
                                                challenge.opponent,
                                                0,
                                                challenge.srcTier,
                                                challenge.destTier,
                                                challenge.clauses,
                                                challenge.mode),
                                        Command.ChallengeStuff);
                            }
                            // Without removeDialog() the dialog is reused and can only
                            // be modified in onPrepareDialog(). This dialog changes
                            // so much that I doubt it's worth the code to deal with
                            // onPrepareDialog() but we should use it if we have complex
                            // dialogs that only need to change a little
                            removeDialog(id);
                            checkChallenges();
                        });
                AlertDialog oppInfoDialog = builder.create();

                oppInfo = challengedLayout.findViewById(getResources().getIdentifier("player_info", "id", PACK_NAME));
                oppInfo.setText(Html.fromHtml("<b>Info: </b>" + PokeStrings.escapeHtml(opp.info())));

                challInfo = challengedLayout.findViewById(R.id.challenge_info);
                challInfo.setText(Html.fromHtml(
                        "<b>Their Tier: </b>" + challenge.srcTier + "<br />" +
                                "<b>Your Tier: </b>" + challenge.destTier + "<br />" +
                                "<b>Mode: </b>" + ChallengeEnums.Mode.values()[challenge.mode].toString() + "<br />" +
                                "<b>Clauses: </b> " + ChallengeEnums.clausesToStringHtml(challenge.clauses)));
                challInfo.setGravity(Gravity.CENTER_HORIZONTAL);

                oppName = challengedLayout.findViewById(getResources().getIdentifier("player_info_name", "id", PACK_NAME));
                oppName.setText(getString(R.string.accept_challenge) + " " + opp.nick() + "?");
                oppName.setTextSize(18);
                //oppTier = (TextView)challengedLayout.findViewById(getResources().getIdentifier("player_info_tier", "id", PACK_NAME));
                //oppTier.setText(Html.fromHtml("<b>Tier: </b>" + NetworkService.escapeHtml(opp.tier)));
                //oppRating = (TextView)challengedLayout.findViewById(getResources().getIdentifier("player_info_rating", "id", PACK_NAME));
                //oppRating.setText(Html.fromHtml("<b>Rating: </b>" + NetworkService.escapeHtml(new Short(opp.rating).toString())));

                return oppInfoDialog;
            }
            case AskForPass: {
                //View layout = inflater.inflate(R.layout.ask_for_pass, null);
                EditText passField = new EditText(this);
                passField.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
                //passField.setTransformationMethod(PasswordTransformationMethod.getInstance());
                int currentOrientation = getResources().getConfiguration().orientation;
                if (currentOrientation == Configuration.ORIENTATION_LANDSCAPE) {
                    setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE);
                } else {
                    setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT);
                }
                builder.setMessage("Please enter your password " + (isChangingNames ? newNickname
                        : netServ.me.nick()) + ".")
                        .setCancelable(true)
                        .setView(passField)
                        .setPositiveButton("Done", (dialog, which) -> {
                            if (netServ != null) {
                                netServ.sendPass(passField.getText().toString(), true);
                                registering = false;
                                netServ.registered = true;
                                if (isChangingNames) {
                                    isChangingNames = false;
                                    Toast.makeText(ChatActivity.this, "Switched names to " + newNickname + ".", Toast.LENGTH_SHORT).show();
                                    newNickname = null;
                                }
                            }
                            removeDialog(id);
                            if (!loading) {
                                setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_USER);
                            }
                        })
                        .setOnCancelListener(dialog -> {
                            removeDialog(id);
                            netServ.askedForPass = false;
                            if (!registering) {
                                disconnect();
                            }
                            if (!loading) {
                                setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_USER);
                            }
                        });
                if (netServ != null) {
                    String defaultPass = netServ.getDefaultPass();
                    passField.setText(defaultPass);
                }
                AlertDialog dialog = builder.create();
                passField.setOnFocusChangeListener((v, hasFocus) -> {
                    if (hasFocus) {
                        dialog.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE);
                    }
                });
                return dialog;
            }
            case AskForServerPass: {
                //View layout = inflater.inflate(R.layout.ask_for_pass, null);
                EditText passField = new EditText(this);
                passField.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
                //passField.setTransformationMethod(PasswordTransformationMethod.getInstance());
                builder.setMessage("Please enter the password for " + netServ.serverName + ".")
                        .setCancelable(true)
                        .setView(passField)
                        .setPositiveButton("Done", (dialog, which) -> {
                            if (netServ != null) {
                                netServ.sendPass(passField.getText().toString(), false);
                            }
                            removeDialog(id);
                        })
                        .setOnCancelListener(dialog -> {
                            removeDialog(id);
                            if (!registering) {
                                disconnect();
                            }
                        });
                AlertDialog dialog = builder.create();
                passField.setOnFocusChangeListener((v, hasFocus) -> {
                    if (hasFocus) {
                        dialog.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE);
                    }
                });
                return dialog;
            }
            case AskForName: {
                EditText nameField = new EditText(this);
                nameField.setInputType(InputType.TYPE_CLASS_TEXT);
                builder.setMessage("Please enter a new name")
                        .setCancelable(true)
                        .setView(nameField)
                        .setPositiveButton("Done", (dialog, which) -> {
                            String newName = nameField.getText().toString();
                            if (newName.length() == 0) {
                                Toast.makeText(ChatActivity.this, "Please input a valid name", Toast.LENGTH_SHORT).show();
                            } else {
                                isChangingNames = true;
                                newNickname = newName;
                                netServ.changeConnect(newName);
                            }
                            removeDialog(id);
                        })
                        .setOnCancelListener(dialog -> removeDialog(id));
                AlertDialog dialog = builder.create();
                nameField.setOnFocusChangeListener((v, hasFocus) -> {
                    if (hasFocus) {
                        dialog.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE);
                    }
                });
                return dialog;
            }
            case ConfirmDisconnect: {
                builder.setMessage("Really disconnect?")
                        .setCancelable(true)
                        .setPositiveButton("Disconnect", (dialog, which) -> {
                            netServ.updateJoinedChannelSettings();
                            showLoading("Disconnecting. Please wait...", false);
                            disconnect();
                        })
                        .setNegativeButton(R.string.title_cancel_button, null);
                return builder.create();
            }
            case FindBattle: {
                EditText range = new EditText(this);
                range.append("" + prefs.getInt("range", 200));
                range.setInputType(InputType.TYPE_CLASS_NUMBER);
                range.setHint("Range");
                builder.setTitle(R.string.find_a_battle)
                        .setMultiChoiceItems(new CharSequence[]{getString(R.string.force_rated), getString(R.string.force_same_tier), getString(R.string.only_within_range)}, new boolean[]{prefs.getBoolean("findOption0", false), prefs.getBoolean("findOption1", true), prefs.getBoolean("findOption2", false)}, (dialog, which, isChecked) -> prefs.edit().putBoolean("findOption" + which, isChecked).apply())
                        .setView(range)
                        .setPositiveButton("Find", (dialog, which) -> {
                            if (connected/*netServ != null && netServ.socket.isConnected()*/) {
                                netServ.findingBattle = true;
                                try {
                                    prefs.edit().putInt("range", AggrxNumbers.parseInt(range.getText().toString(),0)).apply();
                                } catch (NumberFormatException e) {
                                    prefs.edit().remove("range").apply();
                                }
                                netServ.socket.sendMessage(
                                        constructFindBattle(prefs.getBoolean("findOption0", false), prefs.getBoolean("findOption1", true), prefs.getBoolean("findOption2", false), prefs.getInt("range", 200)), Command.FindBattle);
                            }
                        });
                return builder.create();
            }
            case TierSelection: {
                if (netServ == null) {
                    return null;
                }
                return new TierAlertDialog(this, netServ.superTier);
            }
            case PlayerInfo: {
                View layout = inflater.inflate(R.layout.player_info_dialog, findViewById(R.id.player_info_dialog));
                // ImageView[] pPokeIcons = new ImageView[6];
                builder.setView(layout)
                        .setNegativeButton(R.string.title_back_button, (dialog, which) -> removeDialog(id))
                        .setOnCancelListener(dialog -> removeDialog(id))
                        .setPositiveButton(R.string.challenge, (dialog, which) -> {
                            showDialog(ChatDialog.ChooseTierMode.ordinal());
                            removeDialog(id);
                        });
                AlertDialog pInfoDialog = builder.create();


                // for(int i = 0; i < 6; i++){
                // pPokeIcons[i] = (ImageView)layout.findViewById(getResources().getIdentifier("player_info_poke" + (i+1), "id", PACK_NAME));
                //pPokeIcons[i].setImageDrawable(getIcon(lastClickedPlayer.pokes[i]));
                // }
                TextView pInfo = layout.findViewById(R.id.player_info);
                pInfo.setText(Html.fromHtml("<b>Info: </b>" + PokeStrings.escapeHtml(lastClickedPlayer.info())));
                TextView pName = layout.findViewById(R.id.player_info_name);
                pName.setText(lastClickedPlayer.nick());
                ListView ratings = layout.findViewById(R.id.player_info_tiers);
                ratings.setAdapter(new TwoViewsArrayAdapter<>(this, android.R.layout.simple_list_item_2,
                        android.R.id.text1, android.R.id.text2, lastClickedPlayer.tierStandings, PlayerInfo.tierGetter));
                return pInfoDialog;
            }
            case ChooseTierMode: {
                ArrayList<PlayerInfo.TierStanding> standings = (ArrayList<PlayerInfo.TierStanding>) lastClickedPlayer.tierStandings.clone();

                /* If the opponent only has one team, no point in choosing which tier to challenge in */
                if (standings.size() == 1) {
                    challengedTier = standings.get(0).tier;
                    showDialog(ChatDialog.ChallengeMode.ordinal());
                    return null;
                }

                String[] tiers = new String[standings.size()];
                int checkedItem = -1;
                for (int i = 0; i < standings.size(); i++) {
                    tiers[i] = standings.get(i).tier + " (" + standings.get(i).rating + ")";

                    if (standings.get(i).tier.equals(netServ.me.tierStandings.get(0).tier)) {
                        checkedItem = i;
                    }
                }
                builder.setSingleChoiceItems(tiers, checkedItem, (dialog, which) -> {
                }).setPositiveButton("Continue", (dialog, which) -> {
                    which = ((AlertDialog) dialog).getListView().getCheckedItemPosition();
                    if (which == -1) {
                        which = 0;
                    }
                    challengedTier = standings.get(which).tier;
                    showDialog(ChatDialog.ChallengeMode.ordinal());
                    removeDialog(id);
                })
                        .setNegativeButton(R.string.title_back_button, (dialog, which) -> removeDialog(id))
                        .setOnCancelListener(dialog -> removeDialog(id))
                        .setTitle("Select tier");
                return builder.create();
            }
            case ChallengeMode: {
                Clauses[] clauses = Clauses.values();
                int numClauses = clauses.length;
                boolean[] checked = new boolean[numClauses];
                for (int i = 0; i < numClauses; i++) {
                    checked[i] = prefs.getBoolean("challengeOption" + i, false);
                }
                View layout = inflater.inflate(R.layout.challenge_mode, findViewById(R.id.challenge_mode));
                builder.setView(layout);
                ((Spinner) layout.findViewById(R.id.battle_modes)).setSelection(prefs.getInt("battleMode", Mode.Singles.ordinal()));

                ListView clausesList;
                ClausesListAdapter clausesAdapter;
                clausesList = layout.findViewById(R.id.clauses);

                clausesAdapter = new ClausesListAdapter();
                for (int i = 0; i < clausesAdapter.getCount(); i++) {
                    clausesAdapter.setChecked(i, checked[i]);
                }

                clausesList.setAdapter(clausesAdapter);

                clausesList.setOnItemClickListener((arg0, arg1, arg2, arg3) -> {
                    CheckBox check = arg1.findViewById(R.id.clausecheck);
                    check.toggle();
                    prefs.edit().putBoolean("challengeOption" + arg2, check.isChecked()).apply();
                });

                builder.setPositiveButton(R.string.challenge, (dialog, which) -> {
                    prefs.edit().putInt("battleMode", ((Spinner) layout.findViewById(R.id.battle_modes)).getSelectedItemPosition()).apply();
                    int clauses1 = 0;
                    for (int i = 0; i < numClauses; i++) {
                        clauses1 |= (prefs.getBoolean("challengeOption" + i, false)
                                ? Clauses.values()[i].mask()
                                : 0);
                    }
                    if (connected/*netServ != null && netServ.socket != null && netServ.socket.isConnected()*/) {
                        ArrayList<TierStanding> standings = netServ.me.tierStandings;
                        netServ.socket.sendMessage(constructChallenge(ChallengeDesc.Sent.ordinal(),
                                lastClickedPlayer.id,
                                0,
                                standings.get(0).tier,
                                challengedTier,
                                clauses1,
                                prefs.getInt("battleMode", Mode.Singles.ordinal())), Command.ChallengeStuff);
                    }
                    removeDialog(id);
                })
                        .setNegativeButton(R.string.title_back_button, (dialog, which) -> removeDialog(id))
                        .setOnCancelListener(dialog -> removeDialog(id))
                        .setTitle("Select clauses");
                return builder.create();
            }
            case LoadTeam: {
                CharSequence[] teams = getSharedPreferences("team", 0).getString("files", "team.xml").split("\\|");
                builder.setTitle("Load Team")
                        .setItems(teams, (dialog, which) -> {
                            CharSequence selectedTeam = teams[which];
                            netServ.changeTeam(selectedTeam.toString());
                        })
                        .setOnCancelListener(dialog -> removeDialog(id));
                return builder.create();
            }
            case ControlPanel: {
                View layout = inflater.inflate(R.layout.control_panel_layout, findViewById(R.id.control_panel_layout));
                EditText searchEdit = layout.findViewById(R.id.search_edit);

                TextView status = layout.findViewById(R.id.status_text);
                TextView auth = layout.findViewById(R.id.auth_text);
                TextView ip = layout.findViewById(R.id.ip_text);
                TextView seen = layout.findViewById(R.id.last_seen_text);
                ListView aliases = layout.findViewById(R.id.alias_list);

                ArrayAdapter<String> aliasesAdapter = new ArrayAdapter<>(this, R.layout.alias_item, R.id.alias_text);
                aliases.setAdapter(aliasesAdapter);

                Button kick = layout.findViewById(R.id.kick_button);
                kick.setOnClickListener(v -> netServ.playerKick(netServ.getID(searchEdit.getText().toString())));

                Button mute = layout.findViewById(R.id.mute_button);
                mute.setEnabled(false);

                Button temp = layout.findViewById(R.id.temp_button);
                temp.setOnClickListener(v -> {

                });

                Button ban = layout.findViewById(R.id.ban_button);
                ban.setEnabled(netServ.me.auth > 1);

                activeControlPanel = new ControlPanelGroup(searchEdit, status, auth, ip, seen, aliases, aliasesAdapter, kick, mute, temp, ban);

                searchEdit.setText(controlUser);

                Button search = layout.findViewById(R.id.search_button);
                search.setOnClickListener(v -> netServ.requestUserInfo(searchEdit.getText().toString()));

                if (!"".equals(controlUser)) {
                    netServ.requestUserInfo(searchEdit.getText().toString());
                }

                builder.setOnCancelListener(dialog -> removeDialog(id));

                builder.setView(layout);
                return builder.create();
            }
            case ViewRanking: {
                View layout = inflater.inflate(R.layout.ranking_layout, findViewById(R.id.ranking_layout));

                ListView list = layout.findViewById(R.id.ranking_list);
                ViewRankingAdapter adapter = new ViewRankingAdapter(this, R.layout.row_rank, lastClickedPlayer.nick());
                list.setAdapter(adapter);

                EditText editRankerName = layout.findViewById(R.id.editRankerName);
                AutoCompleteTextView editRankerTier = layout.findViewById(R.id.editRankerTier);

                Button buttonLeft = layout.findViewById(R.id.buttonLeft);
                Button buttonRight = layout.findViewById(R.id.buttonRight);
                TextView currentPage = layout.findViewById(R.id.current_page);
                Button searchButton = layout.findViewById(R.id.rank_search_button);

                activeViewRanking = new ViewRankingGroup(editRankerName, editRankerTier, buttonLeft, buttonRight, currentPage, searchButton, list, adapter);

                editRankerName.setText(lastClickedPlayer.nick());
                editRankerTier.setText(lastClickedPlayer.tierStandings.get(0).tier);

                activeViewRanking.setupButton(netServ);
                netServ.requestRanking(editRankerTier.getText().toString(), editRankerName.getText().toString());

                Set<String> set = getSharedPreferences("tiers", Context.MODE_PRIVATE).getStringSet("list", null);

                if (set != null) {
                    editRankerTier.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_dropdown_item_1line, set.toArray(new String[0])));
                }

                builder.setOnCancelListener(dialog -> removeDialog(id));

                builder.setView(layout);
                return builder.create();
            }
            default: {
                return new Dialog(this);
            }
        }
    }

    private Baos constructFindBattle(boolean forceRated, boolean forceSameTier,
                                     boolean onlyInRange, int range) {
        Baos find = new Baos();
        find.putFlags(new boolean[]{onlyInRange, false});
        find.putFlags(new boolean[]{forceRated, forceSameTier});
        if (onlyInRange) {
            find.putShort((short) range);
        }
        return find;
    }

    public void updateTitle() {
        runOnUiThread(() -> {
            if (!TextUtils.isEmpty(netServ.serverName)) {
                setTitle(netServ.serverName);
            }
        });
    }

    public synchronized void updateChat() {
        if (messageAdapter == null) {
            return;
        }
        int delta = messageAdapter.channel.lastSeen - messageAdapter.lastSeen;
        if (delta <= 0) {
            return;
        }
        Runnable update = new Runnable() {
            @Override
            public void run() {
                LinkedList<SpannableStringBuilder> msgList = messageAdapter.channel.messageList;
                int top = messageAdapter.channel.messageList.size() - delta;
                ListIterator<SpannableStringBuilder> it = msgList.listIterator(
                        Math.min(top, Channel.HIST_LIMIT));
                while (it.hasNext()) {
                    SpannableStringBuilder next = it.next();
                    messageAdapter.add(next);
                    messageAdapter.lastSeen++;
                }
                messageAdapter.notifyDataSetChanged();
                int position = chatView.getLastVisiblePosition();
                // Floor
                cancelScroll = (position + 3 < top);
                if (!cancelScroll) {
                    if (position + delta == top || !hasWindowFocus()) {
                        chatView.setSelection(messageAdapter.getCount() - 1);
                    }
                }
                chatViewSwitcher.getViewTreeObserver().addOnGlobalLayoutListener(new OnGlobalLayoutListener() {
                    @Override
                    public void onGlobalLayout() {
                        chatViewSwitcher.getViewTreeObserver().removeOnGlobalLayoutListener(this);
                        int heightDiff = chatViewSwitcher.getRootView().getHeight() - chatViewSwitcher.getHeight();
                        if (!cancelScroll) {
                            if (heightDiff > 100) { // if more than 100 pixels, its probably a keyboard...
                                chatView.setSelection(messageAdapter.getCount() - 1);
                            }
                        }
                    }
                });

                synchronized (this) {
                    notify();
                }
            }
        };

        synchronized (update) {
            runOnUiThread(update);
            try {
                update.wait();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    public void notifyChannelList() {
        runOnUiThread(() -> channelAdapter.notifyDataSetChanged());
    }

    public void notifyChallenge() {
        runOnUiThread(this::checkChallenges);
    }

    public void notifyAskForPass() {
        runOnUiThread(this::checkAskForPass);
    }

    public void notifyAskForServerPass() {
        runOnUiThread(this::checkAskForServerPass);
    }

    public void notifyFailedConnection() {
        disconnect();
    }

    public void makeToast(String s, String length) {
        if ("long".equals(length)) {
            runOnUiThread(() -> Toast.makeText(ChatActivity.this, s, Toast.LENGTH_LONG).show());
        } else if ("short".equals(length)) {
            runOnUiThread(() -> Toast.makeText(ChatActivity.this, s, Toast.LENGTH_SHORT).show());
        }
    }

    public void removePlayer(PlayerInfo pi) {
        synchronized (players) {
            if (players.isPressed()) {
                try {
                    players.wait();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }
        runOnUiThread(() -> {
            synchronized (playerAdapter) {
                playerAdapter.remove(pi);
            }
        });
    }

    public void addPlayer(PlayerInfo pi) {
        synchronized (players) {
            if (players.isPressed()) {
                try {
                    players.wait();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }
        runOnUiThread(() -> {
            synchronized (playerAdapter) {
                playerAdapter.add(pi);
            }
        });
    }

    public void updatePlayer(PlayerInfo newPlayer, PlayerInfo oldPlayer) {
        runOnUiThread(() -> {
            synchronized (playerAdapter) {
                if (playerAdapter.getPosition(oldPlayer) != -1) {
                    playerAdapter.remove(oldPlayer);
                    playerAdapter.add(newPlayer);
                    playerAdapter.notifyDataSetChanged();
                }
            }
        });
    }

    public void removeChannel(Channel ch) {
        runOnUiThread(() -> channelAdapter.removeChannel(ch));
    }

//	private Drawable getIcon(UniqueID uid) {
//		Resources resources = getResources();
//		int resID = resources.getIdentifier("pi" + uid.pokeNum +
//				(uid.subNum == 0 ? "" : "_" + uid.subNum) +
//				"_icon", "drawable", PACK_NAME);
//		if (resID == 0)
//			resID = resources.getIdentifier("pi" + uid.pokeNum + "_icon",
//					"drawable", PACK_NAME);
//		return resources.getDrawable(resID);
//	}

    public void addChannel(Channel ch) {
        runOnUiThread(() -> channelAdapter.addChannel(ch));
    }

    public void chatAppend(String message) {
        runOnUiThread(() -> {
            String newString = chatInput.getText().toString() + message;
            chatInput.setText(newString);
        });
    }

    public void chatSetMsg(String message) {
        runOnUiThread(() -> chatInput.setText(message));
    }

    public void updateControlPanel(UserInfo info) {
        runOnUiThread(() -> activeControlPanel.setUserInfo(info, netServ));
    }

    public void updateControlPanel(String name) {
        runOnUiThread(() -> activeControlPanel.addAlias(name));
    }

    public void updateViewRanking(int startingPage, int startingRank, int total) {
        runOnUiThread(() -> activeViewRanking.updateViewRanking(startingPage, startingRank, total));
    }

    public void updateViewRanking(String name, int points) {
        runOnUiThread(() -> activeViewRanking.updateViewRanking(name, points));
    }

    private enum ChatDialog {
        Challenge,
        AskForPass,
        ConfirmDisconnect,
        FindBattle,
        TierSelection,
        PlayerInfo,
        ChallengeMode,
        ChooseTierMode,
        AskForName,
        AskForServerPass,
        LoadTeam,
        ControlPanel,
        ViewRanking
    }

    private enum ChatContext {
        ChallengePlayer,
        ViewPlayerInfo,
        JoinChannel,
        LeaveChannel,
        WatchBattle,
        PrivateMessage,
        IgnorePlayer,
        ChannelEvent,
        ViewRanking,
        ControlPanel
    }

    class TierAlertDialog extends AlertDialog {
        public Tier parentTier;
        public ListView dialogListView;

        protected TierAlertDialog(Context context, Tier t) {
            super(context);
            parentTier = t;
            dialogListView = makeTierListView();
            setTitle(getString(R.string.tierSelection)/* "Tier Selection"*/);
            setView(dialogListView);
            setIcon(0); // Don't want an icon
        }

        ListView makeTierListView() {
            ListView lv = new ListView(ChatActivity.this);
            lv.setAdapter(new ArrayAdapter<>(ChatActivity.this, R.layout.tier_list_item, parentTier.subTiers));
            lv.setOnItemClickListener((parent, view, position, id) -> {
                Tier self = parentTier.subTiers.get((int) id);
                if (self.subTiers.size() > 0) {
                    parentTier = self;
                    ((ListView) parent).setAdapter(new ArrayAdapter<>(ChatActivity.this,
                            R.layout.tier_list_item, parentTier.subTiers));
                } else {
                    Baos b = new Baos();
                    b.write(0); //The team for which to change the tier. Since we handle only one team...
                    b.putString(self.name);
                    netServ.socket.sendMessage(b, Command.TierSelection);
                    Toast.makeText(ChatActivity.this, "Tier Selected: " + self.name, Toast.LENGTH_SHORT).show();
                    dismiss();
                }
            });
            return lv;
        }

        @Override
        public void onBackPressed() {
            if (parentTier.parentTier == null) { // this is the top level
                dismiss();
            } else {
                dialogListView.setAdapter(new ArrayAdapter<>(ChatActivity.this, R.layout.tier_list_item, parentTier.parentTier.subTiers));
                parentTier = parentTier.parentTier;
            }
        }
    }

    private class MyAdapter extends PagerAdapter {
        @Override
        public int getCount() {
            return 3;
        }

        @Override
        public Object instantiateItem(ViewGroup container, int position) {
            switch (position) {
                case 0:
                    container.addView(playersLayout);
                    return playersLayout;
                case 1:
                    container.addView(chatLayout);
                    return chatLayout;
                case 2:
                    container.addView(channelsLayout);
                    return channelsLayout;
            }
            return null;
        }

        @Override
        public void destroyItem(ViewGroup container, int position, Object object) {
            container.removeView((View) object);
        }

        @Override
        public boolean isViewFromObject(View arg0, Object arg1) {
            return arg0 == arg1;
        }

        @Override
        public float getPageWidth(int page) {
            if (page == 0 || page == 2) {
                return 0.5f;
            }
            return 1.0f;
        }
    }
}


