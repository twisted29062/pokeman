package com.podevs.android.pokeman.poke;

import com.aggrx.scaffold.AggrxNumbers;
import com.podevs.android.pokeman.pokeinfo.GenInfo;
import com.podevs.android.pokeman.pokeinfo.PokemonInfo;
import com.podevs.android.utilities.PokeStrings;

import org.xml.sax.Attributes;
import org.xml.sax.helpers.DefaultHandler;


public class XMLHandler extends DefaultHandler {
    private boolean inMove  = false;
    private boolean inDV    = false;
    private boolean inEV    = false;
    private int     numPoke = 0;
    private int     numMove = 0;
    private int     numEV   = 0;
    private int     numDV   = 0;
    private Team    myParsedTeam;

    public Team getParsedData() {
        return this.myParsedTeam;
    }

    @Override
    public void startDocument() {
        myParsedTeam = new Team();
    }

    @Override
    public void endDocument() {
        myParsedTeam.runCheck();
    }

    @Override
    public void startElement(String namespaceURI, String localName,
                             String qName, Attributes atts) {
        if ("Team".equals(localName)) {
            myParsedTeam.gen.num = (byte) AggrxNumbers.parseInt(PokeStrings.def(atts.getValue("gen"), String.valueOf(GenInfo.genMax())),0);
            myParsedTeam.gen.subNum = (byte) AggrxNumbers.parseInt(PokeStrings.def(atts.getValue("subgen"), String.valueOf((int) GenInfo.lastGen().subNum)),0);
            myParsedTeam.defaultTier = PokeStrings.def(atts.getValue("defaultTier"), "");

            for (int i = 0; i < 6; i++) {
                myParsedTeam.pokes[i].gen = myParsedTeam.gen;
            }
        } else if ("Pokemon".equals(localName)) {
            TeamPoke poke = myParsedTeam.pokes[numPoke];

            poke.uID = new UniqueID(AggrxNumbers.parseInt(PokeStrings.def(atts.getValue("Num"), "0"),0),
                AggrxNumbers.parseInt(PokeStrings.def(atts.getValue("Forme"), "0"),0));
            poke.nick = PokeStrings.def(atts.getValue("Nickname"), PokemonInfo.name(poke.uID));
            poke.item = (short) AggrxNumbers.parseInt(PokeStrings.def(atts.getValue("Item"), "0"),0);

            poke.ability = (short) AggrxNumbers.parseInt(PokeStrings.def(atts.getValue("Ability"), "0"),0);
            poke.nature = (byte) AggrxNumbers.parseInt(PokeStrings.def(atts.getValue("Nature"), "0"),0);
            poke.hiddenPowerType = (byte) AggrxNumbers.parseInt(PokeStrings.def(atts.getValue("HiddenPower"), "16"),0);
            poke.gender = (byte) AggrxNumbers.parseInt(PokeStrings.def(atts.getValue("Gender"), "0"),0);
            poke.shiny = AggrxNumbers.parseInt(PokeStrings.def(atts.getValue("Shiny"), "0"),0) != 0;
            poke.happiness = (byte) AggrxNumbers.parseInt(PokeStrings.def(atts.getValue("Happiness"), "0"),0);
            poke.level = (byte) AggrxNumbers.parseInt(PokeStrings.def(atts.getValue("Lvl"), "0"),0);
            poke.isHackmon = AggrxNumbers.parseInt(PokeStrings.def(atts.getValue("Hackmon"), "0"),0) != 0;
        } else if ("Move".equals(localName)) {
            inMove = true;
        } else if ("DV".equals(localName)) {
            inDV = true;
        } else if ("EV".equals(localName)) {
            inEV = true;
        }
    }

    @Override
    public void endElement(String namespaceURI, String localName, String qName) {
        if ("Pokemon".equals(localName)) {
            if (numPoke != 5) {
                numPoke++;
            }
        }
        if ("Move".equals(localName)) {
            inMove = false;
            if (numMove != 3) {
                numMove++;
            } else {
                numMove = 0;
            }
        }
        if ("DV".equals(localName)) {
            inDV = false;
            if (numDV != 5) {
                numDV++;
            } else {
                numDV = 0;
            }
        }
        if ("EV".equals(localName)) {
            inEV = false;
            if (numEV != 5) {
                numEV++;
            } else {
                numEV = 0;
            }
        }
    }

    @Override
    public void characters(char[] ch, int start, int length) {
        int parseInt = AggrxNumbers.parseInt(new String(ch, start, length),0);
        TeamPoke poke = myParsedTeam.pokes[numPoke];
        if (inMove) {
            poke.moves[numMove].num = (short) parseInt;
        } else if (inDV) {
            poke.DVs[numDV] = (byte) parseInt;
        } else if (inEV) {
            poke.EVs[numEV] = (byte) parseInt;
        }
    }
}