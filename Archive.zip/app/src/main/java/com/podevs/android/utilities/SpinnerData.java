package com.podevs.android.utilities;

/**
 * Object for Item Spinner
 */
public class SpinnerData {
    public final CharSequence text;
    public final int          key;

    public SpinnerData(CharSequence text, int key) {
        this.text = text;
        this.key = key;
    }
}
