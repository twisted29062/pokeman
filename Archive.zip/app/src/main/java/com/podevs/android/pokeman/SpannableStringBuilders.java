package com.podevs.android.pokeman;

import android.text.Spannable;
import android.text.SpannableStringBuilder;

public class SpannableStringBuilders {
    public static void setSpan(SpannableStringBuilder builder, Object what, int start, int end, int flags) {
        if (flags == Spannable.SPAN_EXCLUSIVE_EXCLUSIVE) {
            if (start >= end) {
                return;
            }
        }
        builder.setSpan(what, start, end, flags);
    }
}
