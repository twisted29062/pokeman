package com.podevs.android.pokeman.teambuilder;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.databinding.DataBindingUtil;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.RecyclerView;

import com.aggrx.scaffold.AggrxCast;
import com.aggrx.scaffold.AggrxLists;
import com.aggrx.scaffold.AggrxRecyclerUtil;
import com.jx.scaffold.JxLogger;
import com.podevs.android.pokeman.R;
import com.podevs.android.pokeman.databinding.PokeinlistItemBinding;
import com.podevs.android.pokeman.poke.Gen;
import com.podevs.android.pokeman.poke.TeamPoke;
import com.podevs.android.pokeman.poke.UniqueID;
import com.podevs.android.pokeman.pokeinfo.PokemonInfo;
import com.podevs.android.pokeman.pokeinfo.TypeInfo;

import java.util.List;

public class PokemonChooserFragment extends Fragment {
    UniqueID chosenId = null;
    RecyclerView pokeList = null;
    String nick = null;
    PokemonChooserListener listener = null;
    TextView poke_choice_search_textView = null;
    Gen gen = null;
    ArrayAdapter<String> poke_choice_search_adapter = null;
    PokeListAdapter pokeListAdapter = null;
    private AggrxRecyclerUtil.Recycler<PokemonViewModel> recycler;
    private List<Pokemon> ids;

    static class Pokemon {
        final String name;
        final int type1;
        final int type2;

        final UniqueID uniqueID;

        Pokemon(UniqueID uniqueID, Gen gen) {
            this.uniqueID = uniqueID;
            name = PokemonInfo.name(uniqueID);
            type1 = PokemonInfo.type1(uniqueID, gen.num);
            type2 = PokemonInfo.type2(uniqueID, gen.num);
        }
    }

    static class PokemonViewModel extends AggrxRecyclerUtil.ListViewModel {
        static PokemonViewModel of(Pokemon pokemon, AggrxRecyclerUtil.ItemOnClickListener<PokemonViewModel> itemOnClickListener) {
            PokemonViewModel model = new PokemonViewModel();
            model.pokemon = pokemon;
            model.itemOnClickListener = itemOnClickListener;
            return model;
        }

        Pokemon pokemon;
        AggrxRecyclerUtil.ItemOnClickListener<PokemonViewModel> itemOnClickListener;

        @Override
        public int layoutResId() {
            return R.layout.pokeinlist_item;
        }

        @Override
        public AggrxRecyclerUtil.ViewBindings createViewBinding(@NonNull AggrxRecyclerUtil.ViewHolder<? extends AggrxRecyclerUtil.ViewModel> itemViewHolder) {
            return AggrxRecyclerUtil.ViewBindings.of(DataBindingUtil.bind(itemViewHolder.itemView), (views, viewHolder) -> {
                PokemonViewModel viewModel = viewHolder.get(PokemonViewModel.class);
                PokeinlistItemBinding binding = views.get(PokeinlistItemBinding.class);
                if (viewModel == null || binding == null) {
                    return;
                }
                Pokemon pokemon = viewModel.pokemon;
                //views.bind(PokeinlistItemBinding.class, binding -> {
                int position = viewHolder.getBindingAdapterPosition();

                viewHolder.itemView.setOnClickListener(v -> itemOnClickListener.onClick(viewModel, position, v, -1, null));

                binding.image.setImageDrawable(PokemonInfo.iconDrawable(pokemon.uniqueID));

                String name = pokemon.name;
                if (TextUtils.isEmpty(name)) {
                    JxLogger.w("can not get name %s", pokemon);
                }
                binding.pokeName.setText(name);

                int type1 = pokemon.type1;
                if (type1 == -1) {
                    JxLogger.w("get type 1 image failed. %s", pokemon);
                }
                binding.type1.setImageResource(TypeInfo.typeRes(type1));

                int type2 = pokemon.type2;
                if (type2 == -1) {
                    JxLogger.w("get type 2 image failed. %s", pokemon);
                }

                binding.type2.setImageResource(TypeInfo.typeRes(type2));
                binding.type2.setVisibility(type2 == TypeInfo.Type.Curse.ordinal() ? View.INVISIBLE : View.VISIBLE);
                //}, () -> {

                //});
            });
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.pokemon_chooser_fragment, container, false);
        FragmentActivity activity = getActivity();
        if (activity == null) {
            return v;
        }

        gen = poke().gen;
        pokeList = v.findViewById(R.id.pokeList);

        recycler = AggrxRecyclerUtil.Recycler.verticalList(pokeList);

        // prepare data
        ids = AggrxLists.map(PokemonInfo.ids(gen), (item, index, list) -> new Pokemon(item, gen),null);
        List<PokemonViewModel> viewModels = buildPokemonViewModels(this.ids);

        recycler.adapter().setData(viewModels);
        recycler.adapter().notifyDataSetChanged();

        //pokeList.setAdapter(pokeListAdapter = new PokeListAdapter(gen));

        poke_choice_search_textView = v.findViewById(R.id.pokemon_choice_search);

        poke_choice_search_textView.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                String keyword = s.toString();
                List<PokemonViewModel> viewModels;
                if (TextUtils.isEmpty(keyword)) {
                    viewModels = buildPokemonViewModels(ids);
                } else {
                    List<Pokemon> filtered = AggrxLists.map(ids, (item, index, list) -> {
                        if (item.name.contains(keyword)) {
                            return item;
                        }
                        return null;
                    }, (item) -> item != null);
                    viewModels = buildPokemonViewModels(filtered);
                }

                recycler.adapter().setData(viewModels);
                recycler.adapter().notifyDataSetChanged();
            }
        });

//        poke_choice_search_adapter = new ArrayAdapter<>(activity, android.R.layout.simple_dropdown_item_1line, PokemonInfo.nameArray(gen));
//        poke_choice_search_textView.setAdapter(poke_choice_search_adapter);
//
//        poke_choice_search_textView.setOnItemClickListener((arg0, arg1, arg2, arg3) -> {
//            String name = poke_choice_search_adapter.getItem(arg2);
//            chosenId = PokemonInfo.number(name);
//            updateList();
//        });

//        pokeList.setOnItemClickListener((arg0, arg1, arg2, arg3) -> {
//            chosenId = new UniqueID(arg2, 0);
//            poke_choice_search_textView.setText(PokemonInfo.name(chosenId));
//            /* We already set a completed item, no need for the dropdown to show */
//            poke_choice_search_textView.dismissDropDown();
//        });

        Button ok = v.findViewById(R.id.ok);
        ok.setOnClickListener(v1 -> {
            if (listener != null && chosenId != null) {
                String nick = poke_choice_search_textView.getText().toString();

                if (nick.length() == 0) {
                    nick = PokemonInfo.name(chosenId);
                }

                listener.onPokemonChosen(chosenId, nick);
            }
        });

        if (nick != null) {
            setDetails(chosenId, nick);
            nick = null;
        }

        return v;
    }

    @NonNull
    private List<PokemonViewModel> buildPokemonViewModels(List<Pokemon> pokemons) {
        return AggrxLists.map(pokemons, (item, index, list) -> PokemonViewModel.of(item, (viewModel, position, itemView, subPosition, subView) -> {
            chosenId = viewModel.pokemon.uniqueID;
            poke_choice_search_textView.setText(PokemonInfo.name(chosenId));
            /* We already set a completed item, no need for the dropdown to show */
            // poke_choice_search_textView.dismissDropDown();
        }));
    }

    protected void setDetails(UniqueID number, String nick) {
        chosenId = number;


        if (poke_choice_search_textView != null) {
            if (number.main != 0 && number.sub != 0) {
                poke_choice_search_textView.setText(nick);
            }
            // poke_choice_search_textView.dismissDropDown();
            updateList();
        } else {
            this.nick = nick;
        }
    }

    protected void updateList() {
        // pokeList.setSelection(chosenId.mainNum);
    }

    @Override
    public void onPause() {
        super.onPause();
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();

        JxLogger.w("onDestroyView");
    }

    public TeamPoke poke() {
        EditPokemonActivity activity = AggrxCast.cast(getActivity(), EditPokemonActivity.class);
        if (activity != null)
            return activity.getPoke();
        return null;
    }

    public void setGen(Gen gen) {
        if (gen.equals(this.gen)) {
            return;
        }
        this.gen = gen;

        ids = AggrxLists.map(PokemonInfo.ids(gen), (item, index, list) -> new Pokemon(item, gen));
        List<PokemonViewModel> viewModels = buildPokemonViewModels(this.ids);

        recycler.adapter().setData(viewModels);
        recycler.adapter().notifyDataSetChanged();

        // pokeListAdapter.setGen(gen);
        // FragmentActivity activity = getActivity();
        // if (activity == null) {
        //    return;
        // }
        // poke_choice_search_adapter = new ArrayAdapter<>(activity, android.R.layout.simple_dropdown_item_1line, PokemonInfo.nameArray(gen));
        // poke_choice_search_textView.setAdapter(poke_choice_search_adapter);
    }

    public void setOnPokemonChosenListener(PokemonChooserListener listener) {
        this.listener = listener;
    }

    public interface PokemonChooserListener {
        void onPokemonChosen(UniqueID id, String nickname);
    }
}
