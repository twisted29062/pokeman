package com.podevs.android.pokeman.pokeinfo;

import android.util.SparseArray;

import com.podevs.android.pokeman.poke.UniqueID;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Fill SparseArrays involving names
 */

class PokemonModels {
    public enum Target {
        ChosenTarget, //0
        PartnerOrUser, //1
        Partner, //2
        MeFirstTarget, //3
        AllButSelf, //4
        Opponents, //5
        TeamParty, //6
        User, //7
        All, //8
        RandomTarget, //9
        Field, //10
        OpposingTeam, //11
        TeamSide, //12
        IndeterminateTarget //13
    }

    static class Pokemon {
        UniqueID id;
        String name = "";
        byte gender = 0;
        PokemonInfo.PokemonExtraData extraData = new PokemonInfo.PokemonExtraData();
    }

    static class PokemonX {
        final int main;
        Map<String, Pokemon> forms = new HashMap<>();

        PokemonX(int main) {
            this.main = main;
        }
    }

    /**
     * 游戏主版本
     */
    static class Generation {
        String name;
        int main;
        final Map<String, GenerationVersion> subGenerations = new HashMap<>();
        final List<Integer> usefulItems = new ArrayList<>();
        Short[] allMoves = new Short[0];
        Map<String, PokemonInfo.PokemonData> dataMap = new HashMap<>();
        byte[][] effectiveness = new byte[TypeInfo.Type.values().length][TypeInfo.Type.values().length];
    }

    /**
     * 游戏次版本
     */
    static class GenerationVersion {
        UniqueID id;
        final String name;

        GenerationVersion(UniqueID id, String name) {
            this.id = id;
            this.name = name;
        }
    }

    static class Item {
        int id;
        String message;
        String name;
    }

    static class MoveInfo {
        int id;
        String name;
        String message;

        SparseArray<Byte> damageClass = new SparseArray<>()/*0*/;
        SparseArray<Byte> type = new SparseArray<>()/*0*/;
        SparseArray<Byte> pp = new SparseArray<>()/*5*/;
        SparseArray<Byte> accuracy = new SparseArray<>()/*0*/;
        SparseArray<Byte> power = new SparseArray<>()/*0*/;
        SparseArray<Byte> zpower = new SparseArray<>()/*0*/;
        SparseArray<Integer> flags = new SparseArray<>() /*0*/;
        SparseArray<String> effect = new SparseArray<>()/*null*/;
        SparseArray<String> zeffect = new SparseArray<>()/*null*/;
        SparseArray<Target> range = new SparseArray<>() /*Target.ChosenTarget*/;
    }

    static class Ability {
        int id;
        String name;
        String desc;
    }
}
