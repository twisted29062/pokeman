package com.podevs.android.pokeman.pokeinfo;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;

import androidx.annotation.ColorRes;
import androidx.annotation.StringRes;
import androidx.core.content.ContextCompat;

import com.aggrx.scaffold.AggrxFiles;
import com.aggrx.scaffold.AggrxInterfaces;
import com.jx.scaffold.JxFileUtils;
import com.jx.scaffold.JxLogger;

import java.io.InputStream;

/**
 * @author blox
 */
public class InfoConfig {
    final public static String PKG_NAME = "com.podevs.android.poAndroid";
    @SuppressLint("StaticFieldLeak")
    static public Context context = null;
    static private Resources resources = null;

    public static void setContext(Context ctx) {
        context = ctx;
        resources = ctx.getResources();
    }

    public static int getColor(@ColorRes int id) {
        return ContextCompat.getColor(context, id);
    }

    static String getString(@StringRes int id) {
        return resources.getString(id);
    }

    public static int getIdentifier(String name, String defType) {
        int id = resources.getIdentifier(name, defType, PKG_NAME);
        if (id == 0) {
            JxLogger.e(new Exception(), "Invalid resource %s %s", name, defType);
        }
        return id;
    }

    @SuppressLint("UseCompatLoadingForDrawables")
    public static Drawable getDrawable(int id) {
        return ContextCompat.getDrawable(context, id);
    }

    static boolean fileExists(String path) {
        if (context != null) {
            try {
                context.getResources().getAssets().open(path).close();
                return true;
            } catch (Exception e) {
                return false;
            }
        }
        return false;
    }

    public static Drawable getAssetDrawable(String path, Drawable defaultValue) {
        return AggrxFiles.createDrawable(context, path, defaultValue);
    }

    public static void stream(String path, InputStream defaultVale, AggrxInterfaces.VoidAction1<InputStream> success, AggrxInterfaces.VoidAction1<InputStream> failed) {
        JxFileUtils.assertStream(context, path, success, throwable -> failed.action(defaultVale));
    }
}
