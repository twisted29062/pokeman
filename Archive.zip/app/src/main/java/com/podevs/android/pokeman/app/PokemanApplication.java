package com.podevs.android.pokeman.app;

import androidx.multidex.MultiDexApplication;

import com.aggrx.scaffold.AggrxSharedApplication;
import com.jx.scaffold.JxLogger;
import com.podevs.android.pokeman.BuildConfig;
import com.podevs.android.pokeman.permission.EasyPermissions;
import com.podevs.android.pokeman.pokeinfo.InfoConfig;
import com.podevs.android.pokeman.pokeinfo.PokemonStorage;

public class PokemanApplication extends MultiDexApplication {
    private static PokemanApplication instance;

    public static PokemanApplication getInstance() {
        return instance;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        instance = this;
        InfoConfig.setContext(this);
        AggrxSharedApplication.initialize(this);

        // PokemonStorage.load();

        installDevelopTools();

        if (EasyPermissions.hasPermissions(this, EasyPermissions.MUST_PERMISSIONS)) {
            JxLogger.i("got permission");
        } else {
            JxLogger.w("not permission");
        }
        onCreateWithPermission();
    }

    private void installDevelopTools() {
        if (!BuildConfig.DEBUG) {
            return;
        }

//        if (FlipperUtils.shouldEnableFlipper(this)) {
//            FlipperClient     client            = AndroidFlipperClient.getInstance(this);
//            DescriptorMapping descriptorMapping = DescriptorMapping.withDefaults();
//            LithoFlipperDescriptors.add(descriptorMapping);
//            client.addPlugin(new InspectorFlipperPlugin(this, descriptorMapping));
//            client.start();
//        }

//        if (LeakCanary.isInAnalyzerProcess(this)) {
//            // This process is dedicated to LeakCanary for heap analysis.
//            // You should not init your app in this process.
//            return;
//        }

        // Takt.stock(this).color(Color.RED);
        // BlockCanary.install(this, new AppBlockCanaryContext(this)).start();
        // LeakCanary.install(this);

//        StrictMode.setThreadPolicy(
//            new StrictMode.ThreadPolicy.Builder().detectAll()
//                .penaltyLog().build());
//        StrictMode.setVmPolicy(
//            new StrictMode.VmPolicy.Builder().detectAll()
//                .penaltyLog().build());

    }

    private void onCreateWithPermission() {
//        AppInfo.initialize(getApplicationContext());
//        Retrofits.initialize(getApplicationContext());
//        InitFetcher.fetch(new JxFunc.Action<Fetcher.Result<InitFetcher.Response, Object>>() {
//            @Override public void yield(@NonNull Fetcher.Result<InitFetcher.Response, Object> value) {
//
//            }
//        });
    }
}
