package com.podevs.android.pokeman.teambuilder;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.fragment.app.Fragment;

import com.podevs.android.pokeman.R;
import com.podevs.android.pokeman.battle.ListedPokemon;
import com.podevs.android.pokeman.poke.Team;
import com.podevs.android.pokeman.pokeinfo.InfoConfig;
import com.podevs.android.pokeman.pokeinfo.ItemInfo;
import com.podevs.android.pokeman.pokeinfo.MoveInfo;

public class TeamFragment extends Fragment {
    final ListedPokemon[] pokeList = new ListedPokemon[6];

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.battle_teamscreen, container, false);

        for (int i = 0; i < 6; i++) {
            ViewGroup whole = v.findViewById(
                InfoConfig.getIdentifier("pokeViewLayout" + (i + 1), "id"));
            pokeList[i] = new ListedPokemon(whole);
            whole.setTag(R.id.poke, i);

            whole.setOnClickListener(v1 -> {
                Object tag = v1.getTag(R.id.poke);

                if (tag != null) {
                    int pos = ((Integer) tag);
                    activity().editPoke(pos);
                }
            });
        }
        updateTeam();

        return v;
    }

    @Override
    public void onPause() {
        super.onPause();
    }

    public void updateTeam() {
        Team team = activity().team;
        MoveInfo.forceSetGen(team.gen.num, team.gen.subNum);
        ItemInfo.setGeneration(team.gen.num);
        for (int i = 0; i < 6; i++) {
            pokeList[i].update(team.poke(i), true);
        }
    }

    private TeamCreatorActivity activity() {
        return (TeamCreatorActivity) getActivity();
    }

}
