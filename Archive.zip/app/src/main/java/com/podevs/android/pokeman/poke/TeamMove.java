package com.podevs.android.pokeman.poke;

import com.podevs.android.pokeman.pokeinfo.MoveInfo;

import org.w3c.dom.Element;

public class TeamMove implements Move {
    short num;

    public TeamMove(int i) {
        num = (short) i;
    }

    @Override public int num() {
        return num;
    }

    @Override public String toString() {
        return MoveInfo.name(num);
    }

    public void save(Element move) {
        move.setTextContent(String.valueOf(num));
    }
}
