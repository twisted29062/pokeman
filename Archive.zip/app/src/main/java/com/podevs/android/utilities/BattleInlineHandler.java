package com.podevs.android.utilities;

import android.graphics.Color;
import android.text.Editable;
import android.text.Html;
import android.text.Spannable;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.style.BackgroundColorSpan;
import android.text.style.ClickableSpan;
import android.text.style.StrikethroughSpan;
import android.view.View;

import androidx.annotation.NonNull;

import com.aggrx.scaffold.AggrxNumbers;
import com.jx.scaffold.JxLogger;
import com.podevs.android.pokeman.Command;
import com.podevs.android.pokeman.NetworkService;
import com.podevs.android.pokeman.chat.Channel;

import org.xml.sax.XMLReader;

import java.lang.reflect.Field;
import java.util.HashMap;

@Deprecated
public class BattleInlineHandler implements Html.TagHandler {
    public Channel currentChannel;
    private final NetworkService netServ;
    private final HashMap<String, String> attributes = new HashMap<>();

    public BattleInlineHandler(NetworkService service) {
        netServ = service;
    }

    @Override
    public void handleTag(boolean opening, String tag, Editable output, XMLReader xmlReader) {
        if ("watch".equalsIgnoreCase(tag)) {
            if (opening) {
                // Opening Tag
                attributes.clear();
                try {
                    getAttributes(xmlReader);

                    String stringid = attributes.get("id");
                    if (stringid != null) {
                        int id = AggrxNumbers.parseInt(stringid, 0);

                        start((SpannableStringBuilder) output, spectateSpan(id));
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            } else {
                // Closing Tag
                String stringId = attributes.get("id");
                if (stringId != null) {
                    try {
                        int id = AggrxNumbers.parseInt(stringId, 0);
                        end((SpannableStringBuilder) output, ClickableSpan.class, spectateSpan(id));
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }
        } else if ("ping".equalsIgnoreCase(tag)) {
            if (opening && currentChannel != null) {
                JxLogger.e("Attempt flash");
                netServ.tryFlashChannel(currentChannel);
            }
        } else if ("background".equalsIgnoreCase(tag)) {
            try {
                if (opening) {
                    attributes.clear();

                    getAttributes(xmlReader);

                    String stringColor = attributes.get("color");
                    if (stringColor != null) {
                        int color = Color.parseColor(stringColor);

                        start((SpannableStringBuilder) output, backgroundColor(color));
                    }
                } else {
                    String stringColor = attributes.get("color");
                    if (stringColor != null) {
                        int color = Color.parseColor(stringColor);

                        end((SpannableStringBuilder) output, BackgroundColorSpan.class, backgroundColor(color));
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else if ("timestamp".equalsIgnoreCase(tag)) {
            if (opening) {
                if (netServ.getSettings().timeStamp) {
                    output.append("(").append(PokeStrings.timeStamp()).append(") ");
                }
            }
        } else if ("tr".equalsIgnoreCase(tag)) {
            if (!opening) {
                output.append("\n");
            }
        } else if ("strike".equalsIgnoreCase(tag)) {
            if (opening) {
                start((SpannableStringBuilder) output, new StrikethroughSpan());
            } else {
                end((SpannableStringBuilder) output, StrikethroughSpan.class, new StrikethroughSpan());
            }
        } else if ("posend".equalsIgnoreCase(tag)) {
            if (opening) {
                attributes.clear();

                getAttributes(xmlReader);

                String message = attributes.get("m");
                if (message != null) {
                    start((SpannableStringBuilder) output, poSend(message));
                }
            } else {
                String message = attributes.get("m");
                if (message != null) {
                    end((SpannableStringBuilder) output, ClickableSpan.class, poSend(message));
                }
            }
        } else if ("pojoin".equalsIgnoreCase(tag)) {
            if (opening) {
                attributes.clear();

                getAttributes(xmlReader);

                String message = attributes.get("c");
                if (message != null) {
                    start((SpannableStringBuilder) output, poJoin(message));
                }
            } else {
                String message = attributes.get("c");
                if (message != null) {
                    end((SpannableStringBuilder) output, ClickableSpan.class, poJoin(message));
                }
            }
        } else if ("poappend".equalsIgnoreCase(tag)) {
            if (opening) {
                attributes.clear();

                getAttributes(xmlReader);

                String message = attributes.get("m");
                if (message != null) {
                    start((SpannableStringBuilder) output, poAppend(message));
                }
            } else {
                String message = attributes.get("m");
                if (message != null) {
                    end((SpannableStringBuilder) output, ClickableSpan.class, poAppend(message));
                }
            }
        }
        //JxLogger.e("%s", "Unhandled " + tag);
    }

    private void getAttributes(XMLReader xmlReader) {
        try {
            Field elementField = xmlReader.getClass().getDeclaredField("theNewElement");
            elementField.setAccessible(true);
            Object element = elementField.get(xmlReader);
            if (element == null) return;
            Field attsField = element.getClass().getDeclaredField("theAtts");
            attsField.setAccessible(true);
            Object atts = attsField.get(element);
            if (atts == null) return;
            Field dataField = atts.getClass().getDeclaredField("data");
            dataField.setAccessible(true);
            String[] data = (String[]) dataField.get(atts);
            Field lengthField = atts.getClass().getDeclaredField("length");
            lengthField.setAccessible(true);
            Integer len = (Integer) lengthField.get(atts);

            if (data == null || len == null) {
                return;
            }
            int len2 = len;
            for (int i = 0; i < len2; i++) {
                attributes.put(data[i * 5 + 1], data[i * 5 + 4]);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private BackgroundColorSpan backgroundColor(int color) {
        return new BackgroundColorSpan(color);
    }

    private ClickableSpan poSend(String message) {
        int id = currentChannel.id;
        return new ClickableSpan() {
            @Override
            public void onClick(@NonNull View widget) {
                Baos b = new Baos();
                b.write(1);
                b.write(0);
                b.putInt(id);
                b.putString(message);
                netServ.socket.sendMessage(b, Command.SendMessage);
            }
        };
    }

    private ClickableSpan poJoin(String channel) {
        return new ClickableSpan() {
            @Override
            public void onClick(@NonNull View widget) {
                Baos join = new Baos();
                join.putString(channel);
                if (netServ != null && netServ.socket != null && netServ.socket.isConnected()) {
                    netServ.socket.sendMessage(join, Command.JoinChannel);
                }
            }
        };
    }

    private ClickableSpan poAppend(String message) {
        return new ClickableSpan() {
            @Override
            public void onClick(@NonNull View widget) {
                if (netServ != null && netServ.chatActivity != null) {
                    netServ.chatActivity.chatAppend(message);
                }
            }
        };
    }

    private ClickableSpan spectateSpan(int id) {
        return new ClickableSpan() {
            @Override
            public void onClick(@NonNull View widget) {
                netServ.startWatching(id);
            }
        };
    }

    private static void start(SpannableStringBuilder text, Object mark) {
        int len = text.length();
        text.setSpan(mark, len, len, Spannable.SPAN_MARK_MARK);
    }

    private static void end(SpannableStringBuilder text, Class kind, Object repl) {
        int len = text.length();
        Object object = getLast(text, kind);
        int where = text.getSpanStart(object);

        text.removeSpan(object);

        if (where != len && len > 0) {
            text.setSpan(repl, where, len, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        }
    }

    private static Object getLast(Spanned text, Class kind) {
        Object[] objects = text.getSpans(0, text.length(), kind);

        if (objects.length == 0) {
            return null;
        } else {
            return objects[objects.length - 1];
        }
    }
}
