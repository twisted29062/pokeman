package com.podevs.android.pokeman.chat;

import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import com.podevs.android.pokeman.NetworkService;

public class ViewRankingGroup {
    final EditText editRankerName;
    final EditText editRankerTier;

    final Button   buttonLeft;
    final Button   buttonRight;
    final TextView currentPage;
    final Button   searchButton;

    final ListView           rankingList;
    final ViewRankingAdapter adapter;

    int currentRank;
    int intCurrentPage;
    int intMaxPage;

    public ViewRankingGroup(EditText editRankerName, EditText editRankerTier, Button buttonLeft, Button buttonRight, TextView currentPage, Button searchButton, ListView rankingList, ViewRankingAdapter adapter) {
        this.editRankerName = editRankerName;
        this.editRankerTier = editRankerTier;
        this.buttonLeft = buttonLeft;
        this.buttonRight = buttonRight;
        this.currentPage = currentPage;
        this.searchButton = searchButton;
        this.rankingList = rankingList;
        this.adapter = adapter;
    }

    public void updateViewRanking(final int startingPage, final int startingRank, final int total) {
        String s = startingPage + "/" + total;
        currentPage.setText(s);
        currentRank = startingRank;

        intCurrentPage = startingPage;
        intMaxPage = total;
    }

    public void updateViewRanking(final String name, final int points) {
        adapter.addRanking(currentRank, name, points);
        currentRank++;
    }

    public void setupButton(final NetworkService netServ) {
        buttonLeft.setOnClickListener(v -> {
            if (intCurrentPage > 1) {
                netServ.requestRanking(editRankerTier.getText().toString(), intCurrentPage - 1);
                adapter.clear();
            }
        });

        buttonRight.setOnClickListener(v -> {
            if (intCurrentPage < intMaxPage) {
                netServ.requestRanking(editRankerTier.getText().toString(), intCurrentPage + 1);
                adapter.clear();
            }
        });
        searchButton.setOnClickListener(v -> {
            netServ.requestRanking(editRankerTier.getText().toString(), editRankerName.getText().toString());
            adapter.clear();
        });
    }
}
