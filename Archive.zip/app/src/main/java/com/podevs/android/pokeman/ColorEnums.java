package com.podevs.android.pokeman;

import com.podevs.android.pokeman.poke.PokeEnums.Status;
import com.podevs.android.pokeman.poke.PokeEnums.Terrain;
import com.podevs.android.pokeman.poke.PokeEnums.Weather;

public class ColorEnums {
    public static String[] defaultPlayerColors = {
        "#5811b1",
        "#399bcd",
        "#0474bb",
        "#f8760d",
        "#a00c9e",
        "#0d762b",
        "#5f4c00",
        "#9a4f6d",
        "#d0990f",
        "#1b1390",
        "#028678",
        "#0324b1"
    };

    public enum QtColor {
        White {
            @Override public String toString() {
                return "#ffffff>";
            }
        },
        Black {
            @Override public String toString() {
                return "#000000>";
            }
        },
        Red {
            @Override public String toString() {
                return "#ff0000>";
            }
        },
        DarkRed {
            @Override public String toString() {
                return "#800000>";
            }
        },
        Green {
            @Override public String toString() {
                return "#00ff00>";
            }
        },
        DarkGreen {
            @Override public String toString() {
                return "#008000>";
            }
        },
        Blue {
            @Override public String toString() {
                return "#0000ff>";
            }
        },
        DarkBlue {
            @Override public String toString() {
                return "#000080>";
            }
        },
        Cyan {
            @Override public String toString() {
                return "#00ffff>";
            }
        },
        DarkCyan {
            @Override public String toString() {
                return "#008080>";
            }
        },
        Magenta {
            @Override public String toString() {
                return "#ff00ff>";
            }
        },
        DarkMagenta {
            @Override public String toString() {
                return "#800080>";
            }
        },
        Yellow {
            @Override public String toString() {
                return "#ffff00>";
            }
        },
        DarkYellow {
            @Override public String toString() {
                return "#808000>";
            }
        },
        Gray {
            @Override public String toString() {
                return "#a0a0a4>";
            }
        },
        DarkGray {
            @Override public String toString() {
                return "#808080>";
            }
        },
        LightGray {
            @Override public String toString() {
                return "#c0c0c0>";
            }
        }
    }

    public enum TypeColor {
        Normal {
            @Override public String toString() {
                return "#a8a878>";
            }
        },
        Fighting {
            @Override public String toString() {
                return "#c03028>";
            }
        },
        Flying {
            @Override public String toString() {
                return "#a890f0>";
            }
        },
        Poison {
            @Override public String toString() {
                return "#a040a0>";
            }
        },
        Ground {
            @Override public String toString() {
                return "#e0c068>";
            }
        },
        Rock {
            @Override public String toString() {
                return "#b8a038>";
            }
        },
        Bug {
            @Override public String toString() {
                return "#a8b820>";
            }
        },
        Ghost {
            @Override public String toString() {
                return "#705898>";
            }
        },
        Steel {
            @Override public String toString() {
                return "#b8b8d0>";
            }
        },
        Fire {
            @Override public String toString() {
                return "#f08030>";
            }
        },
        Water {
            @Override public String toString() {
                return "#6890f0>";
            }
        },
        Grass {
            @Override public String toString() {
                return "#78c850>";
            }
        },
        Electric {
            @Override public String toString() {
                return "#f8d030>";
            }
        },
        Psychic {
            @Override public String toString() {
                return "#f85888>";
            }
        },
        Ice {
            @Override public String toString() {
                return "#98d8d8>";
            }
        },
        Dragon {
            @Override public String toString() {
                return "#7038f8>";
            }
        },
        Dark {
            @Override public String toString() {
                return "#705848>";
            }
        },
        Fairy {
            @Override public String toString() {
                return "#f088f6>";
            }
        },
        Curse {
            @Override public String toString() {
                return "#68a090>";
            }
        }
    }

    public static class StatusColor {
        private static String color;

        public StatusColor(int status) {
            switch (Status.poValues()[status]) {
                case Koed:
                    color = "#171ba>";
                    break;
                case Fine:
                    color = TypeColor.Normal.toString();
                    break;
                case Paralysed:
                    color = TypeColor.Electric.toString();
                    break;
                case Burnt:
                    color = TypeColor.Fire.toString();
                    break;
                case Frozen:
                    color = TypeColor.Ice.toString();
                    break;
                case Asleep:
                    color = TypeColor.Psychic.toString();
                    break;
                case Poisoned:
                    color = TypeColor.Poison.toString();
                    break;
                case Confused:
                    color = TypeColor.Ghost.toString();
                    break;
                default:
                    color = ">";
            }
        }

        @Override public String toString() {
            return color;
        }
    }

    public static class TypeForWeatherColor {
        private static String color;

        public TypeForWeatherColor(int weather) {
            switch (Weather.values()[weather]) {
                case Hail:
                    color = TypeColor.Ice.toString();
                    break;
                case Rain:
                case HeavyRain:
                    color = TypeColor.Water.toString();
                    break;
                case SandStorm:
                    color = TypeColor.Rock.toString();
                    break;
                case Sunny:
                case HeavySun:
                    color = TypeColor.Fire.toString();
                    break;
                case Delta:
                    color = TypeColor.Flying.toString();
                    break;
                default:
                    color = TypeColor.Normal.toString();
                    break;
            }
        }

        @Override public String toString() {
            return color;
        }
    }

    public static class TypeForTerrainColor {
        private static String color;

        public TypeForTerrainColor(int terrain) {
            switch (Terrain.values()[terrain]) {
                case Electric:
                    color = TypeColor.Electric.toString();
                    break;
                case Grassy:
                    color = TypeColor.Grass.toString();
                    break;
                case Misty:
                    color = TypeColor.Fairy.toString();
                    break;
                case Psychic:
                    color = TypeColor.Psychic.toString();
                    break;
                default:
                    color = TypeColor.Normal.toString();
                    break;
            }
        }

        @Override public String toString() {
            return color;
        }
    }
}