package com.podevs.android.pokeman.battle;

import com.podevs.android.pokeman.poke.PokeEnums;
import com.podevs.android.pokeman.poke.PokeEnums.StatusFeeling;
import com.podevs.android.pokeman.poke.PokeEnums.Terrain;
import com.podevs.android.pokeman.poke.PokeEnums.TerrainState;
import com.podevs.android.pokeman.poke.PokeEnums.Weather;
import com.podevs.android.pokeman.poke.PokeEnums.WeatherState;
import com.podevs.android.pokeman.poke.ShallowBattlePoke;
import com.podevs.android.pokeman.poke.UniqueID;
import com.podevs.android.pokeman.pokeinfo.GenInfo;
import com.podevs.android.pokeman.pokeinfo.PokemonInfo;
import com.podevs.android.utilities.ArrayUtilities;
import com.podevs.android.utilities.Bais;

public class Debugger {
    // TODO: BE VERY SAFE

    private final static byte me = 0, opp = 1;
    private final static String sp    = "   ";
    private final static String error = "Error:";

    public static String readablePacket(BattlePacket p) {
        StringBuilder readable = new StringBuilder();
        Bais          msg      = p.msg.cloneRemaining();
        byte          player   = player(p.num);
        byte          slot     = slot(p.num, player);
        readable = new StringBuilder(p.bc.toString());
        switch (p.bc) {
            case SendOut: {
                boolean silent   = msg.readBool();
                byte    fromSpot = msg.readByte();

                readable.append(sp).append(playerSlot(player, slot)).append(" {silent:").append(silent).append(" from:").append(fromSpot).append("}");

                Bais copy = msg.cloneRemaining();
                try {
                    ShallowBattlePoke poke = new ShallowBattlePoke(msg, (player == me), GenInfo.lastGen());
                    poke.pokeName = PokemonInfo.name(poke.uID);
                    readable.append(" ").append(poke.toString());
                } catch (Exception e) {
                    readable.append(" " + error).append(copy.toString());
                }
                break;
            }
            case SendBack:
            case Rated:
            case Recoil:
            case Failed: {
                boolean silent = msg.readBool();
                readable.append(sp).append(silent);
                break;
            }
            case UseAttack: {
                short   attack = msg.readShort();
                boolean silent = msg.readBool();
                readable.append(sp + "{attack:").append(attack).append(" silent:").append(silent).append("}");
                break;
            }
            case BeginTurn: {
                int turn = msg.readInt();
                readable.append(sp).append(turn);
                break;
            }
            case Ko:
            case Flinch:
            case Avoid:
            case Miss:
            case CriticalHit: {
                readable.append(sp).append(playerSlot(player, slot));
                break;
            }
            case Hit:
            case BattleEnd:
            case UseItem:
            case Effective: {
                byte number = msg.readByte();
                readable.append(sp).append(number);
                break;
            }
            case StatChange: {
                byte    stat   = msg.readByte(), boost = msg.readByte();
                boolean silent = msg.readBool();
                readable.append(sp + "{stat:").append(stat).append(" boost:").append(boost).append(" silent:").append(silent).append("}");
                break;
            }
            case CappedStat: {
                byte    stat = msg.readByte();
                boolean max  = msg.readBool();
                readable.append(sp + "{stat:").append(stat).append(" max:").append(max).append("}");
                break;
            }
            case ItemCountChange: {
                byte item  = msg.readByte();
                byte count = msg.readByte();
                readable.append(sp + "{item:").append(item).append(" count:").append(count).append("}");
                break;
            }
            case StatusChange: {
                byte    status        = msg.readByte();
                boolean multipleTurns = msg.readBool();
                boolean silent        = msg.readBool();
                readable.append(sp + "{status:").append(status).append(" mult:").append(multipleTurns).append(" silent:").append(silent).append("}");
                break;
            }
            case AbsStatusChange: {
                byte poke   = msg.readByte();
                byte status = msg.readByte();
                readable.append(sp + "{player:").append(player).append(" poke:").append(poke).append(" count:").append(status).append("}");
                break;
            }
            case AlreadyStatusMessage: {
                byte status = msg.readByte();
                readable.append(sp).append(playerSlot(player, slot)).append(sp).append(status);
                break;
            }
            case StatusMessage: {
                byte          status  = msg.readByte();
                StatusFeeling feeling = StatusFeeling.values()[status];
                readable.append(sp).append(feeling.toString());
                break;
            }
            case BattleChat:
            case SpotShifts:
            case MakeYourChoice:
            case BlankMessage:
            case NoOpponent: {
                break;
            }
            case EndMessage: {
                String message = msg.readString();
                if (message == null || "".equals(message)) {
                    break;
                }
                readable.append(sp).append(message);
                break;
            }
            case Spectating: {
                boolean come = msg.readBool();
                int     id   = msg.readInt();
                String  name = msg.readString();
                readable.append(sp + "{come:").append(come).append(" id:").append(id).append(" name:").append(name).append("}");
                break;
            }
            case SpectatorChat: {
                int    id      = msg.readInt();
                String message = msg.readString();
                readable.append(sp + "{id:").append(id).append(" msg:").append(message).append("}");
                break;
            }
            case MoveMessage: {
                short  move  = msg.readShort();
                byte   part  = msg.readByte();
                byte   type  = msg.readByte();
                byte   foe   = msg.readByte();
                short  other = msg.readShort();
                String q     = msg.readString();

                readable.append(sp + "{move:").append(move).append(" part:").append(part).append(" type:").append(type).append(" foe:").append(foe).append(" other:").append(other).append(" q:").append(q).append("}");
//                s = s.replaceAll("%s", playerSlot(player, slot));
//                s = s.replaceAll("%ts", "{p:" +player + " name}");
//                s = s.replaceAll("%tf", "{p:" +(player == 0 ? 1 : 0) + " name}");
//                if (type != -1) s = s.replaceAll("%t", TypeInfo.Type.values()[type].toString());
//                if (foe != -1) s = s.replaceAll("%f", playerSlot(foe, slot));
//                if (other != -1 && s.contains("%m")) s = s.replaceAll("%m", "{move:" + Short.toString(other) + "}");
//                s = s.replaceAll("%d", Short.toString(other));
//                s = s.replaceAll("%q", q);
//                if (other != -1 && s.contains("%i")) s = s.replaceAll("%i", "{item:" + Short.toString(other) + "}");
//                if (other != -1 && s.contains("%a")) s = s.replaceAll("%a", "{ability:" + Short.toString(other) + "}");
//                if (other != -1 && s.contains("%p")) s = s.replaceAll("%p", "{poke:" + (new UniqueID(other, 0).toString()) + "}");
                break;
            }
            case ItemMessage: {
                short item  = msg.readShort();
                byte  part  = msg.readByte();
                byte  foe   = msg.readByte();
                short berry = msg.readShort();
                int   other = msg.readInt();
                readable.append(sp + "{item:").append(item).append(" part:").append(part).append(" foe:").append(foe).append(" berry:").append(berry).append(" other:").append(other).append("}");
//                if (other != -1 && s.contains("%st"))
//                    s = s.replaceAll("%st", PokeEnums.Stat.values()[other].toString());
//                s = s.replaceAll("%s", playerSlot(player, slot));
//                if (foe != -1) s = s.replaceAll("%f", playerSlot(foe, slot));
//                if (berry != -1) s = s.replaceAll("%i", "{berry:" + Integer.toString(other) + "}");
//                if (other != -1 && s.contains("%m")) s = s.replaceAll("%m", "{move:" + Integer.toString(other) + "}");
//                if (other != -1 && s.contains("%p")) s = s.replaceAll("%p", "{poke:" + (new UniqueID(other, 0).toString()) + "}");
                break;
            }
            case WeatherMessage: {
                byte wstatus = msg.readByte(), weather = msg.readByte();
                if (weather == PokeEnums.Weather.NormalWeather.ordinal()) {
                    break;
                }
                readable.append(sp).append(WeatherState.values()[wstatus].toString());
                readable.append(sp).append(Weather.values()[weather]);
                break;
            }
            case StraightDamage: {
                short damage = msg.readShort();
                readable.append(sp).append(damage);
                break;
            }
            case AbilityMessage: {
                short ab    = msg.readShort();
                byte  part  = msg.readByte();
                byte  type  = msg.readByte();
                byte  foe   = msg.readByte();
                short other = msg.readShort();

                readable.append(sp + "{ability:").append(ab).append(" part:").append(part).append(" type:").append(type).append(" foe:").append(foe).append(" other:").append(other).append("}");
//                if (other != -1 && s.contains("%st"))
//                    s = s.replaceAll("%st", "{stat:" + other + "}");
//                s = s.replaceAll("%s", playerSlot(player, slot));
//                s = s.replaceAll("%tf", "{p:" +(player == 0 ? 1 : 0) + " name}");
//                if (type != -1) s = s.replaceAll("%t", TypeInfo.Type.values()[type].toString());
//                if (foe != -1) s = s.replaceAll("%f", playerSlot(foe, slot));
//                if (other != -1 && s.contains("%m")) s = s.replaceAll("%m", "{move:" + Short.toString(other) + "}");
//                if (other != -1 && s.contains("%i")) s = s.replaceAll("%i", "{item:" + Short.toString(other) + "}");
//                if (other != -1 && s.contains("%a")) s = s.replaceAll("%a", "{ability:" + Short.toString(other) + "}");
//                if (other != -1 && s.contains("%p")) s = s.replaceAll("%p", "{poke:" + (new UniqueID(other, 0).toString()) + "}");
                break;
            }
            case Substitute: {
                boolean sub = msg.readBool();
                readable.append(sp).append(playerSlot(player, slot));
                readable.append(sp).append(sub);
                break;
            }
            case PointEstimate: {
                byte first  = msg.readByte();
                byte second = msg.readByte();
                readable.append(sp).append(first).append(sp).append(second);
                break;
            }
            case Clause: {
                readable.append(sp).append(p.num);
                break;
            }
            case TierSection:
            case HtmlMessage: {
                String tier = msg.readString();
                readable.append(sp).append(tier);
                break;
            }
            case TempPokeChange: {
                byte                            id     = msg.readByte();
                SpectatingBattle.TempPokeChange change = SpectatingBattle.TempPokeChange.values()[id];
                readable.append(sp).append(change.toString());
                switch (change) {
                    case TempMove:
                    case DefMove: {
                        byte  moveslot = msg.readByte();
                        short move     = msg.readShort();
                        readable.append(sp + "{s:").append(moveslot).append(" m:").append(move).append("}");
                        break;
                    }
                    case TempPP: {
                        byte moveslot = msg.readByte();
                        byte PP       = msg.readByte();
                        readable.append(sp + "{s:").append(moveslot).append(" p:").append(PP).append("}");
                        break;
                    }
                    case TempSprite:
                    case DefiniteForme: {
                        UniqueID sprite = new UniqueID(msg);
                        readable.append(sp).append(playerSlot(player, slot)).append(sp).append(sprite.toString());
                        break;
                    }//byte poke = msg.readByte();
                    case AestheticForme:
                        short newForm = msg.readShort();
                        readable.append(sp).append(playerSlot(player, slot)).append(sp).append(newForm);
                    default:
                        break;
                }
                break;
            }
            case OfferChoice: {
                byte      numSlot      = msg.readByte();
                boolean   allowSwitch  = msg.readBool();
                boolean   allowAttack  = msg.readBool();
                Boolean[] allowAttacks = new Boolean[4];

                for (int i = 0; i < 4; i++) {
                    allowAttacks[i] = msg.readBool();
                }

                boolean allowMega = msg.readBool();
                readable.append(sp + "allow{switch:").append(allowSwitch).append(" attack:").append(allowAttack).append(" attacks:").append(ArrayUtilities.join(allowAttacks, ",")).append(" mega:").append(allowMega).append(" slot:").append(numSlot).append("}");
                break;
            }
            case ClockStart:
            case ClockStop: {
                readable.append(sp).append(msg.readShort());
                break;
            }
            case ChangeHp: {
                short newHP = msg.readShort();
                readable.append(sp).append(playerSlot(player, slot)).append(sp).append(newHP);
                break;
            }// TODO
            case DynamicInfo: {
                Bais copy = msg.cloneRemaining();
                readable.append(sp).append(playerSlot(player, slot));
                try {
                    readable.append(sp).append(new BattleDynamicInfo(msg));
                } catch (Exception e) {
                    readable.append(sp + error).append(copy.toString());
                }
                break;
            }
            case DynamicStats: {
                Bais copy = msg.cloneRemaining();
                try {
                    readable.append(sp).append(playerSlot(player, slot)).append("  {stats:");
                    for (int i = 0; i < 5; i++) {
                        readable.append(msg.readShort()).append(" ");
                    }
                    readable.append("}");
                } catch (Exception e) {
                    readable.append(sp + error).append(copy.toString());
                }
                break;
            }
            case UsePP: {
                short move   = msg.readShort();
                byte  usedpp = msg.readByte();
                readable.append(sp).append(move).append(sp).append(usedpp);
                break;
            }
            case Notice: {
                String rule    = msg.readString();
                String message = msg.readString();
                readable.append(sp).append(rule).append(sp).append(message);
                break;
            }
            case TerrainMessage: {
                byte tstatus = msg.readByte(), terrain = msg.readByte();
                readable.append(sp).append(TerrainState.values()[tstatus].toString());
                readable.append(sp).append(Terrain.values()[terrain]);
                break;
            }
            default: {
                readable.append(sp + "Battle command unimplemented");
                break;
            }
        }
        return readable.toString();
    }

    private static byte player(byte num) {
        if ((num % 2) == 0) {
            return 0;
        } else {
            return 1;
        }
    }

    private static byte slot(byte num, byte player) {
        if (player == me) {
            return (byte) (num / 2);
        } else {
            return (byte) ((num - 1) / 2);
        }
    }

    private static String playerSlot(byte player, byte slot) {
        return "{p:" + player + " s:" + slot + "}";
    }
}