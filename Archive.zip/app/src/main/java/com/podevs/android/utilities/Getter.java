package com.podevs.android.utilities;

public interface Getter<T> {
    String get(T object, int index);
}
