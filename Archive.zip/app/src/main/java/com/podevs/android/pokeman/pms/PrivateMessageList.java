package com.podevs.android.pokeman.pms;

import com.podevs.android.pokeman.player.PlayerInfo;

import java.util.TreeMap;

public class PrivateMessageList {
    protected final TreeMap<Integer, PrivateMessage> privateMessages = new TreeMap<>();
    PlayerInfo                 me = new PlayerInfo();
    PrivateMessageListListener listener;

    public PrivateMessageList(PlayerInfo me) {
        this.me = me;
    }

    /**
     * New message
     *
     * @param playerInfo
     * @param message
     */
    public void newMessage(PlayerInfo playerInfo, String message) {
        createPM(playerInfo);
        privateMessages.get(playerInfo.id).addMessage(playerInfo, message, PrivateMessageActivity.getTimeStampPM());
    }

    /**
     * Creates a PM window with the other guy
     *
     * @param info the other guy's id
     */
    public void createPM(PlayerInfo info) {
        if (!privateMessages.containsKey(info.id)) {
            privateMessages.put(info.id, new PrivateMessage(info, me));

            if (listener != null) {
                listener.onNewPM(privateMessages.get(info.id));
            }
        }
    }

    public void removePM(int id) {
        if (privateMessages.containsKey(id)) {
            privateMessages.remove(id);

            if (listener != null) {
                listener.onRemovePM(id);
            }
        }
    }

    public int count() {
        return privateMessages.size();
    }

    interface PrivateMessageListListener {
        void onNewPM(PrivateMessage privateMessage);

        void onRemovePM(int id);
    }
}
