package com.podevs.android.pokeman.pokeinfo;

import android.util.SparseArray;

import androidx.annotation.NonNull;

import com.aggrx.scaffold.AggrxLists;
import com.aggrx.scaffold.AggrxMaps;
import com.aggrx.scaffold.AggrxNumbers;
import com.aggrx.scaffold.AggrxSparseArrays;
import com.jx.scaffold.JxLogger;
import com.jx.scaffold.JxPathUtils;
import com.podevs.android.pokeman.registry.RegistryActivity;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class PokemonStorage {
    public static int thisGen = GenInfo.genMax();
    static byte Generation = 2;

    static String languageResourcePath(String res, boolean zh) {
        if (zh) {
            String filename = JxPathUtils.basename(res);
            String path = res.replace(filename, LANGUAGE_DIR + filename);
            if (InfoConfig.fileExists(path)) {
                return path;
            }
        }
        return res;
    }

    static String genResourcePath(int gen, int sub, String prefix, String suffix) {
        String path = JxPathUtils.join(prefix, gen + "G", "Subgen " + sub, suffix);
        if (InfoConfig.fileExists(path)) {
            return path;
        }

        path = JxPathUtils.join(prefix, gen + "G", suffix);
        if (!InfoConfig.fileExists(path)) {
            JxLogger.e(new Exception(), "%s not exist in assert", path);
        }
        return path;
    }

    static SparseArray<PokemonModels.Generation> generations = new SparseArray<>();
    static SparseArray<String> genders = new SparseArray<>(3);

    public static void load() {
        boolean zh = RegistryActivity.localize_assets;
        // load gens
        String genPath = languageResourcePath("db/gens/gens.txt", zh);
        InfoFiller.fill(genPath, (i, s, o) -> {
            PokemonModels.Generation generation = AggrxSparseArrays.getOrSet(generations, i, PokemonModels.Generation::new);
            generation.name = s;
            generation.main = i;
        });

        // load version
        String versionPath = languageResourcePath("db/gens/versions.txt", zh);
        InfoFiller.uID_fill(versionPath, (i, s, o) -> {
            int gen = i.main;//i % 65536;
            int subGen = i.sub;// i / 65536;

            PokemonModels.Generation generation = AggrxSparseArrays.getOrSet(generations, gen, PokemonModels.Generation::new);
            generation.subGenerations.put(i.id(), new PokemonModels.GenerationVersion(i, s));
        });

        // load genders
        String genderPath = languageResourcePath("db/genders/genders.txt", zh);
        InfoFiller.fill(genderPath, (i, s, o) -> genders.put(i, s));

        // load ability
        String abilitiesPath = languageResourcePath("db/abilities/abilities.txt", zh);
        InfoFiller.fill(abilitiesPath, (i, b, o) -> {
            PokemonModels.Ability ability = AggrxSparseArrays.getOrSet(abilities, i, PokemonModels.Ability::new);
            ability.id = i;
            ability.name = b;
        });

        String abilityMessagesPath = languageResourcePath("db/abilities/ability_messages.txt", zh);
        InfoFiller.fill(abilityMessagesPath, (i, b, o) -> {
            PokemonModels.Ability ability = AggrxSparseArrays.getOrSet(abilities, i, PokemonModels.Ability::new);
            ability.id = i;
            ability.desc = b;
        });

        // load move
        String movePath = languageResourcePath("db/moves/moves.txt", zh);
        InfoFiller.fill(movePath, (i, b, o) -> {
            PokemonModels.MoveInfo moveInfo = AggrxSparseArrays.getOrSet(moves, i, PokemonModels.MoveInfo::new);
            moveInfo.id = i;
            moveInfo.name = b;
        });

        String move_messagePath = languageResourcePath("db/moves/move_message.txt", zh);
        InfoFiller.fill(move_messagePath, (i, b, o) -> {
            PokemonModels.MoveInfo moveInfo = AggrxSparseArrays.getOrSet(moves, i, PokemonModels.MoveInfo::new);
            moveInfo.id = i;
            moveInfo.message = b;
        });

        // pokemons
        String pokemonPath = languageResourcePath("db/pokes/pokemons.txt", zh);
        InfoFiller.uID_fill(pokemonPath, (i, s, options) -> {
            PokemonModels.PokemonX pokemonX = AggrxMaps.getOrSet(pokemons, i.main + "", () -> new PokemonModels.PokemonX(i.main));
            PokemonModels.Pokemon pokemon = AggrxMaps.getOrSet(pokemonX.forms, i.id(), PokemonModels.Pokemon::new);
            pokemon.id = i;
            pokemon.name = s;
            pokemon.extraData.options = options;
        });

        InfoFiller.uID_fill("db/pokes/gender.txt", (i, b, o) -> {
            PokemonModels.PokemonX pokemonX = AggrxMaps.getOrSet(pokemons, i.main + "", () -> new PokemonModels.PokemonX(i.main));
            PokemonModels.Pokemon pokemon = AggrxMaps.getOrSet(pokemonX.forms, i.id(), PokemonModels.Pokemon::new);
            pokemon.gender = (byte) AggrxNumbers.parseInt(b, 0);
        });

        // load item
        String itemPath = languageResourcePath("db/items/items.txt", zh);
        InfoFiller.fill(itemPath, (i, b, o) -> {
            PokemonModels.Item item = AggrxSparseArrays.getOrSet(items, i, PokemonModels.Item::new);
            item.id = i;
            item.name = b;
        });

        String berryPath = languageResourcePath("db/items/berries.txt", zh);
        InfoFiller.fill(berryPath, (i, b, o) -> {
            int id = PokemonInfo.BERRY_ICON_BASE + i;
            PokemonModels.Item item = AggrxSparseArrays.getOrSet(items, id, PokemonModels.Item::new);
            item.id = id;
            item.name = b;
        });


        String itemMessagePath = languageResourcePath("db/items/item_messages.txt", zh);
        InfoFiller.fill(itemMessagePath, (i, b, o) -> {
            PokemonModels.Item item = AggrxSparseArrays.getOrSet(items, i, PokemonModels.Item::new);
            item.id = i;
            item.message = b;
        });


        String berryMessagePath = languageResourcePath("db/items/berry_messages.txt", zh);
        InfoFiller.fill(berryMessagePath, (i, b, o) -> {
            int id = PokemonInfo.BERRY_ICON_BASE + i;
            PokemonModels.Item item = AggrxSparseArrays.getOrSet(items, id, PokemonModels.Item::new);
            item.id = id;
            item.message = b;
        });

        String itemUsefulPath = "db/items/item_useful.txt";
        final ArrayList<Integer> items = new ArrayList<>();

        InfoFiller.plainFill(itemUsefulPath, (i, s, o) -> items.add(i));

        /* Sort item names */
        Collections.sort(items, (lhs, rhs) -> itemName(lhs).compareTo(itemName(rhs)));

        final ArrayList<Integer> berries = new ArrayList<>();

        String berryUsefulPath = "db/items/berry_useful.txt";
        InfoFiller.plainFill(berryUsefulPath, (i, s, o) -> berries.add(PokemonInfo.BERRY_ICON_BASE + i));

        /* Sort item names */
        Collections.sort(berries, (lhs, rhs) -> itemName(lhs).compareTo(itemName(rhs)));

        usefulItems.addAll(items);
        usefulItems.addAll(berries);


        /*nature*/
        String naturePath = languageResourcePath("db/natures/nature.txt", zh);
        InfoFiller.fill(naturePath, (i, s, o) -> natures.put(i, s));

        AggrxSparseArrays.each(generations, (gen, index, list) -> {
            // effect
            String effectPath = genResourcePath(gen.main, -1, "db/moves/", "effect.txt");
            effectPath = languageResourcePath(effectPath, zh);
            InfoFiller.fill(effectPath, (i, s, o) -> {
                PokemonModels.MoveInfo move = AggrxSparseArrays.getOrSet(moves, i, PokemonModels.MoveInfo::new);
                move.id = i;
                move.effect.put(gen.main, s);
            });

            // zpower
            String zpowerPath = genResourcePath(gen.main, -1, "db/moves/", "zpower.txt");
            InfoFiller.fill(zpowerPath, new InfoFiller.FillerByte() {
                @Override
                void fillByte(int i, byte b, String o) {
                    PokemonModels.MoveInfo move = AggrxSparseArrays.getOrSet(moves, i, PokemonModels.MoveInfo::new);
                    move.id = i;
                    move.zpower.put(gen.main, b);
                }
            });

            // accuracy
            String accuracyPath = genResourcePath(gen.main, -1, "db/moves/", "accuracy.txt");
            InfoFiller.fill(accuracyPath, new InfoFiller.FillerByte() {
                @Override
                void fillByte(int i, byte b, String o) {
                    PokemonModels.MoveInfo move = AggrxSparseArrays.getOrSet(moves, i, PokemonModels.MoveInfo::new);
                    move.id = i;
                    move.accuracy.put(gen.main, b);
                }
            });

            // type
            String typePath = genResourcePath(gen.main, -1, "db/moves/", "type.txt");
            InfoFiller.fill(typePath, new InfoFiller.FillerByte() {
                @Override
                void fillByte(int i, byte b, String o) {
                    PokemonModels.MoveInfo move = AggrxSparseArrays.getOrSet(moves, i, PokemonModels.MoveInfo::new);
                    move.id = i;
                    move.type.put(gen.main, b);
                }
            });

            // damage_class
            String damage_classPath = genResourcePath(gen.main, -1, "db/moves/", "damage_class.txt");
            InfoFiller.fill(damage_classPath, new InfoFiller.FillerByte() {
                @Override
                void fillByte(int i, byte b, String o) {
                    PokemonModels.MoveInfo move = AggrxSparseArrays.getOrSet(moves, i, PokemonModels.MoveInfo::new);
                    move.id = i;
                    move.damageClass.put(gen.main, b);
                }
            });

            // power
            String powerPath = genResourcePath(gen.main, -1, "db/moves/", "power.txt");
            InfoFiller.fill(powerPath, new InfoFiller.FillerByte() {
                @Override
                void fillByte(int i, byte b, String o) {
                    PokemonModels.MoveInfo move = AggrxSparseArrays.getOrSet(moves, i, PokemonModels.MoveInfo::new);
                    move.id = i;
                    move.power.put(gen.main, b);
                }
            });

            // power
            String zeffectPath = genResourcePath(gen.main, -1, "db/moves/", "zeffect.txt");
            InfoFiller.fill(zeffectPath, (i, s, o) -> {
                        PokemonModels.MoveInfo move = AggrxSparseArrays.getOrSet(moves, i, PokemonModels.MoveInfo::new);
                        move.id = i;
                        move.zeffect.put(gen.main, s);
                    }
            );

            // power
            String rangePath = genResourcePath(gen.main, -1, "db/moves/", "range.txt");
            InfoFiller.fill(rangePath, new InfoFiller.FillerByte() {
                @Override
                void fillByte(int i, byte b, String o) {
                    PokemonModels.MoveInfo move = AggrxSparseArrays.getOrSet(moves, i, PokemonModels.MoveInfo::new);
                    move.id = i;
                    move.range.put(gen.main, PokemonModels.Target.values()[b]);
                }
            });

            // moves
            final Short[] allMoves = new Short[moves.size()];
            for (int i = 0; i <= allMoves.length - 1; i++) {
                allMoves[i] = (short) 0;
            }
            String movesPath = genResourcePath(gen.main, -1, "db/moves/", "moves.txt");
            InfoFiller.plainFill(movesPath, (i, s, o) -> {
                if (i >= 0 && i < allMoves.length) {
                    allMoves[i] = (short) i;
                }
            });

            Short[] allMovesTrim = array_trim(allMoves);
            Arrays.sort(allMovesTrim, (lhs, rhs) -> moveName(lhs).compareToIgnoreCase(moveName(rhs)));
            gen.allMoves = allMovesTrim;

            // generation items
            String releasedItemsPath = genResourcePath(gen.main, -1, "db/items/", "released_items.txt");
            List<Integer> releasedItems = new ArrayList<>();
            List<Integer> finalReleasedItems = releasedItems;
            InfoFiller.plainFill(releasedItemsPath, (i, s, o) -> finalReleasedItems.add(i));

            // TODO:优化查找效率
            releasedItems = AggrxLists.filter(releasedItems, (item1, index1, list1)
                    -> AggrxLists.first(usefulItems, -1, (item2, index2, list2)
                    -> item1.equals(item2)) != -1);

            Collections.sort(releasedItems, (lhs, rhs) -> itemName(lhs).compareTo(itemName(rhs)));

            String releasedBerriesPath = genResourcePath(gen.main, -1, "db/items/", "released_berries.txt");
            List<Integer> releasedBerries = new ArrayList<>();
            List<Integer> finalReleasedBerries = releasedBerries;
            InfoFiller.plainFill(releasedBerriesPath, (i, s, o) -> finalReleasedBerries.add(PokemonInfo.BERRY_ICON_BASE + i));
            releasedBerries = AggrxLists.filter(releasedBerries, (item1, index1, list1)
                    -> AggrxLists.first(usefulItems, -1, (item2, index2, list2)
                    -> item1.equals(item2)) != -1);

            Collections.sort(releasedBerries, (lhs, rhs) -> itemName(lhs).compareTo(itemName(rhs)));

            gen.usefulItems.addAll(releasedItems);
            gen.usefulItems.addAll(releasedBerries);


            // stats
            String statesPath = genResourcePath(gen.main, -1, "db/pokes/", "stats.txt");
            InfoFiller.uID_fill(statesPath, (i, s, o) -> {
                byte[] stats = new byte[6];
                int curIndex = 0;

                /* faster than using a split (using test project to measure times) */
                for (int j = 0; j < 6; j++) {
                    int nextIndex = s.indexOf(' ', curIndex);
                    stats[j] = (byte) AggrxNumbers.parseInt(s.substring(curIndex, nextIndex == -1 ? s.length() : nextIndex), 0);
                    curIndex = nextIndex + 1;
                }

                PokemonInfo.PokemonData data = AggrxMaps.getOrSet(gen.dataMap, i.id(), PokemonInfo.PokemonData::new);
                if (data != null) {
                    data.stats = stats;
                }
            });

            // released
            String releasedPath = genResourcePath(gen.main, -1, "db/pokes/", "released.txt");
            InfoFiller.uID_fill(releasedPath, (i, b, o) -> {
                gen.dataMap.put(i.id(), new PokemonInfo.PokemonData());
            });

            // type1
            String type1Path = genResourcePath(gen.main, -1, "db/pokes/", "type1.txt");
            InfoFiller.uID_fill(type1Path, (i, b, o) -> {
                try {
                    PokemonInfo.PokemonData data = gen.dataMap.get(i.id());
                    if (data != null) {
                        data.type1 = (byte) AggrxNumbers.parseInt(b, 0);
                    }
                } catch (Exception e) {
                    // JxLogger.w("Impossible to load type 1 %s from %s", o, type1Path);
                }
            });

            // type2
            String type2Path = genResourcePath(gen.main, -1, "db/pokes/", "type2.txt");
            InfoFiller.uID_fill(type2Path, (i, b, o) -> {
                try {
                    PokemonInfo.PokemonData data = gen.dataMap.get(i.id());
                    if (data != null) {
                        data.type2 = (byte) AggrxNumbers.parseInt(b, 0);
                    }
                } catch (Exception e) {
                    // JxLogger.w("Impossible to load type 1 %s from %s", o, type1Path);
                }
            });

            // all_moves
            String all_movesPath = genResourcePath(gen.main, -1, "db/pokes/", "all_moves.txt");
            InfoFiller.uID_fill(all_movesPath, (i, s, o) -> {
                try {
                    PokemonInfo.PokemonData data = gen.dataMap.get(i.id());
                    if (data != null) {
                        data.moveString = s;
                    }
                } catch (Exception e) {
                    // JxLogger.w("Impossible to load type 1 %s from %s", o, type1Path);
                }
            });


            // ability1
            String ability1Path = genResourcePath(gen.main, -1, "db/pokes/", "ability1.txt");
            InfoFiller.uID_fill(all_movesPath, (i, s, o) -> {
                try {
                    PokemonInfo.PokemonData data = gen.dataMap.get(i.id());
                    if (data != null) {
                        data.updateAbility(0, AggrxNumbers.parseShort(s, (short) 0));
                    }
                } catch (Exception e) {
                    // JxLogger.w("Impossible to load type 1 %s from %s", o, type1Path);
                }
            });

            // ability2
            String ability2Path = genResourcePath(gen.main, -1, "db/pokes/", "ability2.txt");
            InfoFiller.uID_fill(all_movesPath, (i, s, o) -> {
                try {
                    PokemonInfo.PokemonData data = gen.dataMap.get(i.id());
                    if (data != null) {
                        data.updateAbility(1, AggrxNumbers.parseShort(s, (short) 0));
                    }
                } catch (Exception e) {
                    // JxLogger.w("Impossible to load type 1 %s from %s", o, type1Path);
                }
            });

            // ability3
            String ability3Path = genResourcePath(gen.main, -1, "db/pokes/", "ability3.txt");
            InfoFiller.uID_fill(all_movesPath, (i, s, o) -> {
                try {
                    PokemonInfo.PokemonData data = gen.dataMap.get(i.id());
                    if (data != null) {
                        data.updateAbility(2, AggrxNumbers.parseShort(s, (short) 0));
                    }
                } catch (Exception e) {
                    // JxLogger.w("Impossible to load type 1 %s from %s", o, type1Path);
                }
            });

            // typestable
            String typestablePath = genResourcePath(gen.main, -1, "db/types/", "typestable.txt");
            InfoFiller.fill(typestablePath, (k, s, o) -> {
                String[] split = s.split(" ");
                for (int j = 0; j < split.length; j++) {
                    gen.effectiveness[k][j] = Byte.parseByte(split[j]);
                }
            });
        });
    }

    static SparseArray<String> natures = new SparseArray<>();
    static Map<String, PokemonModels.PokemonX> pokemons = new HashMap<>();

    private static Short[] array_trim(Short[] shorts) {
        int i = shorts.length - 1;
        while (i >= 0 && shorts[i] == 0) {
            --i;
        }

        return Arrays.copyOf(shorts, i + 1);
    }

    static String moveName(int number) {
        PokemonModels.MoveInfo move = AggrxSparseArrays.get(moves, number, null);
        if (move == null) {
            return "";
        }
        return move.name;
    }

    private static final List<Integer> usefulItems = new ArrayList<>();

    static String itemName(int id) {
        PokemonModels.Item item = items.get(id);
        if (item != null) {
            return item.name;
        }
        return "";
    }

    static SparseArray<PokemonModels.Item> items = new SparseArray<>();

    static SparseArray<PokemonModels.MoveInfo> moves = new SparseArray<>();

    static SparseArray<PokemonModels.Ability> abilities = new SparseArray<>();

    /**/
    @NonNull
    static String getAbilityMessagesPath() {
        String path = "db/abilities/ability_messages.txt";
        if (RegistryActivity.localize_assets) {
            path = "db/abilities/" + LANGUAGE_DIR + "ability_messages.txt";
        }
        return path;
    }

    /**/
    @NonNull
    static String getAbilityNamesPath() {
        String path;
        if (RegistryActivity.localize_assets) {
            path = "db/abilities/" + LANGUAGE_DIR + "abilities.txt";
        } else {
            path = "db/abilities/abilities.txt";
        }
        return path;
    }


    private static final String LANGUAGE_DIR = "translation-zh/";

    /**/
    @NonNull
    static String getGendersPath() {
        String path;
        if (RegistryActivity.localize_assets) {
            path = "db/genders/" + LANGUAGE_DIR + "genders.txt";
        } else {
            path = "db/genders/genders.txt";
        }
        return path;
    }

    /**/
    @NonNull
    static String getGenEffectString() {
        String path;
        if (RegistryActivity.localize_assets) {
            path = "db/moves/" + LANGUAGE_DIR + thisGen + "G/effect.txt";
        } else {
            path = "db/moves/" + thisGen + "G/effect.txt";
        }
        return path;
    }

    /**/
    @NonNull
    static String getGensPath() {
        String path;
        if (RegistryActivity.localize_assets) {
            path = "db/gens/" + LANGUAGE_DIR + "gens.txt";
        } else {
            path = "db/gens/gens.txt";
        }
        return path;
    }


    /**/
    @NonNull
    static String getVersionsPath() {
        String path;
        if (RegistryActivity.localize_assets) {
            path = "db/gens/" + LANGUAGE_DIR + "versions.txt";
        } else {
            path = "db/gens/versions.txt";
        }
        return path;
    }

    /**/
    @NonNull
    static String getBerryMessagesPath() {
        String path;
        if (RegistryActivity.localize_assets) {
            path = "db/items/" + LANGUAGE_DIR + "berry_messages.txt";
        } else {
            path = "db/items/berry_messages.txt";
        }
        return path;
    }

    /**/
    @NonNull
    static String getItemMessagesString() {
        String path;
        if (RegistryActivity.localize_assets) {
            path = "db/items/" + LANGUAGE_DIR + "item_messages.txt";
            if (!InfoConfig.fileExists(path)) {
                path = "db/item/item_messages.txt";
            }
        } else {
            path = "db/items/item_messages.txt";
        }
        return path;
    }

    /**/
    @NonNull
    static String getBerryUsefulPath() {
        return "db/items/berry_useful.txt";
    }

    /**/
    @NonNull
    static String getUsefulItemPath() {
        return "db/items/item_useful.txt";
    }

    /**/
    @NonNull
    static String getG2ReleasedBerryPath() {
        return "db/items/" + Generation + "G/released_berries.txt";
    }

    /**/
    @NonNull
    static String get2GReleasedItemsPath() {
        return "db/items/" + Generation + "G/released_items.txt";
    }

    /**/
    @NonNull
    static String getGenZPowerPath() {
        return "db/moves/" + thisGen + "G/zpower.txt";
    }

    /**/
    @NonNull
    static String getGenAccuracyPath() {
        return "db/moves/" + thisGen + "G/accuracy.txt";
    }

    /**/
    @NonNull
    static String getGenType() {
        return "db/moves/" + thisGen + "G/type.txt";
    }

    /**/
    @NonNull
    static String getGendamage_classPath() {
        return "db/moves/" + thisGen + "G/damage_class.txt";
    }

    /**/
    @NonNull
    static String getGenpowerPath() {
        return "db/moves/" + thisGen + "G/power.txt";
    }

    /**/
    @NonNull
    static String getMovePath() {
        String path;
        if (RegistryActivity.localize_assets) {
            path = "db/moves/" + LANGUAGE_DIR + "moves.txt";
        } else {
            path = "db/moves/moves.txt";
        }
        return path;
    }

    /**/
    @NonNull
    static String getGenzeffectPath() {
        return "db/moves/" + thisGen + "G/zeffect.txt";
    }

    /**/
    @NonNull
    static String getGenrangePath() {
        return "db/moves/" + thisGen + "G/range.txt";
    }

    /**/
    @NonNull
    static String getMoveMessagePath() {
        String path;
        if (RegistryActivity.localize_assets) {
            path = "db/moves/" + LANGUAGE_DIR + "move_message.txt";
        } else {
            path = "db/moves/move_message.txt";
        }
        return path;
    }

    /**/
    @NonNull
    static String getGenMovesPath() {
        return "db/moves/" + thisGen + "G/moves.txt";
    }

    /**/
    @NonNull
    static String getNaturePath() {
        String path;
        if (RegistryActivity.localize_assets) {
            path = "db/natures/" + LANGUAGE_DIR + "nature.txt";
        } else {
            path = "db/natures/nature.txt";
        }
        return path;
    }

    /**/
    @NonNull
    static String getPokemonsPath() {
        String path;
        if (RegistryActivity.localize_assets) {
            path = "db/pokes/" + LANGUAGE_DIR + "pokemons.txt";
        } else {
            path = "db/pokes/pokemons.txt";
        }
        return path;
    }

    /**/
    @NonNull
    static String getGenStatsPath(int gen) {
        return "db/pokes/" + gen + "G/stats.txt";
    }

    /**/
    @NonNull
    static String getGenType2Path(int gen) {
        return "db/pokes/" + gen + "G/type2.txt";
    }

    /**/
    @NonNull
    static String getGenType1Path(int gen) {
        return "db/pokes/" + gen + "G/type1.txt";
    }

    /**/
    @NonNull
    static String getGenReleasedPath(int gen) {
        return "db/pokes/" + gen + "G/released.txt";
    }

    /**/
    @NonNull
    static String getGenAllMoves(int gen, int sub) {
        String test;
        if (gen == 6 && sub == 1) {
            test = "db/pokes/6G/Subgen 1/all_moves.txt";
        } else {
            test = "db/pokes/" + gen + "G/all_moves.txt";
        }
        return test;
    }


    /**/
    @NonNull
    static String getGenAbility3File(int gen) {
        return "db/pokes/" + gen + "G/ability3.txt";
    }

    /**/
    @NonNull
    static String getGenAbility2File(int gen) {
        return "db/pokes/" + gen + "G/ability2.txt";
    }

    /**/
    @NonNull
    static String getGenAbility1File(int gen) {
        return "db/pokes/" + gen + "G/ability1.txt";
    }

    /**/
    @NonNull
    static String getGenderPath() {
        return "db/pokes/gender.txt";
    }

    /**/
    @NonNull
    static String getGenTypesTablePath(int i) {
        return "db/types/" + (i + 1) + "G/typestable.txt";
    }

    /**/
    @NonNull
    static String getItemsPath() {
        String path;
        if (RegistryActivity.localize_assets) {
            path = "db/items/" + LANGUAGE_DIR + "items.txt";
        } else {
            path = "db/items/items.txt";
        }
        return path;
    }

    /**/
    @NonNull
    static String getBerriesPath() {
        String path;
        if (RegistryActivity.localize_assets) {
            path = "db/items/" + LANGUAGE_DIR + "berries.txt";
        } else {
            path = "db/items/berries.txt";
        }
        return path;
    }
}
