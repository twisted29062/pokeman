package com.podevs.android.pokeman.pokeinfo;

import android.annotation.SuppressLint;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.text.TextUtils;
import android.util.LruCache;
import android.util.SparseArray;

import androidx.annotation.NonNull;

import com.aggrx.scaffold.AggrxLists;
import com.aggrx.scaffold.AggrxMaps;
import com.aggrx.scaffold.AggrxNumbers;
import com.jx.scaffold.JxLogger;
import com.podevs.android.pokeman.R;
import com.podevs.android.pokeman.poke.Gen;
import com.podevs.android.pokeman.poke.Poke;
import com.podevs.android.pokeman.poke.ShallowBattlePoke;
import com.podevs.android.pokeman.poke.UniqueID;
import com.podevs.android.pokeman.pokeinfo.StatsInfo.Stats;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Static data used to store all information regarding pokemon at all times.
 * Uses caching to reduce read from disk time.
 */

public class PokemonInfo {
    /**
     * Cache of images
     */
    private final static LruCache<String, Drawable> ImageCache = new LruCache<>(22);
    public static final String SPRITES_ROOT = "db/pokes/8G/sprites/s-m";
    public static final int BERRY_ICON_BASE = 8000;
    /**
     * MashMap linking pokeNames to UniqueID
     */
    private static HashMap<String, UniqueID> namesToIds = null;
    /**
     * SpareArray of pokeNames
     */
    private static Map<String, String> pokeNames = null;
    private static SparseArray<Map<String, PokemonData>> generations = null;
    private static Map<String, PokemonExtraData> pokemonDataList = null;
    // private static int pokeCount = 0;
    /**
     * Number of pokemon in a generation
     */
    private static int[] pokeCountg = null;
    private static boolean gendersLoaded = false;
    public static final Drawable DEFAULT_ITEM_DRAWABLE = InfoConfig.getDrawable(R.drawable.i0);
    public static final String ITEM_ICON_DIR = "db/items/items/";
    public static final String BERRY_ICON_DIR = "db/items/berries/";

    /**
     * indexOf method for pokeNames SparseArray
     *
     * @param pokemonName String to be find in list of pokemon names
     * @return Index of pokemon name. Returns 0 if not found
     */

    public static String indexOf(String pokemonName) {
        loadPokeNames();
        return AggrxMaps.findValue(pokeNames, pokemonName);

//        for (int i = 0; i < pokeNames.size(); i++) {
//
//            if (pokeNames.get(pokeNames.keyAt(i)).equals(pokemonName)) {
//                return pokeNames.keyAt(i);
//            } // pokeNames has random offsets, does it even need these?
//        }
//        return 0;
    }

    private static void loadPokeNames() {
        if (pokeNames != null) {
            return;
        }
        pokeNames = new HashMap<>();
        pokemonDataList = new HashMap<>();
        namesToIds = new HashMap<>();

        String path;
        path = PokemonStorage.getPokemonsPath();
        InfoFiller.uID_fill(path, (i, s, options) -> {
            pokeNames.put(i.id(), s);
            PokemonExtraData pokemonExtraData = pokemonDataList.get("" + i.main);
            if (pokemonExtraData == null) {
                pokemonExtraData = new PokemonExtraData();
                pokemonDataList.put("" + i.main, pokemonExtraData);
            }
            pokemonExtraData.ids.add(i);
            if (pokemonDataList.get(i.id()) == null) {
                pokemonDataList.put(i.id(), new PokemonExtraData());
            }
            pokemonDataList.get(i.id()).options = options;

//            if (i.hashCode() > 16000) {
//                PokeData pokeData = pokemonDataList.get("" + i.mainNum/*i % 65536*/);
//                if (pokeData.maxFormes < i.subNum)
//                    pokeData.maxFormes = i.subNum;/*(byte) (i >> 16)*/
//
//            } else if (i.hashCode() > pokeCount) {
//                pokeCount = i.hashCode();
//            }
            //pokemonDataList.get(i.id()).options = options;
            namesToIds.put(s, new UniqueID(i.id()));
        });
//        if (RegistryActivity.localize_assets) {
//            String path = "db/pokes/" + InfoConfig.getString(R.string.asset_localization) + "pokemons.txt";
//            if (InfoConfig.fileExists(path)) {
//                InfoFiller.uIDfill(path, (i, s, options) -> {
//                    pokeNames.put(i, s);
//                    pokemonDataList.put(i, new PokeData());
//
//                    if (i > 16000) {
//                        pokemonDataList.get(i % 65536).maxFormes = (byte) (i >> 16);
//                    } else if (i > pokeCount) {
//                        pokeCount = i;
//                    }
//                    pokemonDataList.get(i).options = options;
//                    namesToIds.put(s, new UniqueID(i));
//                });
//            }
//        }
    }

    /**
     * Checks if
     *
     * @param uID UniqueID of pokemon
     * @return true if pokemon has multiple formes in the teambuilder
     */

    public static boolean hasVisibleFormes(UniqueID uID, Gen gen) {
        loadPokeNames();

        PokemonExtraData data = pokemonDataList.get(uID.main + "");
        if (data == null) {
            return false;
        }
        //Check the pokemon has formes, and that they are not hidden
        if (data.ids.size() > 0) {
            if (data.options == null) {
                return true;
            } else {
                if (data.options.contains("H")) {
                    return false;
                } else {
                    for (UniqueID id : formes(uID, gen)) {
                        if (isVisible(id, gen)) {
                            return true;
                        }
                    }
                }
            }
        }
        return false;
    }

    public static boolean hasHackmonFormes(UniqueID uID) {
        loadPokeNames();

        int num = uID.originalHashCode();
        PokemonExtraData data = pokemonDataList.get(num + "");

        return data.ids.size()/*maxFormes*/ > 0;
    }

    /**
     * Loads formes into list by uID
     *
     * @param uniqueID UniqueID of pokemon
     * @param gen      Generation to load
     * @return list of formes by uID
     */

    public static List<UniqueID> formes(UniqueID uniqueID, Gen gen) {
        loadPokeNames();
        testLoad(gen.num);

        ArrayList<UniqueID> ret = new ArrayList<>();
        PokemonExtraData data = pokemonDataList.get(uniqueID.main + "");

        for (UniqueID generated : data.ids /*int i = 0; i <= data.maxFormes; i++*/) {
            //UniqueID generated = new UniqueID(uniqueID.mainNum, i);
            if (exists(generated, gen)) {
                if (isVisible(generated, gen)) {
                    ret.add(generated);
                }
            }
        }

        return ret;
    }

    public static List<UniqueID> formesHackmon(UniqueID uniqueID, Gen gen) {
        loadPokeNames();
        testLoad(gen.num);

        ArrayList<UniqueID> ret = new ArrayList<>();
        PokemonExtraData data = pokemonDataList.get(uniqueID.main + "");

        for (UniqueID generated : data.ids /*int i = 0; i <= data.maxFormes; i++*/) {
            //UniqueID generated = new UniqueID(uniqueID.mainNum, i);
            if (exists(generated, gen)) {
                ret.add(generated);
            }
        }

        return ret;
    }

    /**
     * @param uID UniqueID to check
     * @param gen Generation to check in
     * @return true is exists
     */

    public static boolean exists(UniqueID uID, Gen gen) {
        testLoad(gen.num);
        Map<String, PokemonData> map = generations.get(gen.num);
        return exists(uID) && AggrxMaps.get(map, uID.id(), null) != null;
    }

    /**
     * Checks if uID is valid or exists.
     *
     * @param uID UniqueID to check
     * @return true is uID exists
     */

    public static boolean exists(UniqueID uID) {
        loadPokeNames();
        return pokeNames.get(uID.id()) != null;
    }

    /**
     * Init arrays
     *
     * @param gen int Generation
     */

    private static void testLoad(int gen) {
        if (generations == null) {
            generations = new SparseArray<>(GenInfo.genMax() + 1);
        }
        if (generations.get(gen) == null) {
            generations.put(gen, new HashMap<>());
        }
        if (pokeCountg == null) {
            pokeCountg = new int[GenInfo.genMax() + 1];
        }
        if (generations.get(gen).size() == 0) {
            loadTypes(gen);
        }
    }

    /**
     * Fill type data for specified generation
     *
     * @param gen int generation
     */

    private static void loadTypes(int gen) {
        pokeCountg[gen] = 0;
        /* First load all the released pokemon and prepare the "data containers" */
        final Map<String, PokemonData> pokemon = generations.get(gen);
        String releasedPath = PokemonStorage.getGenReleasedPath(gen);
        InfoFiller.uID_fill(releasedPath, (i, s, o) -> {
            //JxLogger.w("Load pokemon %s from %s", o, releasedPath);
            pokemon.put(i.id(), new PokemonData());
//            if (i.hashCode() < 16000 && i.hashCode() > pokeCountg[gen]) {
//                pokeCountg[gen] = i.hashCode();
//            }
        }, true);
        pokeCountg[gen] = pokemon.size();

        String type1Path = PokemonStorage.getGenType1Path(gen);
        InfoFiller.uID_fill(type1Path, (i, b, o) -> {
            try {
                PokemonData data = pokemon.get(i.id());
                if (data != null) {
                    data.type1 = (byte) AggrxNumbers.parseInt(b, 0);
                }
            } catch (Exception e) {
                // JxLogger.w("Impossible to load type 1 %s from %s", o, type1Path);
            }
        });
        String type2Path = PokemonStorage.getGenType2Path(gen);
        InfoFiller.uID_fill(type2Path, (i, b, o) -> {
            try {
                PokemonData data = pokemon.get(i.id());
                if (data != null) {
                    data.type2 = (byte) AggrxNumbers.parseInt(b, 0);
                }
            } catch (Exception e) {
                // JxLogger.w("Impossible to load type 2 %s from %s", o, type2Path);
            }
        });
    }

    public static boolean isVisible(UniqueID uID, Gen gen) {
        testLoad(gen.num);

        PokemonExtraData data = pokemonDataList.get(uID.id());
        return (data.options == null || !data.options.contains("B"));
    }

    /**
     * Gets first type of Pokemon by gen
     *
     * @param uID Unique Id
     * @param gen Gen to check in
     * @return type of uID in gen
     */

    public static int type1(UniqueID uID, int gen) {
        testLoad(gen);

        int type = -1;
        Map<String, PokemonData> pokemon = generations.get(gen);
        try {
            PokemonData data = AggrxMaps.get(pokemon, uID.id(), null);
            if (data != null) {
                type = data.type1;
            }
            // else {
            //  JxLogger.w("can not find pokemon %s in %d", uID.hashCodeString(), gen);
            // }

            if (type == -1) {
                PokemonData data1 = AggrxMaps.get(pokemon, uID.main + "", null);
                if (data1 != null) {
                    type = data1.type1;
                }
                // else {
                //  JxLogger.w("can not find pokemon %s use original in %d", uID.hashCodeString(), gen);
                // }
            }
        } catch (NullPointerException e) {
            // type = pokemon.get((new UniqueID()).hashCode()).type2;
            //JxLogger.e("NULL original uID:" + uID);
            e.printStackTrace();
        }
        // if (type == -1) {
        //  JxLogger.w("Get type1 failed. %s", uID);
        // }
        return type;
    }

    /**
     * Gets second type of Pokemon by gen
     *
     * @param uID Unique Id
     * @param gen Gen to check in
     * @return type of uID in gen
     */

    public static int type2(UniqueID uID, int gen) {
        testLoad(gen);

        int type = -1;
        Map<String, PokemonData> pokemon = generations.get(gen);
        try {
            PokemonData data = AggrxMaps.get(pokemon, uID.id(), null);
            if (data != null) {
                type = data.type2;
            } else {
                JxLogger.w("can not find pokemon %s in %d", uID.hashCodeString(), gen);
            }

            if (type == -1) {
                PokemonData data1 = AggrxMaps.get(pokemon, uID.main + "", null);
                if (data1 != null) {
                    type = data1.type2;
                } else {
                    JxLogger.w("can not find pokemon %s use original in %d", uID.hashCodeString(), gen);
                }
            }
        } catch (NullPointerException e) {
            // type = pokemon.get((new UniqueID()).hashCode()).type2;
            //JxLogger.e("NULL original uID:" + uID);
            e.printStackTrace();
        }
        if (type == -1) {
            JxLogger.w("Get type2 failed. %s", uID);
        }
        return type;
    }

    /**
     * Gets moves for Pokemon
     *
     * @param uId UniqueID
     * @param gen int generation
     * @param sub sub generation
     * @return short[] of moves for uID
     */

    public static short[] moves(UniqueID uId, int gen, int sub) {
        testLoadMoves(gen, sub);
        convertMoveStringIfNeeded(uId, gen);

        Map<String, PokemonData> genDataMap = generations.get(gen);
        PokemonData genData = genDataMap.get(uId.id());
        if (genData.moves == null && uId.sub != 0) {
            return moves(uId.original(), gen, sub);
        }

        short[] ret = genData.moves;

        if (ret == null) {
            return new short[0];
        } else {
            return ret;
        }
    }

    private static void convertMoveStringIfNeeded(UniqueID uId, int gen) {
        Map<String, PokemonData> genDataMap = generations.get(gen);
        if (genDataMap == null) {
            return;
        }
        PokemonData poke = genDataMap.get(uId.id());
        if (poke.moveString != null) {
            String[] moves = poke.moveString.split(" ");

            Arrays.sort(moves, (lhs, rhs) -> MoveInfo.name(AggrxNumbers.parseInt(lhs, 0)).compareTo(MoveInfo.name(AggrxNumbers.parseInt(rhs, 0))));

            poke.moves = new short[moves.length];

            for (int i = 0; i < moves.length; i++) {
                poke.moves[i] = (short) AggrxNumbers.parseInt(moves[i], 0);
            }
            poke.moveString = null;
        }
    }

    /**
     * Ensures data pokemons array is filled
     *
     * @param gen int generation
     * @param sub sub generation
     */

    private static void testLoadMoves(int gen, int sub) {
        testLoad(gen);
        Map<String, PokemonData> pokemon = generations.get(gen);
        for (Map.Entry<String, PokemonData> entry : pokemon.entrySet()) {
            PokemonData genData = entry.getValue();
            if (genData.moveString != null || genData.moves != null) {
                return;
            }
        }

        String test;
        test = PokemonStorage.getGenAllMoves(gen, sub);
		/*
		String path = "db/pokes/" + gen + "G/Subgen " + sub + "all_moves.txt";
		 */

        InfoFiller.uID_fill(test, (i, s, o) -> {
            PokemonData poke = pokemon.get(i.id());
            if (poke != null) {
                poke.moveString = s;
            }
        });
    }

    /**
     * A temporary method to account for move changes between XY and ORAS.
     */

    public static void resetGen6() {
        generations.put(6, null);//[6] = null;
    }

    /**
     * Calculate the specified stat of a known pokemon in a specified generation (You?)
     *
     * @param poke Pokemon to check
     * @param stat Which stat 0-5
     * @param gen  int generation
     * @return stat
     */

    public static int calcStat(Poke poke, int stat, int gen) {
        if (stat == Stats.Hp.ordinal()) {
            return (stat(poke.uID(), stat, gen) == 1 ? 1 : ((2 * stat(poke.uID(), stat, gen) + poke.dv(stat) * (1 + (
                    gen <= 2 ? 1 : 0)) + poke.ev(stat) / 4) * poke.level()) / 100 + 5 + 5 + poke.level());
        } else {
            int base = ((2 * stat(poke.uID(), stat, gen) + poke.dv(stat) * (1 + (gen <= 2 ? 1
                    : 0)) + poke.ev(stat) / 4) * poke.level()) / 100 + 5;

            return NatureInfo.boostStat(base, poke.nature(), stat);
        }
    }

    /**
     * Gets stat for Pokemon
     *
     * @param uId  UniqueID
     * @param stat 0-5
     * @param gen  gen
     * @return stat of uID in gen
     */

    public static int stat(UniqueID uId, int stat, int gen) {
        loadStats(gen);
        Map<String, PokemonData> genDataMap = generations.get(gen);
        byte[] stats = genDataMap.get(uId.id()).stats;

        if (stats == null) {
            stats = genDataMap.get(uId.main + "").stats;
        }
        return (stats[stat] + 256) % 256;
    }

    /**
     * Loads stats for generation
     *
     * @param gen int generation
     */

    private static void loadStats(int gen) {
        testLoad(gen);
        Map<String, PokemonData> dataMap = generations.get(gen);
        for (Map.Entry<String, PokemonData> entry : dataMap.entrySet()) {
            PokemonData genData = entry.getValue();
            if (genData.stats != null) {
                return;
            }
        }

        InfoFiller.uID_fill(PokemonStorage.getGenStatsPath(gen), (i, s, o) -> {
            byte[] stats = new byte[6];
            int curIndex = 0;

            /* faster than using a split (using test project to measure times) */
            for (int j = 0; j < 6; j++) {
                int nextIndex = s.indexOf(' ', curIndex);
                stats[j] = (byte) AggrxNumbers.parseInt(s.substring(curIndex, nextIndex == -1 ? s.length() : nextIndex), 0);
                curIndex = nextIndex + 1;
            }

            PokemonData data = dataMap.get(i.id());
            if (data != null) {
                data.stats = stats;
            }
        });
    }

    /**
     * Calculate the specified stat of an unknown pokemon in a specified generation (Enemy?)
     *
     * @param ID     Unique ID
     * @param stat   which stat 0-5
     * @param gen    int generation
     * @param level  pokemon level
     * @param minmax 0 minimized, 1 maximized.
     * @return calculated stat
     */

    public static int calcMinMaxStat(UniqueID ID, int stat, int gen, int level, int minmax) {
        int doubleStat = 2 * stat(ID, stat, gen);
        int maxValue = minmax == 1 ? 31 : 0;
        int genValue = gen <= 2 ? 1 : 0;
        int maxValue2 = minmax == 1 ? 252 : 0;
        double x = ((doubleStat + maxValue * (1 + genValue) + maxValue2 / 4.0) * level) / 100.0;
        if (stat == 0) {
            return (int) Math.floor(x + 5 + 5 + level);
        } else {
            double base = Math.floor(x + 5);
            return (int) Math.floor(base + (minmax == 1 ? 1 : -1) * (base / 10));
        }
    }

    /**
     * For BattleActivity to return a pokeball instead of a missigno icon. Implements caching
     *
     * @return drawable of "pi_status.png"
     */

    @SuppressLint("UseCompatLoadingForDrawables")
    public static Drawable iconDrawablePokeBallStatus() {
        String iconKey = "pi_status";

        Drawable drawable = ImageCache.get(iconKey);
        if (drawable == null) {
            //int i = InfoConfig.getIdentifier(iconKey, "drawable");
            drawable = InfoConfig.getDrawable(R.drawable.pi_status);
            ImageCache.put(iconKey, drawable);
        }
        Drawable.ConstantState constantState = drawable.mutate().getConstantState();
        if (constantState == null) {
            return null;
        }
        return constantState.newDrawable();
    }

    /**
     * Returns drawable of specified UniqueID. Implements caching
     *
     * @param uid UniqueID
     * @return drawable of uid
     */

    public static Drawable iconDrawableCache(UniqueID uid) {
        String iconKey = "pi" + uid.toString();
        Drawable drawable = ImageCache.get(iconKey);
        if (drawable == null) {
            drawable = iconDrawable(uid);
            ImageCache.put(iconKey, drawable);
        }
        Drawable.ConstantState constantState = drawable.mutate().getConstantState();
        if (constantState == null) {
            return null;
        }
        return constantState.newDrawable();
    }

    /**
     * Attempts to get Drawable of a UniqueID. Handles missing resource errors
     *
     * @param uid UniqueID
     * @return Drawable of uid
     */

    @SuppressLint("UseCompatLoadingForDrawables")
    public static Drawable iconDrawable(UniqueID uid) {
        Drawable defaultDrawable = InfoConfig.getDrawable(R.drawable.battle_gender_transparent);
        try {
            return InfoConfig.getAssetDrawable(iconRes(uid), defaultDrawable);
        } catch (Resources.NotFoundException e) {
            return InfoConfig.getAssetDrawable(iconRes(uid.original()), defaultDrawable);
        } catch (NullPointerException e) {
            JxLogger.e("NULL ICON" + uid);
            return InfoConfig.getAssetDrawable(iconRes(new UniqueID()), defaultDrawable);
        }
    }

    /**
     * @param uid Unique
     * @return resource identifier of uid
     */

    public static String iconRes(UniqueID uid) {
        if (uid.sub == 0) {
            return "db/pokes/icons/" + uid.main + ".png";
        } else {
            return "db/pokes/icons/" + uid.main + "-" + uid.sub + ".png";
        }
//        Resources resources = InfoConfig.resources;
//        int resID = resources.getIdentifier("pi_" + uid.pokeNum +
//                (uid.subNum == 0 ? "" : "_" + uid.subNum), "drawable", InfoConfig.pkgName);
//        if (resID == 0) {
//            resID = resources.getIdentifier("pi_" + uid.pokeNum, "drawable", InfoConfig.pkgName);
//        }
//        if (resID == 0) {
//            resID = R.drawable.battle_gender_transparent;
//        }
//        return resID;
    }

    /**
     * Get drawable from resources.
     *
     * @param itemId Local resource name.
     * @return Local drawable.
     * @throws android.content.res.Resources.NotFoundException Throws NotFoundException if the given ID does not exist.
     */

    @SuppressLint("UseCompatLoadingForDrawables")
    private static Drawable itemDrawable(int itemId) {
        if (itemId == 0) {
            return DEFAULT_ITEM_DRAWABLE;
        }
        String path = itemRes(itemId);
        return InfoConfig.getAssetDrawable(path, DEFAULT_ITEM_DRAWABLE);
//        //Resources resource = InfoConfig.resources;
//        int identifier = InfoConfig.getIdentifier(itemId, "drawable");
//        if (identifier == 0) {
//            return InfoConfig.getDrawable(R.drawable.i0) ;
//        }
//        return InfoConfig.getDrawable(identifier);
    }

    @NonNull
    public static String itemRes(int itemId) {
        boolean isBerry = (itemId > BERRY_ICON_BASE);
        String path;
        if (isBerry) {
            path = BERRY_ICON_DIR + (itemId - BERRY_ICON_BASE) + ".png";
        } else {
            path = ITEM_ICON_DIR + itemId + ".png";
        }
        return path;
    }

    /**
     * Attempts to get Drawable from Cache, if not it reads from file then writes it to cache.
     *
     * @param itemId x
     * @return Drawable from cache or directly from local.
     */

    public static Drawable itemDrawableCache(int itemId) {
        String itemKey = "i" + itemId;
        Drawable drawable = ImageCache.get(itemKey);
        if (drawable == null) {
            drawable = itemDrawable(itemId);
            ImageCache.put(itemKey, drawable);
        }
        return drawable;
    }

    /**
     * Attempts to get Drawable from Cache, if not it reads from file then writes it to cache.
     *
     * @param gender 0, 1 or 2
     * @return Drawable from cache or directly from local.
     */

    public static Drawable genderDrawableCache(Integer gender) {
        String genderKey = "battle_gender" + gender.toString();
        Drawable drawable = ImageCache.get(genderKey);
        if (drawable == null) {
            drawable = genderDrawable(genderKey);
            ImageCache.put(genderKey, drawable);
        }
        return drawable;
    }

    /**
     * Get drawable from resources.
     *
     * @param key Local resource name.
     * @return Local drawable.
     * @throws android.content.res.Resources.NotFoundException Throws NotFoundException if the given ID does not exist.
     */

    @SuppressLint("UseCompatLoadingForDrawables")
    private static Drawable genderDrawable(String key) {
        //Resources resource = InfoConfig.resources;
        int identifier = InfoConfig.getIdentifier(key, "drawable"/*, InfoConfig.pkgName*/);
        if (identifier == 0) {
            return InfoConfig.getDrawable(R.drawable.battle_gender_transparent);
        }
        return InfoConfig.getDrawable(identifier);
    }

    public static String getSpritePath(UniqueID uID, boolean shiny, boolean female, boolean front) {
        if (uID.main < 0) {
            return "empty_sprite";
        } else {
            String direction = SPRITES_ROOT;
            if (!front) {
                direction = SPRITES_ROOT + "/back";
            }

            // shiny
            if (shiny) {
                direction += "/shiny";
            }

            String pokeName = (uID.sub == 0) ? (uID.main + "") : (uID.main + "-" + uID.sub);

            // sexy
            if (female) {
                String temp = direction;
                temp += "/female";
                String s = temp + "/" + pokeName + ".png";
                if (InfoConfig.fileExists(s)) {
                    direction = temp;
                }
            }

            return direction + "/" + pokeName + ".png";
        }
    }

    /**
     * @param poke  pokemon
     * @param front front or back
     * @return string for resources.getIdentifier()
     */

    public static String sprite(ShallowBattlePoke poke, boolean front) {
        UniqueID uID;
        if (poke.specialSprites.isEmpty()) {
            uID = poke.uID;
        } else {
            uID = poke.specialSprites.peek();
        }
        if (uID == null) {
            return "";
        }

        return getSpritePath(uID, poke.shiny, poke.gender == GenderInfo.Gender.Female.ordinal(), front);
//        if (uID.main < 0) {
//            return "empty_sprite";
//        } else {
//            String direction = SPRITES_ROOT;
//            if (!front) {
//                direction = SPRITES_ROOT + "/back";
//            }
//
//            // shiny
//            if (poke.shiny) {
//                direction += "/shiny";
//            }
//
//            String pokeName = (uID.sub == 0) ? (uID.main + "") : (uID.main + "-" + uID.sub);
//
//            // sexy
//            if (poke.gender == GenderInfo.Gender.Female.ordinal()) {
//                String temp = direction;
//                temp += "/female";
//                String s = temp + "/" + pokeName + ".png";
//                if (InfoConfig.fileExists(s)) {
//                    direction = temp;
//                }
//            }
//
//            return direction + "/" + pokeName + ".png";
////            res = "p" + uID.pokeNum + (uID.subNum == 0 ? "" : "_" + uID.subNum) +
////                    (front ? "_front" : "_back");
////            if (poke.gender == GenderInfo.Gender.Female.ordinal()) {
////                if (InfoConfig.resources.getIdentifier(res + "f", "drawable", InfoConfig.pkgName) != 0 && poke.gender == GenderInfo.Gender.Female.ordinal())
////                // Special female sprite
////                {
////                    res = res + "f";
////                }
////            }
////            if (poke.shiny) {
////                if (InfoConfig.resources.getIdentifier(res + "s", "drawable", InfoConfig.pkgName) != 0) {
////                    res += (poke.shiny ? "s" : "");
////                }
////            }
//        }
//        int ident = InfoConfig.resources.getIdentifier(res, "drawable", InfoConfig.pkgName);
//        if (ident == 0) {
//            // No sprite found. Default to missingNo.
//            if (front) {
//                return "missing_no.png";
//            } else {
//                return sprite(poke, true);
//            }
//        } else {
//            return res + ".png";
//        }
    }

    /**
     * Returns the status of the ImageCache
     *
     * @return ImageCache.toString()
     */
    public static String cacheStatus() {
        return ImageCache.toString();
    }

    /**
     * @param gen Generation to load
     * @return Array of names
     */

    public static String[] nameArray(Gen gen) {
        String[] ret = new String[numberOfPokemons(gen) + 1]; //+1 for missing_no

        for (UniqueID id : namesToIds.values()) {
            if (id.sub == 0 && id.main < ret.length) {
                ret[id.main] = name(id);
            }
        }
        return ret;
    }

    /**
     * Name of pokemon by dex number
     *
     * @param uID UniqueID of pokemon
     * @return Gets standard name from uID
     */

    public static String name(UniqueID uID) {
        loadPokeNames();
        return pokeNames.get(uID.id());
    }

    /**
     * Number of pokemon in specified generation
     *
     * @param gen Generation
     * @return Number of pokemon in Generation given
     */

    public static List<UniqueID> ids(Gen gen) {
        testLoad(gen.num);
        Map<String, PokemonData> map = generations.get(gen.num);
        ArrayList<String> strings = new ArrayList<>(map.keySet());
        List<UniqueID> newStrings = AggrxLists.map(strings, (item, index, list) -> {
            UniqueID u1 = new UniqueID(item);
            if (TextUtils.isEmpty(name(u1))) {
                return null;
            }
            return u1;
        }, o -> o != null);

        Collections.sort(newStrings, (u1, u2) -> {
            //UniqueID u1 = new UniqueID(o1);
            //UniqueID u2 = new UniqueID(o2);
            int result = Integer.compare(u1.main, u2.main);
            if (result != 0) {
                return result;
            }
            result = Integer.compare(u1.sub, u2.sub);
            if (result != 0) {
                return result;
            }
            //result = u1.other.compareTo(u2.other);
            return result;
        });
        return newStrings;
    }

    public static int numberOfPokemons(Gen gen) {
        testLoad(gen.num);
        Map<String, PokemonData> map = generations.get(gen.num);
        if (map == null) {
            return 0;
        }
        return map.size();
    }

	/*
	public static int numberOfPokemons() {
		loadPokeNames();

		return pokeCount;
	}

	public static int totalNumberOfPokemons() {
		loadPokeNames();

		return pokeNames.size();
	}
	*/

    /**
     * Get allowed abilities for pokemon in specified gen
     *
     * @param id  UniqueID
     * @param gen int generation
     * @return abilities
     */

    public static short[] abilities(UniqueID id, int gen) {
        testLoadAbilities(id, gen);

        Map<String, PokemonData> map = generations.get(gen);
        short[] abilities = map.get(id.id()).ability;

        if (abilities == null) {
            abilities = map.get(id.main + "").ability;
        }
        return abilities;
    }

    /**
     * Fill Ability array
     *
     * @param id  UniqueID
     * @param gen int Generation
     */

    private static void testLoadAbilities(UniqueID id, int gen) {
        if (gen >= 3) {
            testLoad(gen);
            Map<String, PokemonData> pokemonsInGeneration = generations.get(gen);
            PokemonData pokemonData = pokemonsInGeneration.get(id.main + "");
            if (pokemonData != null && pokemonData.ability != null) {
                return;
            }

            String ability1File = PokemonStorage.getGenAbility1File(gen);
            InfoFiller.uID_fill(ability1File, (i, s, o) -> {
                PokemonData pokemonData1 = pokemonsInGeneration.get(i.id());
                if (pokemonData1 != null) {
                    pokemonData1.updateAbility(0, AggrxNumbers.parseShort(s, (short) 0));
                } else {
                    // JxLogger.w("Impossible to load ability 1 %s from %s", o, ability1File);
                }
            });
            String ability2File = PokemonStorage.getGenAbility2File(gen);
            InfoFiller.uID_fill(ability2File, (i, s, o) -> {
                PokemonData pokemonData1 = pokemonsInGeneration.get(i.id());
                if (pokemonData1 != null) {
                    pokemonData1.updateAbility(1, AggrxNumbers.parseShort(s, (short) 0));
                } else {
                    // JxLogger.w("Impossible to load ability 2 %s from %s", o, ability2File);
                }
            });
            String ability3File = PokemonStorage.getGenAbility3File(gen);
            InfoFiller.uID_fill(ability3File, (i, s, o) -> {
                PokemonData pokemonData1 = pokemonsInGeneration.get(i.id());
                if (pokemonData1 != null) {
                    pokemonData1.updateAbility(2, AggrxNumbers.parseShort(s, (short) 0));
                } else {
                    // JxLogger.w("Impossible to load ability 3 %s from %s", o, ability3File);
                }
            });
        }
    }

    /**
     * Search for pokemon name
     *
     * @param name Pokemon Name
     * @return UniqueID of pokemon
     */

    public static UniqueID number(String name) {
        return namesToIds.get(name);
    }

    /**
     * Return possible genders for a pokemon
     *
     * @param uID UniqueID
     * @return gender
     */

    public static int gender(UniqueID uID) {
        testLoadGenders();

        PokemonExtraData data = pokemonDataList.get(uID.id());
        if (data == null) {
            return 0;
        }
        byte gender = data.gender;
        if (gender == -1) {
            gender = pokemonDataList.get(uID.main + "").gender;
        }

        return gender == -1 ? 0 : gender;
    }

    /**
     * Load Gender information
     */

    private static void testLoadGenders() {
        if (!gendersLoaded) {
            loadPokeNames();
            gendersLoaded = true;

            InfoFiller.uID_fill(PokemonStorage.getGenderPath(), (i, b, o) -> {
                PokemonExtraData pokemonExtraData = pokemonDataList.get(i.id());
                if (pokemonExtraData != null) {
                    pokemonExtraData.gender = (byte) AggrxNumbers.parseInt(b, 0);
                }
            });
        }
    }

    /**
     * Pokemon Data object
     */

    static class PokemonData {
        byte type1 = -1;
        byte type2 = -1;
        short[] ability = null;
        short[] moves = null;
        String moveString = null;
        byte[] stats = null;

        public void updateAbility(int index, short value) {
            if (ability == null) {
                ability = new short[]{0, 0, 0};
            }
            ability[index] = value;
        }
    }

    /**
     * Extra PokeData object
     */

    static class PokemonExtraData {
        // byte maxFormes = 0;
        byte gender = -1;
        String options = null;
        List<UniqueID> ids = new ArrayList<>();
    }
}
