package com.podevs.android.pokeman.settings;

import android.os.Bundle;

import com.jx.scaffold.JxLogger;
import com.podevs.android.pokeman.NetworkService;
import com.podevs.android.pokeman.app.BaseActivity;

public class SetPreferenceActivity extends BaseActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getFragmentManager().beginTransaction().replace(android.R.id.content, new Settings()).commit();
    }

    @Override
    public void onBackPressed() {
        try {
            NetworkService.loadSettings();
        } catch (Exception e) {
            JxLogger.e("FAILURE TO CALL NETWORK");
        }
        super.onBackPressed();
    }

}
