package com.podevs.android.pokeman.teambuilder;

import android.annotation.TargetApi;
import android.app.Activity;
import android.app.ActivityManager;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ConfigurationInfo;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.SparseArray;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;

import androidx.fragment.app.Fragment;
import androidx.viewpager.widget.PagerAdapter;
import androidx.viewpager.widget.ViewPager;

import com.jx.scaffold.JxLogger;
import com.podevs.android.pokeman.R;
import com.podevs.android.pokeman.TrainerInfo;
import com.podevs.android.pokeman.player.PlayerProfile;
import com.podevs.android.pokeman.poke.Gen;
import com.podevs.android.pokeman.poke.Team;
import com.podevs.android.pokeman.pokeinfo.GenInfo;
import com.podevs.android.pokeman.pokeinfo.InfoConfig;
import com.podevs.android.utilities.QColor;

import java.util.Set;

//import androidx.fragment.app.Fragment;
//import androidx.viewpager.widget.ViewPager;

@TargetApi(Build.VERSION_CODES.HONEYCOMB)
public class TrainerFragment extends Fragment {
    protected static final String TAG = "Trainer menu";
    private PlayerProfile p = null;
    private boolean profileChanged = false;
    private AutoCompleteTextView teamTier = null;
    private Spinner genChooser = null;
    private static final String rootPath = "ui/Trainer/";


    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == TeamCreatorActivity.PICK_COLOR_RESULT_CODE && resultCode == Activity.RESULT_OK) {
            int colorInt = data.getIntExtra("org.openintents.extra.COLOR", p.color.colorInt);
            p.color = new QColor(colorInt);
            profileChanged = true;
        } else if (requestCode == TeamCreatorActivity.COLOR_PICKER_RESULT_CODE && resultCode == Activity.RESULT_OK) {
            int colorInt = data.getIntExtra("color", p.color.colorInt);
            p.color = new QColor(colorInt);
            profileChanged = true;
        }
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        p = new PlayerProfile(getActivity());
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.teambuilder_root, container, false);

        Button importbutton = v.findViewById(R.id.import_team_button);
        //Register onClick listener
        importbutton.setOnClickListener(v12 -> ((TeamCreatorActivity) getActivity()).onImportClicked());

        Button editTeamButton = v.findViewById(R.id.editteam);
        editTeamButton.setOnClickListener(arg0 -> ((TeamCreatorActivity) getActivity()).viewPager.setCurrentItem(1, true));

        ((EditText) v.findViewById(R.id.name)).append(p.nick);
        ((EditText) v.findViewById(R.id.trainerInfo)).setText(p.trainerInfo.info);
        ((EditText) v.findViewById(R.id.winning_message)).setText(p.trainerInfo.winMsg);
        ((EditText) v.findViewById(R.id.losing_message)).setText(p.trainerInfo.loseMsg);

        teamTier = v.findViewById(R.id.teamTier);
        genChooser = v.findViewById(R.id.gens);
        ArrayAdapter<CharSequence> genAdapter = new ArrayAdapter<>(getActivity(), R.layout.pokemon_detail_fragment_nature_choose_item);
        for (int i = GenInfo.genMin(); i <= GenInfo.genMax(); i++) {
            for (int j = 0; j <= GenInfo.maxSubgen(i); j++) {
                genAdapter.add(GenInfo.name(new Gen(i, j)));
            }
        }
        genChooser.setAdapter(genAdapter);
        genChooser.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String genName = parent.getItemAtPosition(position).toString();
                getTeam().setGen(GenInfo.version(genName));
                getTeambuilder().teamChanged = true;
                getTeambuilder().onGenChanged();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        updateTeam();

        teamTier.addTextChangedListener(new TextWatcher() {

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count,
                                          int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }

            @Override
            public void afterTextChanged(Editable s) {
                getTeam().defaultTier = s.toString();
                getTeambuilder().teamChanged = true;
            }
        });

        Set<String> set = getActivity().getSharedPreferences("tiers", Context.MODE_PRIVATE).getStringSet("list", null);

        if (set != null) {
            teamTier.setAdapter(new ArrayAdapter<>(getActivity(),
                    android.R.layout.simple_dropdown_item_1line, set.toArray(new String[0])));
        }

        Button colorButton = v.findViewById(R.id.color);
        colorButton.setOnClickListener(v1 -> {
            ActivityManager activityManager = (ActivityManager) getActivity().getSystemService(Context.ACTIVITY_SERVICE);
            ConfigurationInfo configurationInfo = activityManager.getDeviceConfigurationInfo();
            boolean supportsEs2 = configurationInfo.reqGlEsVersion >= 0x20000;

            if (supportsEs2) {
                Intent intent = new Intent(getActivity(), ColorPickerActivity.class);
                intent.putExtra("color", p.color.colorInt);

                startActivityForResult(intent, TeamCreatorActivity.COLOR_PICKER_RESULT_CODE);
            } else {
                Intent intent = new Intent("org.openintents.action.PICK_COLOR");
                intent.putExtra("org.openintents.extra.COLOR", p.color.colorInt);

                try {
                    startActivityForResult(intent, TeamCreatorActivity.PICK_COLOR_RESULT_CODE);
                } catch (ActivityNotFoundException e) {
                    showDownloadDialog();
                }
            }
        });

        colorButton.setTag(R.id.color, p.color.colorInt);

        ViewPager avatars = v.findViewById(R.id.avatarChooser);
        avatars.setAdapter(new AvatarAdapter());
        avatars.setCurrentItem(p.trainerInfo.avatar, true);

        return v;
    }

    private AlertDialog showDownloadDialog() {
        AlertDialog.Builder downloadDialog = new AlertDialog.Builder(getActivity());
        downloadDialog.setTitle("Download color picker");
        downloadDialog.setMessage("The color picker app doesn't seem to be installed!");
        downloadDialog.setPositiveButton("Download", (dialogInterface, i) -> {
            String packageName = "org.openintents.colorpicker";
            Uri uri = Uri.parse("market://details?id=" + packageName);
            Intent intent = new Intent(Intent.ACTION_VIEW, uri);
            try {
                startActivity(intent);
            } catch (ActivityNotFoundException anfe) {
                // Hmm, market is not installed
                JxLogger.w("Google Play is not installed; cannot install " + packageName);
            }
        });
        downloadDialog.setNegativeButton(R.string.title_cancel_button, (dialogInterface, i) -> {
        });
        return downloadDialog.show();
    }

    public void updateTeam() {
        String tier = getTeam().defaultTier;
        teamTier.setText(tier);

        String genName = GenInfo.name(getTeam().gen);

        if (!genChooser.getSelectedItem().toString().equals(genName)) {
            for (int i = 0; i < genChooser.getCount(); i++) {
                if (genChooser.getItemAtPosition(i).toString().equals(genName)) {
                    genChooser.setSelection(i);
                    break;
                }
            }
        }
    }

    private Team getTeam() {
        return getTeambuilder().team;
    }

    public TeamCreatorActivity getTeambuilder() {
        return ((TeamCreatorActivity) getActivity());
    }

    @Override
    public void onPause() {
        /* Implement user changes */
        PlayerProfile p2 = new PlayerProfile();
        View v = getView();
        p2.nick = ((EditText) v.findViewById(R.id.name)).getText().toString();
        p2.trainerInfo.info = ((EditText) v.findViewById(R.id.trainerInfo)).getText().toString();
        p2.trainerInfo.winMsg = ((EditText) v.findViewById(R.id.winning_message)).getText().toString();
        p2.trainerInfo.loseMsg = ((EditText) v.findViewById(R.id.losing_message)).getText().toString();
        p2.color = p.color;
        p2.trainerInfo.avatar = p.trainerInfo.avatar;

        if (profileChanged || !p2.equals(p)) {
            getActivity().setResult(Activity.RESULT_OK);
            p2.save(getActivity());
            p = p2;
            profileChanged = false;
        }

        super.onPause();
    }

    private class AvatarAdapter extends PagerAdapter {
        final SparseArray<View> items = new SparseArray<>();

        @Override
        public int getCount() {
            return TrainerInfo.COUNT;
        }

        @Override
        public Object instantiateItem(ViewGroup container, int position) {
            //Resources resources = InfoConfig.resources;

            Drawable drawable = InfoConfig.getAssetDrawable(TrainerInfo.trainerRes(position), null);

            ImageView v = new ImageView(getActivity());
            if (drawable != null) {
                v.setImageDrawable(drawable);
            }

            v.setTag(R.id.avatar, position);
            container.addView(v);
            items.put(position, v);

            if (position != p.trainerInfo.avatar) {
                v.setAlpha(0.4f);
            }

            v.setOnClickListener(v1 -> {
                int avatar = (Integer) v1.getTag(R.id.avatar);
                int oldAv = p.trainerInfo.avatar;

                p.trainerInfo.avatar = (short) avatar;
                profileChanged = true;

                if (items.get(oldAv) != null) {
                    items.get(oldAv).setAlpha(0.4f);
                }
                v1.setAlpha(1.0f);
            });

            return v;

        }

        @Override
        public void destroyItem(ViewGroup container, int position, Object object) {
            container.removeView((View) object);
            items.remove(position);
        }

        @Override
        public boolean isViewFromObject(View arg0, Object arg1) {
            return arg0 == arg1;
        }

        @Override
        public float getPageWidth(int position) {
            return 0.25f;
        }
    }
}
