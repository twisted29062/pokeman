package com.podevs.android.pokeman.pokeinfo;

import android.util.SparseArray;

import java.util.ArrayList;
import java.util.Collections;

public class ItemInfo {
    private static final SparseArray<String> ITEM_NAMES = new SparseArray<>();
    private static SparseArray<String> itemMessages = null;
    private static int[] usefulItems = null;
    private static int[] usefulThisGeneration = null;
    private static final short[] plates = new short[]{
            0,
            188,
            196,
            201,
            187,
            199,
            192,
            198,
            193,
            189,
            197,
            194,
            202,
            195,
            191,
            185,
            186,
            330,
            0
    };
    private static final short[] MEMORY_CHIPS = new short[]{
            // 344-360
            0, 344, 345, 346, 347, 348, 349, 350, 351, 352, 353, 354, 355, 356, 357, 358, 359, 360, 0
    };
    private static final short[] Z_MOVES = new short[]{
            673, 674, 675, 676, 677, 678, 679, 680, 681, 682, 683, 684, 685, 686, 687,
            688, 689, 690, 691, 692, 693, 694, 695, 696, 697, 698, 699, 700, 701, 702, 703,
            708, 706, 707, 710
    };

    public static void setGeneration(byte gen) {
        usefulThisGeneration = null;
        if (gen < 2) {
            gen = 2;
        }
        PokemonStorage.Generation = gen;
    }

    public static String name(int item) {
        if (ITEM_NAMES.indexOfKey(item) < 0) {
            loadItemNames();
        }

        return ITEM_NAMES.get(item, "");
    }

    public static int indexOf(String s) {
        if (ITEM_NAMES.indexOfKey(1) < 0) {
            loadItemNames();
        }

        for (int i = 0; i < ITEM_NAMES.size(); i++) {
            if (ITEM_NAMES.get(ITEM_NAMES.keyAt(i), "").equals(s)) {
                return ITEM_NAMES.keyAt(i);
            }
        }
        return 15;
    }

    private static void loadItemNames() {
        String path;
        path = PokemonStorage.getItemsPath();
        InfoFiller.fill(path, (i, b, o) -> ITEM_NAMES.put(i, b));
        path = PokemonStorage.getBerriesPath();
        InfoFiller.fill(path, (i, b, o) -> ITEM_NAMES.put(PokemonInfo.BERRY_ICON_BASE + i, b));
    }

    public static int indexOf(int i) {
        return ITEM_NAMES.keyAt(i);
    }

    public static String message(int num, int part) {
        if (itemMessages == null) {
            loadItemMessages();
        }

        String[] parts = (itemMessages.get(num, "")).split("\\|");
        try {
            return parts[part];
        } catch (ArrayIndexOutOfBoundsException ex) {
            return "";
        }
    }

    private static void loadItemMessages() {
        itemMessages = new SparseArray<>();
        String path = PokemonStorage.getItemMessagesString();
        InfoFiller.fill(path, (i, b, o) -> itemMessages.put(i, b));
        path = PokemonStorage.getBerryMessagesPath();
        InfoFiller.fill(path, (i, b, o) -> itemMessages.put(PokemonInfo.BERRY_ICON_BASE + i, b));
    }

    public static int[] getUsefulThisGeneration() {
        if (usefulThisGeneration == null) {
            if (usefulItems == null) {
                loadUsefulItems();
            }
            loadGenerationItems();
        }
        return usefulThisGeneration;
    }

    public static short plateForType(int type) {
        return plates[type];
    }

    public static short memoryChipForType(int type) {
        return MEMORY_CHIPS[type];
    }

    public static short zCrystalMove(short item) {
        if (item < 3000 || item >= 4000) {
            return 0;
        }
        return Z_MOVES[item - 3000];
    }

    private static void loadUsefulItems() {
        final ArrayList<Integer> items = new ArrayList<>();

        InfoFiller.plainFill(PokemonStorage.getUsefulItemPath(), (i, s, o) -> items.add(i));

        /* Sort item names */
        Collections.sort(items, (lhs, rhs) -> name(lhs).compareTo(name(rhs)));

        final ArrayList<Integer> berries = new ArrayList<>();

        InfoFiller.plainFill(PokemonStorage.getBerryUsefulPath(), (i, s, o) -> berries.add(PokemonInfo.BERRY_ICON_BASE + i));

        /* Sort item names */
        Collections.sort(berries, (lhs, rhs) -> name(lhs).compareTo(name(rhs)));

        usefulItems = new int[items.size() + berries.size()];

        for (int i = 0; i < items.size(); i++) {
            usefulItems[i] = items.get(i);
        }

        for (int i = 0; i < berries.size(); i++) {
            usefulItems[i + items.size()] = berries.get(i);
        }
    }

    private static boolean primitiveContains(int toFind) {
        for (int usefulItem : usefulItems) {
            if (usefulItem == toFind) {
                return true;
            }
        }
        return false;
    }

    private static void loadGenerationItems() {
        final ArrayList<Integer> releasedItems = new ArrayList<>();

        InfoFiller.plainFill(PokemonStorage.get2GReleasedItemsPath(), (i, s, o) -> releasedItems.add(i));

        for (int i = releasedItems.size() - 1; i > -1; i--) {
            if (!primitiveContains(releasedItems.get(i))) {
                releasedItems.remove(releasedItems.get(i));
            }
        }

        Collections.sort(releasedItems, (lhs, rhs) -> name(lhs).compareTo(name(rhs)));

        final ArrayList<Integer> releasedBerries = new ArrayList<>();

        InfoFiller.plainFill(PokemonStorage.getG2ReleasedBerryPath(), (i, s, o) -> releasedBerries.add(8000 + i));

        for (int i = releasedBerries.size() - 1; i > -1; i--) {
            if (!primitiveContains(releasedBerries.get(i))) {
                releasedBerries.remove(releasedBerries.get(i));
            }
        }

        Collections.sort(releasedBerries, (lhs, rhs) -> name(lhs).compareTo(name(rhs)));

        usefulThisGeneration = new int[releasedItems.size() + releasedBerries.size()];

        for (int i = 0; i < releasedItems.size(); i++) {
            usefulThisGeneration[i] = releasedItems.get(i);
        }

        for (int i = 0; i < releasedBerries.size(); i++) {
            usefulThisGeneration[i + releasedItems.size()] = releasedBerries.get(i);
        }
    }

    public static int plateType(short item) {
        for (int i = 0; i < plates.length; i++) {
            if (item == plates[i]) {
                return i;
            }
        }
        return 0;
    }

    public static int memoryType(short item) {
        for (int i = 0; i < MEMORY_CHIPS.length; i++) {
            if (item == MEMORY_CHIPS[i]) {
                return i;
            }
        }
        return 0;
    }
}
