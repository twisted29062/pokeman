package com.podevs.android.utilities;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Filter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.jx.scaffold.JxLogger;
import com.podevs.android.pokeman.R;
import com.podevs.android.pokeman.pokeinfo.PokemonInfo;
import com.podevs.android.widgets.FilterableArrayAdapter;

import java.util.ArrayList;

/**
 * Custom ArrayAdapter of SpinnerData
 */
public class ImageSpinnerAdapter extends FilterableArrayAdapter<SpinnerData> {
    // final static String pkgName = "com.podevs.android.poAndroid";
    public final Resources resources;
    final LayoutInflater inflater;
    private final ArrayList<SpinnerData> data;
    private ArrayList<SpinnerData> fitems;

    int resourceId;

    public ImageSpinnerAdapter(Context spinner, int id, ArrayList<SpinnerData> objects, Resources resources) {

        super(spinner, id, objects);
        resourceId = id;
        data = objects;
        fitems = objects;

        this.resources = resources;

        inflater = (LayoutInflater) spinner.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @NonNull
    @Override
    public View getView(int position, View convertView, @NonNull ViewGroup parent) {
        return getCustomView(position, convertView, parent, true);
    }

    @Override
    public View getDropDownView(int position, View convertView, @NonNull ViewGroup parent) {
        return getCustomView(position, convertView, parent, false);
    }

    public View getCustomView(int position, View row, ViewGroup parent, boolean useOriginal) {
        if (row == null) {
            row = inflater.inflate(R.layout.item_chooser_row_item, parent, false);
        }

        SpinnerData value;
        if (useOriginal) {
            value = data.get(position);
        } else {
            value = fitems.get(position);
        }

        TextView text = row.findViewById(R.id.text);
        ImageView image = row.findViewById(R.id.image);
        Drawable img = PokemonInfo.itemDrawableCache(value.key);
        // img.setBounds(0, 0, 32, 32);

        text.setText(value.text);
        // text.setCompoundDrawables(img, null, null, null);
        if (image != null) {
            image.setImageDrawable(img);
        } else {
            JxLogger.w("%d %s", value.key, value.text);
        }


        return row;
    }

    private Filter filter;

    @Override
    public Filter getFilter() {
        if (filter == null)
            filter = new SpinnerFilter(data);

        return filter;
    }

    @Override
    protected ImageSpinnerAdapter filterResult(CharSequence constraint) {
        String prefix = constraint.toString().toLowerCase();
        if (prefix == null || prefix.length() == 0) {
            ArrayList<SpinnerData> list = new ArrayList<>(data);
            return new ImageSpinnerAdapter(getContext(), resourceId, list, resources);
        } else {
            final ArrayList<SpinnerData> list = new ArrayList<>(data);
            final ArrayList<SpinnerData> result = new ArrayList<>();
            int count = list.size();

            for (int i = 0; i < count; i++) {
                final SpinnerData item = list.get(i);
                final String value = item.text.toString().toLowerCase();

                if (value.startsWith(prefix)) {
                    result.add(item);
                }
            }

            return new ImageSpinnerAdapter(getContext(), resourceId, result, resources);
            // results.values = result;
            // results.count = result.size();
        }

        // return results;
    }

    private class SpinnerFilter extends Filter {
        private final ArrayList<SpinnerData> original;

        private SpinnerFilter(ArrayList<SpinnerData> data) {
            this.original = data;
        }

        @Override
        protected FilterResults performFiltering(CharSequence constraint) {
            FilterResults results = new FilterResults();
            String prefix = constraint.toString().toLowerCase();
            if (prefix == null || prefix.length() == 0) {
                ArrayList<SpinnerData> list = new ArrayList<>(original);
                results.values = list;
                results.count = list.size();
            } else {
                final ArrayList<SpinnerData> list = new ArrayList<>(original);
                final ArrayList<SpinnerData> result = new ArrayList<>();
                int count = list.size();

                for (int i = 0; i < count; i++) {
                    final SpinnerData item = list.get(i);
                    final String value = item.text.toString().toLowerCase();

                    if (value.startsWith(prefix)) {
                        result.add(item);
                    }
                }
                results.values = result;
                results.count = result.size();
            }

            return results;
        }

        @Override
        protected void publishResults(CharSequence charSequence, FilterResults results) {
            fitems = (ArrayList<SpinnerData>) results.values;
            if (fitems == null) {
                return;
            }
            clear();
            int count = fitems.size();
            for (int i = 0; i < count; i++) {
                SpinnerData pkmn = fitems.get(i);
                add(pkmn);
            }
        }
    }

}
