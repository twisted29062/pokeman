package com.podevs.android.pokeman;

import android.content.Context;
import android.text.SpannableStringBuilder;
import android.text.method.LinkMovementMethod;
import android.text.util.Linkify;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.podevs.android.pokeman.chat.Channel;

import java.util.LinkedList;
import java.util.ListIterator;

public class MessageListAdapter extends BaseAdapter {
    public static boolean              copyandpaste = false;
    final         LinkedList<TextView> messageViews = new LinkedList<>();
    public final Channel              channel;
    public        int                  lastSeen;
    final Context context;

    public MessageListAdapter(Channel ch, Context ctxt) {
        super();
        channel = ch;
        context = ctxt;
        synchronized (channel.messageList) {
            ListIterator<SpannableStringBuilder> it = channel.messageList.listIterator();
            for (int i = 0; i < channel.messageList.size(); i++) {
                add(it.next());
            }
            lastSeen = channel.lastSeen;
        }
    }

    public void add(SpannableStringBuilder span) {
        TextView toAdd = new TextView(context);
        toAdd.setText(span);

        //Too buggy. Needs custom gesture
        if (copyandpaste) {
            try {
                toAdd.setTextIsSelectable(true);
            } catch (RuntimeException e) {
                e.printStackTrace();
                return;
            }
        }

        if (toAdd.getLinksClickable()) {
            toAdd.setMovementMethod(LinkMovementMethod.getInstance());
        }

        //Linkify.addLinks(toAdd, Linkify.WEB_URLS);
        Linkify.addLinks(toAdd, NetworkService.URL_PATTERN, "");

        messageViews.add(toAdd);
        if (getCount() > Channel.HIST_LIMIT) {
            messageViews.remove();
        }
    }

    @Override public int getCount() {
        return messageViews.size();
    }

    @Override public TextView getItem(int position) {
        return messageViews.get(position);
    }

    @Override public long getItemId(int position) {
        // Required
        return position;
    }

    @Override public View getView(int position, View convertView, ViewGroup parent) {
        return getItem(position);
    }

    @Override
    public boolean isEnabled(int position) {
        return false;
    }
}
