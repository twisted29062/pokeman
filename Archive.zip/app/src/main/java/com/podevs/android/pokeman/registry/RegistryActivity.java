package com.podevs.android.pokeman.registry;

import android.Manifest;
import android.app.ActivityManager;
import android.app.ActivityManager.RunningServiceInfo;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.ComponentName;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.IBinder;
import android.preference.PreferenceManager;
import android.text.InputType;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.Toast;

import androidx.core.app.ActivityCompat;

import com.aggrx.scaffold.AggrxNumbers;
import com.aggrx.scaffold.AggrxRandom;
import com.jx.scaffold.JxLogger;
import com.podevs.android.pokeman.NetworkService;
import com.podevs.android.pokeman.R;
import com.podevs.android.pokeman.app.BaseActivity;
import com.podevs.android.pokeman.chat.ChatActivity;
import com.podevs.android.pokeman.player.FullPlayerInfo;
import com.podevs.android.pokeman.pokeinfo.InfoConfig;
import com.podevs.android.pokeman.registry.RegistryConnectionService.RegistryCommandListener;
import com.podevs.android.pokeman.registry.ServerListAdapter.Server;
import com.podevs.android.pokeman.settings.SetPreferenceActivity;
import com.podevs.android.pokeman.teambuilder.TeamCreatorActivity;
import com.podevs.android.utilities.Baos;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.Locale;

public class RegistryActivity extends BaseActivity implements ServiceConnection, RegistryCommandListener {

    static final String TAG = "RegistryActivity";
    static final int TEAMBUILDER_CODE = 1;
    public static boolean localize_assets = false;
    private ListView servers;
    private boolean viewToggle = false;
    private RelativeLayout registryRoot;
    private ServerListAdapter adapter;
    private EditText editAddr;
    private EditText editName;
    private boolean bound = false;
    private FullPlayerInfo meLoginPlayer = null;
    private SharedPreferences prefs;

    /*
    enum RegistryDialog {
        SelectImportMethod,
        ImportTeamFromFile
    }
    */
    private final OnClickListener registryListener = new OnClickListener() {
        @Override
        public void onClick(View v) {
            if (v == findViewById(R.id.connect_button)) {

                String ipString = editAddr.getText().toString().split(":")[0];
                String portString = "";
                try {
                    portString = editAddr.getText().toString().split(":")[1];
                } catch (ArrayIndexOutOfBoundsException e) {
                    // No need to act
                }
                int portVal = -1;
                try {
                    portVal = AggrxNumbers.parseInt(portString, 0);
                } catch (NumberFormatException e) {
                    // No need to act
                }
                if (portVal < 1 || portVal > 65535) {
                    Toast.makeText(RegistryActivity.this, "Invalid value for port", Toast.LENGTH_LONG).show();
                    return;
                }

                String nick = editName.getText().toString().trim();
                if (nick.length() == 0) {
                    Toast.makeText(RegistryActivity.this, "Please enter a trainer name.", Toast.LENGTH_LONG).show();
                    return;
                }

                meLoginPlayer.profile.nick = nick;

                Intent intent = new Intent(RegistryActivity.this, NetworkService.class);
                intent.putExtra("ip", ipString);
                intent.putExtra("port", portVal);
                intent.putExtra("loginPlayer", new Baos().putBaos(meLoginPlayer).toByteArray());
                prefs.edit().putString("lastAddr", editAddr.getText().toString()).apply();
                meLoginPlayer.profile.save(RegistryActivity.this);

                startService(intent);
                startActivity(new Intent(RegistryActivity.this, ChatActivity.class));
                finish();
            } else if (v == findViewById(R.id.import_team_button)) {
                startActivityForResult(new Intent(RegistryActivity.this, TeamCreatorActivity.class), TEAMBUILDER_CODE);
            } else if (v == findViewById(R.id.settings)) {
                startActivity(new Intent(RegistryActivity.this, SetPreferenceActivity.class));
            }
        }
    };

    /**
     * Called when the activity is first created.
     */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        if (InfoConfig.context == null) {
            InfoConfig.setContext(this);
        }

        if (!(Thread.getDefaultUncaughtExceptionHandler() instanceof CustomExceptionHandler)) {
            Thread.setDefaultUncaughtExceptionHandler(new CustomExceptionHandler(this));
        }

        super.onCreate(savedInstanceState);

        SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(getBaseContext());
        localize_assets = preferences.getBoolean("localize", false);

        if (!getIntent().hasExtra("sticky")) {
            ActivityManager manager = (ActivityManager) getSystemService(ACTIVITY_SERVICE);
            for (RunningServiceInfo service : manager.getRunningServices(Integer.MAX_VALUE)) {
                if ("com.podevs.android.poAndroid.NetworkService".equals(service.service.getClassName())) {
                    startActivity(new Intent(RegistryActivity.this, ChatActivity.class));
                    finish();
                    return;
                }
            }
        }

        if (getIntent().hasExtra("failedConnect")) {
            Toast.makeText(this, "Server connection failed", Toast.LENGTH_LONG).show();
        }

        stopService(new Intent(RegistryActivity.this, NetworkService.class));

        setContentView(R.layout.registry_activity);

        prefs = getPreferences(MODE_PRIVATE);

        editAddr = findViewById(R.id.addr_edit);
        if (editAddr != null)
            editAddr.setText(prefs.getString("lastAddr", ""));
        editName = findViewById(R.id.name_edit);
        // Hide the soft-keyboard when the activity is created
        editName.setInputType(InputType.TYPE_NULL);
        editName.setOnTouchListener((v, event) -> {
            editName.setInputType(InputType.TYPE_CLASS_TEXT);
            editName.onTouchEvent(event);
            return true;
        });

        meLoginPlayer = new FullPlayerInfo(RegistryActivity.this);
        editName.setText(meLoginPlayer.nick());

        //Capture out button from layout
        Button conbutton = findViewById(R.id.connect_button);
        Button importbutton = findViewById(R.id.import_team_button);
        Button setbutton = findViewById(R.id.settings);

        //Register onClick listener
        conbutton.setOnClickListener(registryListener);
        importbutton.setOnClickListener(registryListener);
        setbutton.setOnClickListener(registryListener);

        registryRoot = findViewById(R.id.registry_root);


        int index = AggrxRandom.randomInt(12) + 1;
        String path = String.format(Locale.getDefault(), "ui/Registry/reg_back_%d.png", index);
        Drawable drawable = InfoConfig.getAssetDrawable(path, null);
        if (drawable != null) {
            registryRoot.setBackground(drawable);
        }

        servers = findViewById(R.id.server_listing);
        adapter = new ServerListAdapter(this, R.id.server_listing);
        servers.setAdapter(adapter);
        /* Set the edit texts on list item click */
        servers.setOnItemClickListener((parent, view, position, id) -> {
            Server server = (Server) parent.getItemAtPosition(position);
            editAddr.setText(server.ip + ":" + server.port);
        });


        servers.setOnItemLongClickListener((parent, view, position, id) -> {
            Server server = (Server) parent.getItemAtPosition(position);
            JxLogger.e("Long click works: " + server.desc);
            // TODO: Display server description
            /*Intent intent = new Intent(RegistryActivity.this, RichTextActivity.class);
            intent.putExtra("richtext", server.desc);
            RegistryActivity.this.startActivity(intent); */
            return true;
        });

        Intent intent = new Intent(RegistryActivity.this, RegistryConnectionService.class);
        bound = bindService(intent, this, BIND_AUTO_CREATE);

        checkPermissions();
        checkShouldUpdate(preferences);
    }

    private void checkPermissions() {
        if (Build.VERSION.SDK_INT >= 23 && CustomExceptionHandler.shouldWrite) {
            if (checkSelfPermission(android.Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED) {
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1);
            }
        }
    }

    private void checkShouldUpdate(SharedPreferences prefs) {
        long newTime = System.currentTimeMillis();
        long oldTime = prefs.getLong("timecheck", newTime);
        prefs.edit().putLong("timecheck", newTime).apply();
        if ((newTime - oldTime) > (3600000 * 12)) { // 12 Hours
            // checkForUpdates();
        }
        // checkForUpdates();
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent intent) {
        super.onActivityResult(requestCode, resultCode, intent);
        if (requestCode == TEAMBUILDER_CODE) {
            /* If the teambuilder did something, reload the team */
            //if (resultCode == Activity.RESULT_OK) {
            meLoginPlayer = new FullPlayerInfo(RegistryActivity.this);
            editName.setText(meLoginPlayer.nick());
            //}
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        checkPermissions();
    }

    //    @Override
//    public boolean onMenuItemSelected(int which, MenuItem item) {
//        // XXX Placeholder
//        return true;
//    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        registryRoot.getViewTreeObserver().addOnGlobalLayoutListener(() -> {
            if (!viewToggle) {
                ServerListAdapter oldadapter = adapter;
                setContentView(R.layout.registry_activity);
                servers = findViewById(R.id.server_listing);
                servers.setAdapter(oldadapter);
                viewToggle = true;
            }
            printToast("ONCONFIGURATION CHANGED", Toast.LENGTH_SHORT);
        });
    }

    @Override
    synchronized public void onDestroy() {
        if (bound) {
            unbindService(this);
            bound = false;
        }
        super.onDestroy();
    }

    public void printToast(String s, int len) {
        runOnUiThread(() -> Toast.makeText(RegistryActivity.this, s, len).show());
    }

//    private void checkForUpdates() {
//        new Thread(() -> {
//            try {
//                URL            url   = new URL(UpdateCheck.GITHUB_LINK);
//                BufferedReader in    = new BufferedReader(new InputStreamReader(url.openStream()));
//                String         input = in.readLine();
//                in.close();
//                UpdateCheck newCheck = new UpdateCheck(input);
//                UpdateCheck oldCheck = new UpdateCheck();
//                if (newCheck.getVersion() > oldCheck.getVersion()) {
//                    runOnUiThread(() -> new AlertDialog.Builder(RegistryActivity.this)
//                        .setTitle("Update available")
//                        .setPositiveButton("Download", (dialog, whichButton) -> {
//                            ProgressDialog progressDialog = ProgressDialog.show(RegistryActivity.this, "Downloading...", "", true);
//                            new Thread(() -> {
//                                try {
//                                    String path = Environment.getExternalStorageDirectory() + "/download/";
//                                    File   file = new File(path);
//                                    file.mkdirs();
//                                    File             outputFile = new File(file, "pokemon-online.apk");
//                                    FileOutputStream fos        = new FileOutputStream(outputFile);
//
//                                    URL url1 = new URL(newCheck.getLink());
//
//                                    InputStream is = url1.openStream();
//
//                                    byte[] buffer = new byte[2048];
//                                    int    len1;
//                                    while ((len1 = is.read(buffer)) != -1) {
//                                        fos.write(buffer, 0, len1);
//                                    }
//                                    fos.close();
//                                    is.close();
//
//                                    runOnUiThread(progressDialog::dismiss);
//
//                                    Intent intent = new Intent(Intent.ACTION_VIEW);
//                                    intent.setDataAndType(Uri.fromFile(new File(Environment.getExternalStorageDirectory() + "/download/" + "pokemon-online.apk")), "application/vnd.android.package-archive");
//                                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
//                                    startActivity(intent);
//                                } catch (IOException e) {
//                                    progressDialog.dismiss();
//                                    e.printStackTrace();
//                                }
//                            }).start();
//                        }).setNegativeButton(R.string.decline, (dialog, which) -> dialog.dismiss()).show());
//                }
//            } catch (Exception e) {
//                e.printStackTrace();
//            }
//        }).start();
//    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        super.onCreateOptionsMenu(menu);
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.mainoptions, menu);
        return true;
    }

    @Override
    synchronized public void ServerListEnd() {
        if (!bound) {
            return;
        }
        JxLogger.i("Unbinding registry connection service");
        bound = false;

        try {
            unbindService(RegistryActivity.this);
        } catch (IllegalArgumentException ex) {
            /* Might happen if the registry acitivity was already stopped
             * and the service was unbound from there.
             */
            return;
        }

        runOnUiThread(() -> adapter.sortByPlayers());
    }

    @Override
    synchronized public void onServiceConnected(ComponentName name, IBinder binder) {
        bound = true;
        ((RegistryConnectionService.LocalBinder) binder).connect(this);
    }

    @Override
    synchronized public void onServiceDisconnected(ComponentName name) {
        bound = false;
    }


    @Override
    public void RegistryConnectionClosed() {
        ServerListEnd();
    }


    @Override
    public void NewServer(String name, String desc, short players,
                          String ip, short maxplayers, int port) {
        runOnUiThread(() -> adapter.addServer(name, desc, ip, port, players, maxplayers));
    }


}