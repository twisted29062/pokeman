package com.podevs.android.pokeman.teambuilder;

import android.app.AlertDialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;

import com.aggrx.scaffold.AggrxCast;
import com.aggrx.scaffold.AggrxNumbers;
import com.podevs.android.pokeman.R;
import com.podevs.android.pokeman.poke.TeamPoke;
import com.podevs.android.pokeman.poke.UniqueID;
import com.podevs.android.pokeman.pokeinfo.AbilityInfo;
import com.podevs.android.pokeman.pokeinfo.GenderInfo;
import com.podevs.android.pokeman.pokeinfo.HiddenPowerInfo;
import com.podevs.android.pokeman.pokeinfo.ItemInfo;
import com.podevs.android.pokeman.pokeinfo.NatureInfo;
import com.podevs.android.pokeman.pokeinfo.PokemonInfo;
import com.podevs.android.pokeman.teambuilder.EVSlider.EVListener;
import com.podevs.android.utilities.ImageSpinnerAdapter;
import com.podevs.android.utilities.SpinnerData;
import com.podevs.android.widgets.FilterableChooser;

import java.util.ArrayList;
import java.util.List;


public class PokemonDetailsFragment extends Fragment implements EVListener {
    public PokemonDetailsListener listener = null;
    private EVSlider[] sliders = null;
    private TextView levelChooser = null, happinessChooser = null;
    private Spinner formesChooser = null, abilityChooser = null, natureChooser = null, genderChooser = null;
    private FilterableChooser itemChooser = null;
    private CheckBox shinyChooser = null;
    private LinearLayout formesLayout;
    private ArrayAdapter<CharSequence> abilityChooserAdapter, genderChooserAdapter;
    private Button manualIVButton = null;
    private ToggleButton hackmonButton = null;
    private FormListAdapter formListAdapter;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.pokemon_detail_fragment_layout, container, false);
        FragmentActivity activity = getActivity();
        if (activity == null) {
            return v;
        }

        sliders = new EVSlider[]{
                new EVSlider(v.findViewById(R.id.hp_ev), 0),
                new EVSlider(v.findViewById(R.id.att_ev), 1),
                new EVSlider(v.findViewById(R.id.def_ev), 2),
                new EVSlider(v.findViewById(R.id.spatt_ev), 3),
                new EVSlider(v.findViewById(R.id.spdef_ev), 4),
                new EVSlider(v.findViewById(R.id.speed_ev), 5)
        };

		/*
		labels = new TextView[]{
			(TextView)v.findViewById(R.id.hplabel),
			(TextView)v.findViewById(R.id.attlabel),
			(TextView)v.findViewById(R.id.deflabel),
			(TextView)v.findViewById(R.id.spattlabel),
			(TextView)v.findViewById(R.id.spdeflabel),
			(TextView)v.findViewById(R.id.speedlabel)
		};
		*/

        for (EVSlider slider : sliders) {
            slider.listener = this;
        }

        abilityChooser = v.findViewById(R.id.ability_choice);
        itemChooser = v.findViewById(R.id.item_choice);
        natureChooser = v.findViewById(R.id.nature);
        genderChooser = v.findViewById(R.id.gender);
        formesChooser = v.findViewById(R.id.formes);
        formesLayout = v.findViewById(R.id.formes_layout);
        shinyChooser = v.findViewById(R.id.shiny);
        levelChooser = v.findViewById(R.id.level);
        happinessChooser = v.findViewById(R.id.happiness);
        manualIVButton = v.findViewById(R.id.manual_iv);
        hackmonButton = v.findViewById(R.id.hackmon);

        buildItem(activity);
        buildAbility(activity);
        buildGender(activity);
        buildFormes(activity);
        buildNature(activity);
        buildLevel(activity);
        buildHappiness(activity);
        buildShiny();
        buildManual(activity);
        buildHackmon();

        updatePoke();

        return v;
    }

    private void buildHackmon() {
        hackmonButton.setOnClickListener(v1 -> {
            if (hackmonButton.isChecked()) {
                poke().isHackmon = true;
            } else {
                poke().isHackmon = false;
                resetEVs();
            }
            notifyMoveFragment();
            updatePoke();
        });
    }

    private void buildManual(FragmentActivity activity) {
        manualIVButton.setOnClickListener(v12 -> {
            View view = LayoutInflater.from(activity).inflate(R.layout.iv_changer, null);
            EditText[] inputs = new EditText[6];
            inputs[0] = view.findViewById(R.id.iv1);
            inputs[1] = view.findViewById(R.id.iv2);
            inputs[2] = view.findViewById(R.id.iv3);
            inputs[3] = view.findViewById(R.id.iv4);
            inputs[4] = view.findViewById(R.id.iv5);
            inputs[5] = view.findViewById(R.id.iv6);
            byte gen = poke().gen().num;
            for (int i = 0; i < 6; i++) {
                inputs[i].setText(String.valueOf(poke().dv(i)));
            }
            /*
            for (int i = 0; i < 6; i++) {
                inputs[i].addTextChangedListener(new TextWatcher() {
                    @Override
                    public void afterTextChanged(Editable s) {
                        String test = "";
                    }

                    @Override
                    public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                        String test = "";
                    }

                    @Override
                    public void onTextChanged(CharSequence s, int start, int before, int count) {
                        String test = "";
                    }
                });
            }
            */
            AlertDialog.Builder builder = new AlertDialog.Builder(activity);
            builder.setTitle(R.string.manual_iv)
                    .setView(view)
                    .setPositiveButton(R.string.ok, (dialog, which) -> {
                        for (int i = 0; i < 6; i++) {
                            int temp1;
                            if (inputs[i].getText().toString().length() == 0) {
                                temp1 = 0;
                            } else {
                                temp1 = Integer.decode(inputs[i].getText().toString());
                                if (gen > 2) {
                                    if (temp1 > 31) {
                                        temp1 = 31;
                                    }
                                } else {
                                    if (temp1 > 15) {
                                        temp1 = 15;
                                    }
                                }
                            }
                            poke().DVs[i] = (byte) temp1;
                        }
                        if (!poke().validHiddenPowerType(poke().hiddenPowerType())) {
                            poke().hiddenPowerType = (byte) HiddenPowerInfo.Type(poke());
                        }
                        updateStats();
                    })
                    .setNegativeButton(R.string.cancel, (dialog, which) -> {
                        dialog.dismiss();
                        dialog.cancel();
                    });
            builder.create().show();
        });
    }

    private void buildShiny() {
        shinyChooser.setOnCheckedChangeListener((buttonView, isChecked) -> poke().shiny = isChecked);
    }

    private void buildHappiness(FragmentActivity activity) {
        happinessChooser.setOnClickListener(v13 -> {
            EditText input = new EditText(activity);

            new AlertDialog.Builder(activity)
                    .setTitle(R.string.change_happiness)
                    .setView(input)
                    .setPositiveButton(R.string.ok, (dialog, whichButton) -> {
                        String link = input.getText().toString();
                        int i = 0;
                        if (link.length() != 0) {
                            try {
                                i = AggrxNumbers.parseInt(link, 0);
                            } catch (Exception e) {
                                makeToast("Enter valid number between 0 and 255");
                            }
                        }
                        if (i > 255) {
                            i = 255;
                        }
                        if (i < 0) {
                            i = 0;
                        }
                        poke().happiness = (byte) i;
                        String s = getString(R.string.happiness_short) + " " + i;
                        happinessChooser.setText(s);
                    }).show();
        });
    }

    private void buildLevel(FragmentActivity activity) {
        levelChooser.setOnClickListener(v14 -> {
            EditText input = new EditText(activity);

            new AlertDialog.Builder(activity)
                    .setTitle(R.string.change_level)
                    .setView(input)
                    .setPositiveButton(R.string.ok, (dialog, whichButton) -> {
                        String link = input.getText().toString();
                        int i = 1;
                        if (link.length() != 0) {
                            try {
                                i = AggrxNumbers.parseInt(link, 0);
                            } catch (Exception e) {
                                makeToast("Enter valid number");
                            }
                        }
                        if (i > 100) {
                            i = 100;
                        }
                        if (i < 1) {
                            i = 1;
                        }
                        poke().level = (byte) i;
                        String s = getString(R.string.level_short) + " " + i;
                        levelChooser.setText(s);
                        updateStats();
                    }).show();
        });
    }

    private void buildItem(FragmentActivity activity) {
        ArrayList<SpinnerData> temp = new ArrayList<>();
        int[] usefulItems = ItemInfo.getUsefulThisGeneration();
        for (int usefulItem : usefulItems) {
            SpinnerData tempData = new SpinnerData(ItemInfo.name(usefulItem), usefulItem);
            temp.add(tempData);
        }
        ImageSpinnerAdapter itemChooserAdapter = new ImageSpinnerAdapter(activity, R.layout.item_chooser_row_item, temp, getResources());
        itemChooser.setAdapter(itemChooserAdapter);
        itemChooser.setItemClicked(position -> {
            TeamPoke poke = poke();
            if (poke == null) {
                return;
            }
            int orid = poke.uID().hashCode();

            poke.setItem((short) ItemInfo.getUsefulThisGeneration()[position]);
            notifyUpdated(orid != poke.uID().hashCode());
        });

//        itemChooser.setOnItemSelectedListener(new OnItemSelectedListener() {
//            @Override
//            public void onItemSelected(AdapterView<?> arg0, View arg1,
//                                       int arg2, long arg3) {
//                TeamPoke poke = poke();
//                if (poke == null) {
//                    return;
//                }
//                int orid = poke.uID().hashCode();
//
//                poke.setItem((short) ItemInfo.getUsefulThisGeneration()[arg2]);
//                notifyUpdated(orid != poke.uID().hashCode());
//            }
//
//            @Override
//            public void onNothingSelected(AdapterView<?> arg0) {
//            }
//        });
    }

    private void buildNature(FragmentActivity activity) {
        ArrayAdapter<CharSequence> natureChooserAdapter = new ArrayAdapter<>(activity, R.layout.pokemon_detail_fragment_nature_choose_item
                /* R.layout.pokemon_detail_fragment_nature_choose_item*/);
        for (int i = 0; i < NatureInfo.count(); i++) {
            natureChooserAdapter.add(NatureInfo.boostedName(i));
        }
        natureChooser.setAdapter(natureChooserAdapter);
        natureChooser.setOnItemSelectedListener(new OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> arg0, View arg1,
                                       int arg2, long arg3) {
                TeamPoke poke = poke();
                if (poke == null) {
                    return;
                }
                poke.nature = (byte) arg2;

                updateStats();
                notifyUpdated();
            }

            @Override
            public void onNothingSelected(AdapterView<?> arg0) {
            }
        });
    }

    private void buildFormes(FragmentActivity activity) {
        //formesChooserAdapter = new ArrayAdapter<CharSequence>(getActivity(), R.layout.pokemon_detail_fragment_nature_choose_item);
        formesChooser.setAdapter(formListAdapter = new FormListAdapter(activity, R.layout.forminlist_item, poke().gen()));
        formesChooser.setOnItemSelectedListener(new OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
                poke().setNum((UniqueID) arg0.getItemAtPosition(arg2));
                notifyUpdated(true);
            }

            @Override
            public void onNothingSelected(AdapterView<?> arg0) {
            }
        });
    }

    private void buildGender(FragmentActivity activity) {
        genderChooserAdapter = new ArrayAdapter<>(activity, R.layout.pokemon_detail_fragment_nature_choose_item);
        genderChooser.setAdapter(genderChooserAdapter);
        genderChooser.setOnItemSelectedListener(new OnItemSelectedListener() {

            @Override
            public void onItemSelected(AdapterView<?> arg0, View arg1,
                                       int arg2, long arg3) {
                poke().gender = (byte) GenderInfo.indexOf((String) genderChooserAdapter.getItem(arg2));
                notifyUpdated();
            }

            @Override
            public void onNothingSelected(AdapterView<?> arg0) {
            }
        });
    }

    private void buildAbility(FragmentActivity activity) {
        abilityChooserAdapter = new ArrayAdapter<>(activity, R.layout.pokemon_detail_fragment_nature_choose_item);
        abilityChooser.setAdapter(abilityChooserAdapter);
        abilityChooser.setOnItemSelectedListener(new OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> arg0, View arg1,
                                       int arg2, long arg3) {
                TeamPoke poke = poke();
                if (poke == null) {
                    return;
                }

                if (poke.isHackmon) {
                    Short[] abilities = AbilityInfo.getAllAbilities(poke.gen().num);
                    if (abilities == null) {
                        return;
                    }
                    for (Short ability : abilities) {
                        if (AbilityInfo.name(ability) == abilityChooserAdapter.getItem(arg2)) {
                            poke.ability = ability;
                            notifyUpdated();
                            break;
                        }
                    }
                } else {
                    short[] abilities = PokemonInfo.abilities(poke.uID(), poke.gen.num);
                    for (short ability : abilities) {
                        if (AbilityInfo.name(ability) == abilityChooserAdapter.getItem(arg2)) {
                            poke.ability = ability;
                            notifyUpdated();
                            break;
                        }
                    }
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> arg0) {
            }
        });
    }

    public void notifyMoveFragment() {
        ((MoveChooserFragment) getParentFragmentManager().getFragments().get(3)).updatePoke();
    }

    private void makeToast(String text) {
        Toast.makeText(getActivity(), text, Toast.LENGTH_SHORT).show();
    }

    public void notifyUpdated(boolean b) {
        if (listener != null) {
            listener.onPokemonEdited(b);
        }
    }

    private String tier() {
        return ((EditPokemonActivity) getActivity()).getTier();
    }

    public void updatePoke() {
        TeamPoke teamPoke = poke();
        TeamPoke tempPoke = teamPoke;
        if (tempPoke == null) {
            return;
        }

        if ((tempPoke.gen().num == 6 && tempPoke.gen().subNum == 1 || tempPoke.gen().num >= 7) || "All Gen Hackmons".equals(tier())) {
            hackmonButton.setEnabled(true);
            hackmonButton.setChecked(tempPoke.isHackmon);
        } else {
            hackmonButton.setEnabled(false);
            hackmonButton.setChecked(false);
        }

        if (PokemonInfo.hasVisibleFormes(tempPoke.uID(), tempPoke.gen) || (teamPoke.isHackmon && PokemonInfo.hasHackmonFormes(tempPoke.uID()))) {
            formesLayout.setVisibility(View.VISIBLE);
            formListAdapter.clear();

            List<UniqueID> list;
            if (teamPoke.isHackmon) {
                list = PokemonInfo.formesHackmon(tempPoke.uID(), tempPoke.gen);
            } else {
                list = PokemonInfo.formes(tempPoke.uID(), tempPoke.gen);
            }
            for (UniqueID uID : list) {
                formListAdapter.add(uID);
                if (uID.equals(tempPoke.uID())) {
                    formesChooser.setSelection(formListAdapter.getCount() - 1);
                }
            }
        } else {
            formesLayout.setVisibility(View.GONE);
        }

        for (int i = 0; i < 6; i++) {
            sliders[i].setNum(tempPoke.ev(i));
        }

        updateStats();

        if (tempPoke.gen.num >= 3) {

            abilityChooserAdapter.clear();
            if (!teamPoke.isHackmon) {
                short[] abilities = PokemonInfo.abilities(teamPoke.uID(), tempPoke.gen.num);

                abilityChooserAdapter.add(AbilityInfo.name(abilities[0]));
                if (abilities[0] == tempPoke.ability) {
                    abilityChooser.setSelection(0);
                }
                if (abilities[1] != 0) {
                    abilityChooserAdapter.add(AbilityInfo.name(abilities[1]));
                    if (abilities[1] == tempPoke.ability) {
                        abilityChooser.setSelection(1);
                    }
                }
                if (abilities[2] != 0) {
                    abilityChooserAdapter.add(AbilityInfo.name(abilities[2]));
                    if (abilities[2] == tempPoke.ability) {
                        abilityChooser.setSelection(abilityChooserAdapter.getCount() - 1);
                    }
                }
            } else {
                Short[] abilities = AbilityInfo.getAllAbilities(teamPoke.gen().num);

                if (abilities != null) {
                    for (int i = 0; i <= abilities.length - 1; i++) {
                        abilityChooserAdapter.add(AbilityInfo.name(abilities[i]));
                        if (abilities[i] == tempPoke.ability) {
                            abilityChooser.setSelection(i);
                        }
                    }
                }
            }
            natureChooser.setSelection(tempPoke.nature);
            natureChooser.setVisibility(View.VISIBLE);
            abilityChooser.setVisibility(View.VISIBLE);
        } else {
            natureChooser.setVisibility(View.GONE);
            abilityChooser.setVisibility(View.GONE);
        }

        tempPoke = teamPoke;

        if (tempPoke.gen.num >= 2) {
            genderChooserAdapter.clear();
            if (teamPoke.isHackmon) {
                genderChooserAdapter.add(GenderInfo.name(0));
                genderChooserAdapter.add(GenderInfo.name(1));
                genderChooserAdapter.add(GenderInfo.name(2));
                genderChooser.setSelection(tempPoke.gender == 1 ? 0 : 1);
            } else {
                int genderChoice = PokemonInfo.gender(tempPoke.uID());
                if (genderChoice == 0) {
                    tempPoke.gender = 0;
                    genderChooserAdapter.add(GenderInfo.name(0));
                } else if (genderChoice == 1) {
                    genderChooserAdapter.add(GenderInfo.name(1));
                } else if (genderChoice == 2) {
                    genderChooserAdapter.add(GenderInfo.name(2));
                } else {
                    genderChooserAdapter.add(GenderInfo.name(1));
                    genderChooserAdapter.add(GenderInfo.name(2));
                    genderChooser.setSelection(tempPoke.gender == 1 ? 0 : 1);
                }
            }

            int[] usefulItems = ItemInfo.getUsefulThisGeneration();
            int pokeItem = tempPoke.item();
            for (int i = 0; i < usefulItems.length; i++) {
                if (usefulItems[i] == pokeItem) {
                    itemChooser.setSelection(i);
                    break;
                }
            }
            shinyChooser.setChecked(tempPoke.shiny);
            String s = getString(R.string.happiness_short) + " " + (tempPoke.happiness & 0xFF);
            happinessChooser.setText(s);

            sliders[4].setVisibility(View.VISIBLE);
            shinyChooser.setVisibility(View.VISIBLE);
            genderChooser.setVisibility(View.VISIBLE);
            itemChooser.setVisibility(View.VISIBLE);
            happinessChooser.setVisibility(View.VISIBLE);
            manualIVButton.setEnabled(true);
        } else {
            sliders[4].setVisibility(View.GONE);
            shinyChooser.setVisibility(View.GONE);
            genderChooser.setVisibility(View.GONE);
            itemChooser.setVisibility(View.GONE);
            happinessChooser.setVisibility(View.GONE);
            manualIVButton.setEnabled(false);
        }

        String s = getString(R.string.level_short) + " " + tempPoke.level();
        levelChooser.setText(s);
    }

    public void updateStats() {
        TeamPoke tempPoke = poke();
        if (tempPoke == null) {
            return;
        }

        for (int i = 0; i < 6; i++) {
            sliders[i].setTotal(tempPoke.stat(i));
        }
    }

    @Override
    public void onEVChanged(int stat, int ev) {
        TeamPoke tempPoke = poke();
        if (tempPoke == null) {
            return;
        }

        int totalEVs = tempPoke.totalEVs() - tempPoke.ev(stat) + ev;

        if (!tempPoke.isHackmon) {
            if (totalEVs > 510 && tempPoke.gen().num > 2) {
                ev = (510 - (tempPoke.totalEVs() - tempPoke.ev(stat)));
                ev = ev / 4 * 4;
            }
        }

        if (ev > 252) {
            ev = 252;
        }
        poke().EVs[stat] = (byte) ev;

        sliders[stat].setNum(ev);
        sliders[stat].setTotal(tempPoke.stat(stat));

        notifyUpdated();
    }

    public void notifyUpdated() {
        if (listener != null) {
            listener.onPokemonEdited(false);
        }
    }

    private TeamPoke poke() {
        EditPokemonActivity activity = AggrxCast.cast(getActivity(), (EditPokemonActivity.class));
        if (activity == null) {
            return null;
        }
        return activity.getPoke();
    }

    private void resetEVs() {
        for (int i = 0; i < 6; i++) {
            sliders[i].setNum(0);
            poke().EVs[i] = 0;
            //labels[i].setText(StatsInfo.Shortcut(i) + ": " + poke().stat(i));
            sliders[i].setTotal(poke().stat(i));
        }
    }

    public interface PokemonDetailsListener {
        void onPokemonEdited(boolean updateAll);
    }
}
