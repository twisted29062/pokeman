package com.podevs.android.pokeman.battle;

public class ChallengeEnums {
    public static String clausesToStringHtml(int clauses) {
        StringBuilder s = new StringBuilder();
        for (int i = 0; i < Clauses.values().length; i++) {
            //String clauseNumber = Integer.toBinaryString(1 << i);
            //String clausesID = Integer.toBinaryString(clauses);
            //JxLogger.e("%s","" + clauseNumber);
            //JxLogger.e("%s","" + clausesID);
            if ((clauses & (1 << i)) > 0) {
                //JxLogger.e("%s", "true");
                s.append("<br />").append(Clauses.values()[i].toString());
            }
        }
        return s.toString();
    }

    public enum ChallengeDesc {
        Sent,
        Accepted,
        Cancelled,
        Busy,
        Refused,
        InvalidTeam,
        InvalidGen,
        InvalidTier,

        ChallengeDescLast
    }

    public enum Clauses {
        SleepClause {
            @Override public final int mask() {
                return 1;
            }

            @Override public final String toString() {
                return "Sleep Clause";
            }

            @Override public final String battleText() {
                return "Sleep Clause prevented the sleep inducing effect of the move from working.";
            }
        },
        FreezeClause {
            @Override public final int mask() {
                return 2;
            }

            @Override public final String toString() {
                return "Freeze Clause";
            }

            @Override public final String battleText() {
                return "Freeze Clause prevented the freezing effect of the move from working.";
            }
        },
        DisallowSpectator {
            @Override public final int mask() {
                return 4;
            }

            @Override public final String toString() {
                return "Disallow Spects";
            }

            @Override public final String battleText() {
                return "";
            }
        },
        ItemClause {
            @Override public final int mask() {
                return 8;
            }

            @Override public final String toString() {
                return "Item Clause";
            }

            @Override public final String battleText() {
                return "";
            }
        },
        ChallengeCup {
            @Override public final int mask() {
                return 16;
            }

            @Override public final String toString() {
                return "Challenge Cup";
            }

            @Override public final String battleText() {
                return "";
            }
        },
        NoTimeOut {
            @Override public final int mask() {
                return 32;
            }

            @Override public final String toString() {
                return "No Timeout";
            }

            @Override public final String battleText() {
                return "The battle ended by timeout.";
            }
        },
        SpeciesClause {
            @Override public final int mask() {
                return 64;
            }

            @Override public final String toString() {
                return "Species Clause";
            }

            @Override public final String battleText() {
                return "";
            }
        },
        RearrangeTeams {
            @Override public final int mask() {
                return 128;
            }

            @Override public final String toString() {
                return "Team Preview";
            }

            @Override public final String battleText() {
                return "";
            }
        },
        SelfKO {
            @Override public final int mask() {
                return 256;
            }

            @Override public final String toString() {
                return "Self-KO Clause";
            }

            @Override public final String battleText() {
                return "The Self-KO Clause acted as a tiebreaker.";
            }
        },
        InvertedBattle {
            @Override public final int mask() {
                return 512;
            }

            @Override public final String toString() {
                return "Inverted Battle";
            }

            @Override public final String battleText() {
                return "";
            }
        };

        public abstract int mask();

        public abstract String battleText();
    }

    public enum Mode {
        Singles {
            @Override public final String toString() {
                return "Singles";
            }

            @Override public final int numberOfSlots() {
                return 1;
            }
        },
        Doubles {
            @Override public final String toString() {
                return "Doubles";
            }

            @Override public final int numberOfSlots() {
                return 2;
            }
        },
        Triples {
            @Override public final String toString() {
                return "Triples";
            }

            @Override public final int numberOfSlots() {
                return 3;
            }
        },
        Rotation {
            @Override public final String toString() {
                return "Rotation";
            }

            @Override public final int numberOfSlots() {
                return 3;
            }
        };

        public abstract int numberOfSlots();
    }
}
