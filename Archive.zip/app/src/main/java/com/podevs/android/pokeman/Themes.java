package com.podevs.android.pokeman;

public class Themes {
    public static int themeTeambuilder = R.style.AppTheme;
}
