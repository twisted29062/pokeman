package com.podevs.android.utilities;


public interface SerializeBytes {
    void serializeBytes(Baos output);
}
