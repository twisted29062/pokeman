package com.podevs.android.pokeman.teambuilder;

import android.annotation.SuppressLint;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.SeekBar;
import android.widget.SeekBar.OnSeekBarChangeListener;
import android.widget.TextView;

import com.aggrx.scaffold.AggrxNumbers;
import com.podevs.android.pokeman.R;
import com.podevs.android.pokeman.pokeinfo.StatsInfo;

public class EVSlider {
    public EVListener listener;
    private final TextView total;
    private final SeekBar slider;
    private final EditText edit;
    private final View parent;

    EVSlider(View lay, final int stat) {
        total = lay.findViewById(R.id.total);
        slider = lay.findViewById(R.id.slider);
        TextView label = lay.findViewById(R.id.label);
        edit = lay.findViewById(R.id.edit);
        edit.setImeOptions(EditorInfo.IME_ACTION_DONE);
        label.setText(StatsInfo.shortcutRes(stat));
        parent = lay;

        slider.setOnSeekBarChangeListener(new OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress,
                                          boolean fromUser) {
                if (!fromUser) {
                    return;
                }

                /* Steps of 4 */
                int pr = (progress / 4) * 4;

                setNum(pr);
                if (listener != null) {
                    listener.onEVChanged(stat, pr);
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });

        edit.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_DONE) {
                if (listener != null) {
                    listener.onEVChanged(stat, AggrxNumbers.parseInt(edit.getText().toString(),0));
                }
                return true;
            }
            return false;
        });
    }

    @SuppressLint("SetTextI18n")
    void setNum(int num) {
        slider.setProgress(num);
        edit.setText(Integer.toString(num));
    }

    @SuppressLint("SetTextI18n")
    void setTotal(int num) {
        total.setText(Integer.toString(num));
    }

    void setVisibility(int visibility) {
        parent.setVisibility(visibility);
    }

    public interface EVListener {
        void onEVChanged(int stat, int ev);
    }
}
