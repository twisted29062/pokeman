/*
 * Copyright Google Inc. All Rights Reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.podevs.android.pokeman.permission;

import android.Manifest;
import android.annotation.TargetApi;
import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.provider.Settings;
import android.view.View;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;

import com.podevs.android.pokeman.R;

import java.util.ArrayList;
import java.util.List;

//import android.support.v4.app.ActivityCompat;


/**
 * Android M (API >= 23).
 */
public class EasyPermissions {

    public static final int PERMISSION_REQUEST        = 16060;
    public static final int SETTINGS_REQ_CODE         = 16061;
    public static final int PERMISSION_CAMERA_REQUEST = 16062;

    //必要权限
    public static final String[] MUST_PERMISSIONS    = new String[]{Manifest.permission.READ_PHONE_STATE, Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE};
    //第一次申请权限
    public static final String[] FIRST_PERMISSIONS   = new String[]{Manifest.permission.READ_PHONE_STATE, Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION};
    //相机权限
    public static final String[] CAMERA_PERMISSION   = new String[]{Manifest.permission.CAMERA};
    //定位权限
    public static final String[] LOCATION_PERMISSION = new String[]{Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION};


    private static final String TAG = "EasyPermissions";

    /**
     *
     */
    public static boolean hasPermissions(Context context, String[] perms) {
        // Always return true for SDK < M, let the system deal with the permissions
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) {
            return true;
        }

        for (String perm : perms) {
            boolean hasPerm = (ContextCompat.checkSelfPermission(context, perm) ==
                PackageManager.PERMISSION_GRANTED);
            if (!hasPerm) {
                return false;
            }
        }

        return true;
    }

    /**
     *
     */
    public static void requestPermissions(Object object, int requestCode, String[] perms) {

        checkCallingObjectSuitability(object);

        boolean shouldShowRationale = false;
        for (String perm : perms) {
            shouldShowRationale =
                shouldShowRationale || shouldShowRequestPermissionRationale(object, perm);
        }

        if (shouldShowRationale) {
            showPermissonsDialog(object, requestCode, perms);
        } else {
            showHelperDialog(object, requestCode, perms);
        }
    }

    //第一次调用&后续未禁止弹窗时调用
    public static void showPermissonsDialog(Object object, int requestCode, String[] perms) {
        Activity activity = getActivity(object);
        if (null == activity) {
            return;
        }
        View   permissionsTipsView = View.inflate(activity, R.layout.permissions_opentips_dialog, null);
        Dialog tipsDialog          = new Dialog(activity, R.style.no_frame_dialog);
        tipsDialog.setContentView(permissionsTipsView);
        permissionsTipsView.findViewById(R.id.open_now_tv).setOnClickListener(view -> {
            checkCallingObjectSuitability(object);

            tipsDialog.dismiss();
            executePermissionsRequest(object, perms, requestCode);
        });
        tipsDialog.show();
        tipsDialog.setCancelable(false);
    }

    @TargetApi(23)
    private static void executePermissionsRequest(Object object, String[] perms, int requestCode) {
        checkCallingObjectSuitability(object);

        if (object instanceof Activity) {
            ActivityCompat.requestPermissions((Activity) object, perms, requestCode);
        } else if (object instanceof Fragment) {
            ((Fragment) object).requestPermissions(perms, requestCode);
        } else if (object instanceof android.app.Fragment) {
            ((android.app.Fragment) object).requestPermissions(perms, requestCode);
        }
    }

    @TargetApi(11)
    private static Activity getActivity(Object object) {
        if (object instanceof Activity) {
            return ((Activity) object);
        } else if (object instanceof Fragment) {
            return ((Fragment) object).getActivity();
        } else if (object instanceof android.app.Fragment) {
            return ((android.app.Fragment) object).getActivity();
        } else {
            return null;
        }
    }

    //禁止弹窗时调用
    public static void showHelperDialog(Object object, int requestCode, String[] perms) {
        Activity activity = getActivity(object);
        if (null == activity) {
            return;
        }
        View   helpView   = View.inflate(activity, R.layout.permissions_helper_dialog, null);
        Dialog helpDialog = new Dialog(activity, R.style.no_frame_dialog);
        helpDialog.setContentView(helpView);
        helpView.findViewById(R.id.set_tv).setOnClickListener(view -> {
            helpDialog.dismiss();
            Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
            Uri    uri    = Uri.fromParts("package", activity.getPackageName(), null);
            intent.setData(uri);
            startAppSettingsScreen(object, intent);
        });
        helpDialog.show();
        helpDialog.setCancelable(false);
    }

    @TargetApi(11)
    private static void startAppSettingsScreen(Object object,
                                               Intent intent) {
        if (object instanceof Activity) {
            ((Activity) object).startActivityForResult(intent, SETTINGS_REQ_CODE);
        } else if (object instanceof Fragment) {
            ((Fragment) object).startActivityForResult(intent, SETTINGS_REQ_CODE);
        } else if (object instanceof android.app.Fragment) {
            ((android.app.Fragment) object).startActivityForResult(intent, SETTINGS_REQ_CODE);
        }
    }

    @TargetApi(23)
    private static boolean shouldShowRequestPermissionRationale(Object object, String perm) {
        if (object instanceof Activity) {
            return ActivityCompat.shouldShowRequestPermissionRationale((Activity) object, perm);
        } else if (object instanceof Fragment) {
            return ((Fragment) object).shouldShowRequestPermissionRationale(perm);
        } else if (object instanceof android.app.Fragment) {
            return ((android.app.Fragment) object).shouldShowRequestPermissionRationale(perm);
        } else {
            return false;
        }
    }

    private static void checkCallingObjectSuitability(Object object) {
        // Make sure Object is an Activity or Fragment
        boolean isActivity        = object instanceof Activity;
        boolean isSupportFragment = object instanceof Fragment;
        boolean isAppFragment     = object instanceof android.app.Fragment;
        boolean isMinSdkM         = Build.VERSION.SDK_INT >= Build.VERSION_CODES.M;

        if (!(isSupportFragment || isActivity || (isAppFragment && isMinSdkM))) {
            if (isAppFragment) {
                throw new IllegalArgumentException(
                    "Target SDK needs to be greater than 23 if caller is android.app.Fragment");
            } else {
                throw new IllegalArgumentException("Caller must be an Activity or a Fragment.");
            }
        }
    }

    /**
     * 直接获取权限，如相机
     */
    public static void permissionsCamera(Object object, int requestCode, String[] perms) {

        Activity activity = getActivity(object);
        if (null == activity) {
            return;
        }

        checkCallingObjectSuitability(object);

        executePermissionsRequest(object, perms, requestCode);
    }

    /**
     *
     */
    public static void onRequestPermissionsResult(int requestCode, String[] permissions,
                                                  int[] grantResults, Object object) {

        checkCallingObjectSuitability(object);

        // Make a collection of granted and denied permissions from the request.
        ArrayList<String> granted = new ArrayList<>();
        ArrayList<String> denied  = new ArrayList<>();
        for (int i = 0; i < permissions.length; i++) {
            String perm = permissions[i];
            if (grantResults[i] == PackageManager.PERMISSION_GRANTED) {
                granted.add(perm);
            } else {
                denied.add(perm);
            }
        }

        // Report granted permissions, if any.
        if (!granted.isEmpty()) {
            // Notify callbacks
            if (object instanceof PermissionCallbacks) {
                ((PermissionCallbacks) object).onPermissionsGranted(requestCode, granted);
            }
        }

        // Report denied permissions, if any.
        if (!denied.isEmpty()) {
            if (object instanceof PermissionCallbacks) {
                ((PermissionCallbacks) object).onPermissionsDenied(requestCode, denied);
            }
        }

        // If 100% successful, call annotated methods
        if (!granted.isEmpty() && denied.isEmpty()) {
            if (object instanceof PermissionCallbacks) {
                ((PermissionCallbacks) object).onPermissionsAllGranted();
            }
        }
    }


    public interface PermissionCallbacks extends
        ActivityCompat.OnRequestPermissionsResultCallback {

        void onPermissionsGranted(int requestCode, List<String> perms);

        void onPermissionsDenied(int requestCode, List<String> perms);

        void onPermissionsAllGranted();

    }

}
