package com.podevs.android.pokeman.pokeinfo;

public class GenderInfo {
    private static String[] genders;

    static {
        loadGenderNames();
    }

    public static String name(int num) {
        if (genders == null) {
            loadGenderNames();
        }
        String gender = genders[num];
        return gender == null ? "" : gender;
    }

    private static void loadGenderNames() {
        genders = new String[Gender.values().length];
        String path = PokemonStorage.getGendersPath();
        InfoFiller.fill(path, new InfoFiller.Filler() {
            int index = 0;

            @Override
            public void fill(int i, String s, String o) {
                genders[index] = s;
                index++;
            }
        });
    }

    public static int indexOf(String gender) {
        if (genders == null) {
            loadGenderNames();
        }
        for (int i = 0; i < genders.length; i++) {
            if (gender != null && gender.equals(genders[i])) {
                return i;
            }
        }
        return -1;
    }

    public enum Gender {
        /*未知*/
        Neutral,
        /*雄性*/
        Male,
        /*雌性*/
        Female
    }
}
