package com.podevs.android.pokeman.teambuilder;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.viewpager.widget.ViewPager;

import com.podevs.android.pokeman.R;
import com.podevs.android.pokeman.battle.ListedPokemon;
import com.podevs.android.pokeman.poke.TeamPoke;
import com.podevs.android.pokeman.poke.UniqueID;
import com.podevs.android.pokeman.teambuilder.MoveChooserFragment.MoveChooserListener;
import com.podevs.android.pokeman.teambuilder.PokemonChooserFragment.PokemonChooserListener;
import com.podevs.android.pokeman.teambuilder.PokemonDetailsFragment.PokemonDetailsListener;

//import android.support.v4.view.ViewPager;

public class EditPokemonFragment extends Fragment implements PokemonChooserListener, PokemonDetailsListener, MoveChooserListener {
    private ListedPokemon pokeList;
    private ViewPager     pager = null;

    private PokemonChooserFragment pokemonChooser = null;
    private PokemonDetailsFragment pokemonDetails = null;
    private MoveChooserFragment    moveChooser    = null;

    private boolean pokeChanged = false;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        if (savedInstanceState != null) {
            pokeChanged = true;
        }
        View v = inflater.inflate(R.layout.edit_pokemon, container, false);

        pokeList = new ListedPokemon(v.findViewById(R.id.pokeViewLayout));

        pager = v.findViewById(R.id.edit_poke_viewpager);
        pager.setAdapter(new EditPokeAdapter(getFragmentManager()));

        pokeList.setOnImageClickListener(arg0 -> pager.setCurrentItem(0));

        pokeList.setOnDetailsClickListener(v12 -> pager.setCurrentItem(1));

        pokeList.setOnMoveClickListener(v1 -> pager.setCurrentItem(2));

        updatePoke();

        return v;
    }

    public void updatePoke() {
        updateHeader();
        if (pokemonChooser != null) {
            pokemonChooser.setDetails(poke().uID(), poke().nick);
        }
        updateDetails();
        if (moveChooser != null) {
            moveChooser.updatePoke();
        }
    }

    private void updateDetails() {
        if (pokemonDetails != null) {
            pokemonDetails.updatePoke();
        }
    }

    private void updateHeader() {
        pokeList.update(poke());
    }

    private TeamPoke poke() {
        return ((EditPokemonActivity) getActivity()).getPoke();
    }

    @Override
    public void onPause() {
        super.onPause();
    }

    @Override public void onPokemonChosen(UniqueID id, String nickname) {
        poke().setNum(id);
        if (nickname.length() > 0) {
            poke().nick = nickname;
        }

        updatePoke();
        pokeChanged = true;

        pager.setCurrentItem(1);
    }

    @Override public void onPokemonEdited(boolean updateAll) {
        if (!updateAll) {
            updateHeader();
        } else {
            updatePoke();
        }
        pokeChanged = true;
    }

    @Override public void onMovesetChanged(boolean stats) {
        updateHeader();

        if (stats) {
            updateDetails();
        }

        pokeChanged = true;
    }

    public boolean hasEdits() {
        return pokeChanged;
    }

    class EditPokeAdapter extends FragmentPagerAdapter {

        public EditPokeAdapter(FragmentManager fm) {
            super(fm);
        }

        @NonNull
        @Override
        public Fragment getItem(int arg0) {
            if (arg0 == 0) {
                pokemonChooser = new PokemonChooserFragment();
                pokemonChooser.setDetails(poke().uID(), poke().nick);
                pokemonChooser.setOnPokemonChosenListener(EditPokemonFragment.this);
                return pokemonChooser;
            } else if (arg0 == 1) {
                pokemonDetails = new PokemonDetailsFragment();
                pokemonDetails.listener = EditPokemonFragment.this;
                return pokemonDetails;
            } else if (arg0 == 2) {
                moveChooser = new MoveChooserFragment();
                moveChooser.listener = EditPokemonFragment.this;
                return moveChooser;
            } else {
                return null;
            }
        }

        @Override
        public int getCount() {
            return 3;
        }

    }
}
