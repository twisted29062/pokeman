package com.podevs.android.pokeman.chat;

import android.content.Context;
import android.database.DataSetObserver;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.ListAdapter;
import android.widget.TextView;

import com.podevs.android.pokeman.R;
import com.podevs.android.pokeman.battle.ChallengeEnums;

import java.util.HashSet;

public class ClausesListAdapter implements ListAdapter {
    public final boolean[]                checked   = new boolean[getCount()];
    private final HashSet<DataSetObserver> observers = new HashSet<>();

    public void setChecked(int i, boolean checked) {
        this.checked[i] = checked;
        //notifyDataSetChanged();
    }

    @Override public void registerDataSetObserver(DataSetObserver arg0) {
        observers.add(arg0);
    }

    @Override public void unregisterDataSetObserver(DataSetObserver arg0) {
        observers.remove(arg0);
    }

    @Override public int getCount() {
        return ChallengeEnums.Clauses.values().length;
    }

    @Override public Object getItem(int arg0) {
        return ChallengeEnums.Clauses.values()[arg0];
    }

    @Override public long getItemId(int arg0) {
        return arg0;
    }

    @Override public boolean hasStableIds() {
        return true;
    }

    @Override public View getView(int position, View convertView, ViewGroup parent) {
        View view = convertView;
        if (view == null) {
            LayoutInflater inflater = (LayoutInflater) parent.getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            view = inflater.inflate(R.layout.clause_item, null);
        }

        TextView name = view.findViewById(R.id.clausename);
        name.setText(getItem(position).toString());

        CheckBox check = view.findViewById(R.id.clausecheck);
        check.setChecked(checked[position]);

        return view;
    }

    @Override public int getItemViewType(int arg0) {
        return 0;
    }

    @Override public int getViewTypeCount() {
        return 1;
    }

    @Override public boolean isEmpty() {
        return getCount() == 0;
    }

    @Override public boolean areAllItemsEnabled() {
        return true;
    }

    @Override public boolean isEnabled(int position) {
        return true;
    }

    public void notifyDataSetChanged() {
        for (DataSetObserver obs : observers) {
            obs.onChanged();
        }
    }
}
