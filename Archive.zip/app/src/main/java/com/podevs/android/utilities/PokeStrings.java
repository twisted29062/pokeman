package com.podevs.android.utilities;

import android.content.Context;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.text.SimpleDateFormat;
import java.util.Locale;

/**
 * Extra string methods
 */

public class PokeStrings {
    private final static SimpleDateFormat format = new SimpleDateFormat("HH:mm:ss", Locale.UK);

    public static String escapeHtml(String seq) {
        return seq.replace("&", "&amp;").replace("<", "&lt;");
    }

    public static String join(String[] strings, String sep) {
        String ret = "";

        for (int i = 0; i < strings.length; i++) {
            ret = ret.concat(strings[i]);

            if (i + 1 < strings.length) {
                ret = ret.concat(sep);
            }
        }

        return ret;
    }

    public static String timeStamp() {
        // DateUtils.formatDateTime()
        return format.format(System.currentTimeMillis());
    }

    public static String def(String s, String def) {
        return s == null ? def : s;
    }

    public static String getFileContent(Context ctx, String path) {
        FileInputStream in;
        try {
            in = ctx.openFileInput(path);
        } catch (FileNotFoundException e) {
            return "";
        }

        BufferedReader br;
        try {
            br = new BufferedReader(new InputStreamReader(in, "UTF-8"));
        } catch (UnsupportedEncodingException e) {
            return "";
        }

        StringBuilder sb = new StringBuilder();
        String line;
        try {
            while ((line = br.readLine()) != null) {
                sb.append(line);
                sb.append('\n');
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return sb.toString();
    }

    public static boolean isNumeric(String str) {
        return str.matches("\\d*");
    }
}
