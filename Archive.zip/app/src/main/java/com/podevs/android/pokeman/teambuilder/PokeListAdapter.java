package com.podevs.android.pokeman.teambuilder;

import android.database.DataSetObserver;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ListAdapter;
import android.widget.TextView;

import com.aggrx.scaffold.AggrxMaps;
import com.jx.scaffold.JxLogger;
import com.podevs.android.pokeman.R;
import com.podevs.android.pokeman.poke.Gen;
import com.podevs.android.pokeman.poke.UniqueID;
import com.podevs.android.pokeman.pokeinfo.PokemonInfo;
import com.podevs.android.pokeman.pokeinfo.TypeInfo;
import com.podevs.android.pokeman.pokeinfo.TypeInfo.Type;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

public class PokeListAdapter implements ListAdapter {
    private Gen gen;
    private final HashSet<DataSetObserver> observers = new HashSet<>();
    List<UniqueID> ids = new ArrayList<>();

    PokeListAdapter(Gen gen) {
        super();
        this.gen = gen;
        ids = PokemonInfo.ids(gen);
    }

    public void setGen(Gen g) {
        if (g.equals(gen)) {
            return;
        }
        gen = g;

        for (DataSetObserver obs : observers) {
            obs.onInvalidated();
        }
        ids = PokemonInfo.ids(gen);
    }

    @Override
    public void registerDataSetObserver(DataSetObserver arg0) {
        observers.add(arg0);
    }

    @Override
    public void unregisterDataSetObserver(DataSetObserver arg0) {
        observers.remove(arg0);
    }

    @Override
    public int getCount() {
        return ids.size();// PokemonInfo.numberOfPokemons(gen);
    }

    @Override
    public Object getItem(int pos) {
        return pos;
    }

    @Override
    public long getItemId(int pos) {
        return pos;
    }

    @Override
    public boolean hasStableIds() {
        return true;
    }

    @Override
    public View getView(int pos, View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = ViewGroup.inflate(parent.getContext(), R.layout.pokeinlist_item, null);
        }

        UniqueID uniqueID = (AggrxMaps.get(ids, pos, new UniqueID("")));

        ImageView image = convertView.findViewById(R.id.image);
        image.setImageDrawable(PokemonInfo.iconDrawable(uniqueID));

        TextView nameView = (TextView) convertView.findViewById(R.id.poke_name);
        String name = PokemonInfo.name(uniqueID);
        if (TextUtils.isEmpty(name)) {
            JxLogger.w("can not get name %s", uniqueID.id());
        }
        nameView.setText(name);

        ImageView type1View = (ImageView) convertView.findViewById(R.id.type1);
        int type1 = PokemonInfo.type1(uniqueID, gen.num);
        if (type1 == -1) {
            JxLogger.w("get type 1 image failed. %s %d", uniqueID.hashCodeString(), gen.num);
        }
        type1View.setImageResource(TypeInfo.typeRes(type1));

        int type2 = PokemonInfo.type2(uniqueID, gen.num);
        if (type2 == -1) {
            JxLogger.w("get type 2 image failed. %s %d", uniqueID.hashCodeString(), gen.num);
        }
        ImageView type2View = convertView.findViewById(R.id.type2);

        type2View.setImageResource(TypeInfo.typeRes(type2));
        type2View.setVisibility(type2 == Type.Curse.ordinal() ? View.INVISIBLE : View.VISIBLE);

        return convertView;
    }

    @Override
    public int getItemViewType(int arg0) {
        return 0;
    }

    @Override
    public int getViewTypeCount() {
        return 1;
    }

    @Override
    public boolean isEmpty() {
        return false;
    }

    @Override
    public boolean areAllItemsEnabled() {
        return true;
    }

    @Override
    public boolean isEnabled(int arg0) {
        return true;
    }

}
