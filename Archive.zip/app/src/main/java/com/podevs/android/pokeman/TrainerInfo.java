package com.podevs.android.pokeman;

public class TrainerInfo {
    public static final String ROOT_PATH = "ui/Trainer/";
    public static final int COUNT = 852;

    public static String trainerRes(int id) {
        return ROOT_PATH + id + ".png";
    }
}
