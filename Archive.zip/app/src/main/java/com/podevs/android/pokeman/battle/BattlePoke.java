package com.podevs.android.pokeman.battle;

import android.text.Html;
import android.text.SpannableStringBuilder;

import com.aggrx.scaffold.AggrxMaps;
import com.podevs.android.pokeman.poke.Gen;
import com.podevs.android.pokeman.poke.Move;
import com.podevs.android.pokeman.poke.Poke;
import com.podevs.android.pokeman.poke.ShallowBattlePoke;
import com.podevs.android.pokeman.poke.UniqueID;
import com.podevs.android.pokeman.pokeinfo.HiddenPowerInfo;
import com.podevs.android.pokeman.pokeinfo.PokemonInfo;
import com.podevs.android.pokeman.pokeinfo.TypeInfo;
import com.podevs.android.pokeman.pokeinfo.TypeInfo.Type;
import com.podevs.android.utilities.Bais;
import com.podevs.android.utilities.Baos;

// This class represents your poke during a battle.
public class BattlePoke extends ShallowBattlePoke implements Poke {
    public short currentHP;
    public short totalHP;
    public short gender;
    public String abilityString;
    public byte teamNum;
    public final short[] stats = new short[5];
    public final BattleMove[] moves = new BattleMove[4];
    short item;
    // public String itemString;
    short ability;
    // byte statusCount = 0;
    // byte originalStatusCount = 0;
    byte nature;
    byte hiddenPower = (byte) TypeInfo.Type.Dark.ordinal();
    byte happiness;
    final Gen gen;
    final int[] DVs = new int[6];
    final int[] EVs = new int[6];

    public BattlePoke(Bais msg, Gen gen) {
        uID = new UniqueID(msg);
        nick = msg.readString();
        totalHP = msg.readShort();
        currentHP = msg.readShort();
        gender = msg.readByte();
        shiny = msg.readBool();
        level = msg.readByte();
        item = msg.readShort();
        ability = msg.readShort();
        nature = msg.readByte();
        hiddenPower = msg.readByte();
        happiness = msg.readByte();
        pokeName = PokemonInfo.name(uID);

        int type1 = PokemonInfo.type1(uID, gen.num);
        types[0] = AggrxMaps.get(Type.values(), type1, Type.Normal);// Type.values()[type1];

        int type2 = PokemonInfo.type2(uID, gen.num);
        types[1] = AggrxMaps.get(Type.values(), type2, Type.Normal);//Type.values()[type2];
        this.gen = gen;

        for (int i = 0; i < 5; i++) {
            stats[i] = msg.readShort();
        }
        for (int i = 0; i < 4; i++) {
            moves[i] = new BattleMove(msg);
        }
        /* EVs and DVs are QLists on the server end,
         * so we need to discard the int representing
         * the number of items in the list. */
        //msg.readInt();
        for (int i = 0; i < 6; i++) {
            EVs[i] = msg.readInt();
            //msg.readInt();
        }
        for (int i = 0; i < 6; i++) {
            DVs[i] = msg.readInt();
        }
    }

    @Override
    public void serializeBytes(Baos b) {
        b.putBaos(uID);
        b.putString(nick);
        b.putShort(totalHP);
        b.putShort(currentHP);
        b.write(gender);
        b.putBool(shiny);
        b.write(level);
        b.putShort(item);
        b.putShort(ability);
        b.write(nature);
        b.write(hiddenPower);
        b.write(happiness);
        for (int i = 0; i < 5; i++) {
            b.putShort(stats[i]);
        }
        for (int i = 0; i < 4; i++) {
            b.putBaos(moves[i]);
        }
        for (int i = 0; i < 6; i++) {
            b.write(EVs[i]);
        }
        for (int i = 0; i < 6; i++) {
            b.write(DVs[i]);
        }
    }

    @Override
    public SpannableStringBuilder movesString() {
        SpannableStringBuilder s = new SpannableStringBuilder();
        for (int i = 0; i < 4; i++) {
            s.append(i == 0 ? "" : "\n");
            if (this.moves[i] == null) {
                s.append("????" + "    " + "??");
            } else {
                s.append(Html.fromHtml("<font color=\"" + moves[i].getHexColor() + "\">" + moves[i].toString() + "    " + moves[i].totalPP + "</font>"));
            }
        }
        return s;
    }

    public String printStats() {
        StringBuilder s = new StringBuilder();
        s.append(currentHP());
        for (int i = 0; i < 5; i++) {
            s.append("\n").append(stats[i] == -1 ? "???" : stats[i]);
        }
        return s.toString();
    }

    @Override
    public int ability() {
        return ability;
    }

    @Override
    public int item() {
        return item;
    }

    @Override
    public int totalHP() {
        return totalHP;
    }

    @Override
    public int currentHP() {
        return currentHP;
    }

    @Override
    public CharSequence nick() {
        return nick;
    }

    @Override
    public UniqueID uID() {
        return uID;
    }

    @Override
    public Gen gen() {
        return this.gen;
    }

    @Override
    public Move move(int j) {
        return moves[j];
    }

    @Override
    public int hiddenPowerType() {
        if (this.gen().num > 6) {
            return this.hiddenPower;
        }
        return HiddenPowerInfo.Type(this);
    }

    @Override
    public int dv(int i) {
        return DVs[i];
    }

    @Override
    public int ev(int i) {
        return EVs[i];
    }

    @Override
    public int level() {
        return level;
    }

    @Override
    public int nature() {
        return nature;
    }

    @Override
    public int gender() {
        return gender;
    }

}
