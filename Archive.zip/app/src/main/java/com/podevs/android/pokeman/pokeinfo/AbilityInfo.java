package com.podevs.android.pokeman.pokeinfo;

import android.util.SparseArray;

import java.util.ArrayList;
import java.util.Arrays;

public class AbilityInfo {
    private static ArrayList<String> abilityNames = null;
    private static SparseArray<String> abilityMessages = null;
    private static Short[][] allAbilities = null;

    public static String name(int item) {
        if (abilityNames == null) {
            loadAbilityNames();
        }

        String name = abilityNames.get(item);
        return name == null ? "" : name;
    }

    public static int indexOf(String s) {
        if (abilityNames == null) {
            loadAbilityNames();
        }

        return abilityNames.indexOf(s);
    }

    public static String message(int num, int part) {
        if (abilityMessages == null) {
            loadAbilityMessages();
        }

        String[] parts = (abilityMessages.get(num, "")).split("\\|");
        try {
            return parts[part];
        } catch (ArrayIndexOutOfBoundsException ex) {
            return "";
        }
    }

    private static void loadAbilityMessages() {
        abilityMessages = new SparseArray<>();
        String path = PokemonStorage.getAbilityMessagesPath();
        InfoFiller.fill(path, (i, b, o) -> abilityMessages.put(i, b));
    }

    private static void loadAbilityNames() {
        abilityNames = new ArrayList<>();
        String path = PokemonStorage.getAbilityNamesPath();
        InfoFiller.fill(path, (i, b, o) -> abilityNames.add(b));
        loadAllArray();
    }

    private static void loadAllArray() {
        allAbilities = new Short[5][];
        allAbilities[4] = new Short[abilityNames.size() - 1];
        for (int i = 0; i <= allAbilities[4].length - 1; i++) {
            allAbilities[4][i] = (short) (i + 1);
        }

        allAbilities[3] = Arrays.copyOf(allAbilities[4], 191);
        allAbilities[2] = Arrays.copyOf(allAbilities[3], 164);
        allAbilities[1] = Arrays.copyOf(allAbilities[2], 123);
        allAbilities[0] = Arrays.copyOf(allAbilities[1], 76);

        for (int i = 0; i < 5; i++) {
            java.util.Arrays.sort(allAbilities[i], (lhs, rhs) -> name(lhs).compareToIgnoreCase(name(rhs)));
        }
    }

    public static Short[] getAllAbilities(int gen) {
        if (gen - 3 >= allAbilities.length) {
            return null;
        }
        return allAbilities[gen - 3];
    }
}
