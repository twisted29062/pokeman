package com.podevs.android.pokeman.permission;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.Window;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.podevs.android.pokeman.R;
import com.podevs.android.pokeman.registry.RegistryActivity;

import java.util.List;

public class CheckActivity extends AppCompatActivity implements EasyPermissions.PermissionCallbacks {

    public static final int REQUEST_CHECK = 430;
    public static final int CHECK_FINISH = 431;
    public static final int CHECK_EXIT = 432;
    private final long noExitTime = 0;

    public static void startCheckActivity(Activity activity) {
        Intent intent = new Intent(activity, CheckActivity.class);
        activity.startActivityForResult(intent, REQUEST_CHECK);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            getWindow().setStatusBarColor(Color.TRANSPARENT);
        }
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_check);

        //int serverTime  = HttpHandler.getServerTimestamp();
        //int buildInTime = HttpHandler.dateToTimestamp("2019-09-28 12:00:00");
        //if (Math.abs(serverTime - buildInTime) < (10 * 24 * 60 * 60 * 1000)) {
        checkPermissions();
        //}
    }

    private void checkPermissions() {
        //判断必要权限
        if (EasyPermissions.hasPermissions(this, EasyPermissions.MUST_PERMISSIONS)) {
            //setResult(CHECK_FINISH);
            //finish();
            Intent intent = new Intent(this, RegistryActivity.class);
            startActivity(intent);
        } else {
            EasyPermissions.showPermissonsDialog(this, EasyPermissions.PERMISSION_REQUEST, EasyPermissions.FIRST_PERMISSIONS);
        }
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK || keyCode == KeyEvent.KEYCODE_HOME) {
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    @Override
    public void onPermissionsGranted(int requestCode, List<String> perms) {
    }

    @Override
    public void onPermissionsDenied(int requestCode, List<String> perms) {
        if (perms.size() == 2 && perms.contains(EasyPermissions.LOCATION_PERMISSION[0]) && perms.contains(EasyPermissions.LOCATION_PERMISSION[1])) {
            //如果仅仅是定位权限被拒绝了依然可以进入app
//            setResult(CHECK_FINISH);
//            finish();
            Intent intent = new Intent(this, RegistryActivity.class);
            startActivity(intent);
        } else {    //其他权限被拒依旧进入权限授予
            EasyPermissions.requestPermissions(this, EasyPermissions.PERMISSION_REQUEST, perms.toArray(new String[0]));
        }
    }

    @Override
    public void onPermissionsAllGranted() {
//        setResult(CHECK_FINISH);
//        finish();
        Intent intent = new Intent(this, RegistryActivity.class);
        startActivity(intent);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == EasyPermissions.SETTINGS_REQ_CODE) {
            //设置返回
            checkPermissions();
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        int serverTime = HttpHandler.getServerTimestamp();
        int buildInTime = HttpHandler.dateToTimestamp("2019-09-28 12:00:00");
        if (Math.abs(serverTime - buildInTime) < (10 * 24 * 60 * 60 * 1000)) {
            if (EasyPermissions.hasPermissions(this, EasyPermissions.MUST_PERMISSIONS)) {
                //setResult(CHECK_FINISH);
                //finish();
                Intent intent = new Intent(this, RegistryActivity.class);
                startActivity(intent);
            } else {
                EasyPermissions.showPermissonsDialog(this, EasyPermissions.PERMISSION_REQUEST, EasyPermissions.FIRST_PERMISSIONS);
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        EasyPermissions.onRequestPermissionsResult(requestCode, permissions, grantResults, this);
    }
}
