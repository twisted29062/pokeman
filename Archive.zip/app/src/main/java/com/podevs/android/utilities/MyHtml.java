package com.podevs.android.utilities;

import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.text.Html;
import android.text.Spannable;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.TextPaint;
import android.text.TextUtils;
import android.text.style.BackgroundColorSpan;
import android.text.style.ClickableSpan;
import android.text.style.ForegroundColorSpan;
import android.text.style.ImageSpan;
import android.text.style.ParagraphStyle;
import android.text.style.QuoteSpan;
import android.text.style.RelativeSizeSpan;
import android.text.style.StrikethroughSpan;
import android.text.style.StyleSpan;
import android.text.style.SubscriptSpan;
import android.text.style.SuperscriptSpan;
import android.text.style.TextAppearanceSpan;
import android.text.style.TypefaceSpan;
import android.text.style.URLSpan;
import android.text.style.UnderlineSpan;
import android.view.View;

import androidx.annotation.NonNull;

import com.aggrx.scaffold.AggrxNumbers;
import com.podevs.android.pokeman.Command;
import com.podevs.android.pokeman.NetworkService;
import com.podevs.android.pokeman.R;
import com.podevs.android.pokeman.chat.Channel;

import org.ccil.cowan.tagsoup.HTMLSchema;
import org.xml.sax.Attributes;
import org.xml.sax.ContentHandler;
import org.xml.sax.InputSource;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;

import java.io.IOException;
import java.io.StringReader;

// Custom implementation of android.text.html

public class MyHtml {

    private MyHtml() {
    }

    public static Spanned fromHtml(String source) {
        return fromHtml(source, null, null, null, null);
    }

    public static Spanned fromHtml(String source, ImageGetter imageGetter, Html.TagHandler tagHandler, Channel chan, NetworkService netServ) {
        org.ccil.cowan.tagsoup.Parser parser = new org.ccil.cowan.tagsoup.Parser();
        try {
            parser.setProperty(org.ccil.cowan.tagsoup.Parser.schemaProperty, HtmlParser.schema);
        } catch (org.xml.sax.SAXNotRecognizedException | org.xml.sax.SAXNotSupportedException e) {
            throw new RuntimeException(e);
        }

        HtmlToSpannedConverter converter = new HtmlToSpannedConverter(source, imageGetter, tagHandler, parser, chan, netServ);
        return converter.convert();
    }

    public static String escapeHtml(CharSequence text) {
        StringBuilder out = new StringBuilder();
        withinStyle(out, text, 0, text.length());
        return out.toString();
    }

    private static void withinStyle(StringBuilder out, CharSequence text,
                                    int start, int end) {
        for (int i = start; i < end; i++) {
            char c = text.charAt(i);

            if (c == '<') {
                out.append("&lt;");
            } else if (c == '>') {
                out.append("&gt;");
            } else if (c == '&') {
                out.append("&amp;");
            } else if (c >= 0xD800 && c <= 0xDFFF) {
                if (c < 0xDC00 && i + 1 < end) {
                    char d = text.charAt(i + 1);
                    if (d >= 0xDC00 && d <= 0xDFFF) {
                        i++;
                        int codepoint = 0x010000 | (int) c - 0xD800 << 10 | (int) d - 0xDC00;
                        out.append("&#").append(codepoint).append(";");
                    }
                }
            } else if (c > 0x7E || c < ' ') {
                out.append("&#").append((int) c).append(";");
            } else if (c == ' ') {
                while (i + 1 < end && text.charAt(i + 1) == ' ') {
                    out.append("&nbsp;");
                    i++;
                }

                out.append(' ');
            } else {
                out.append(c);
            }
        }
    }

    public interface ImageGetter {
        Drawable getDrawable(String source, Attributes attributes);
    }

    private static class HtmlParser {
        private static final HTMLSchema schema = new HTMLSchema();
    }
}

class HtmlToSpannedConverter implements ContentHandler {

    private static final float[] HEADER_SIZES = {
        1.5f, 1.4f, 1.3f, 1.2f, 1.1f, 1f,
    };

    private final String                 mSource;
    private final XMLReader              mReader;
    private final SpannableStringBuilder mSpannableStringBuilder;
    private final MyHtml.ImageGetter     mImageGetter;
    private final Html.TagHandler        mTagHandler;
    private final NetworkService         mNetServ;
    private final Channel                mChan;

    public HtmlToSpannedConverter(String source, MyHtml.ImageGetter imageGetter, Html.TagHandler tagHandler, org.ccil.cowan.tagsoup.Parser parser, Channel chan, NetworkService netServ) {
        mSource = source;
        mSpannableStringBuilder = new SpannableStringBuilder();
        mImageGetter = imageGetter;
        mTagHandler = tagHandler;
        mReader = parser;
        mNetServ = netServ;
        mChan = chan;
    }

    public Spanned convert() {

        mReader.setContentHandler(this);
        try {
            mReader.parse(new InputSource(new StringReader(mSource)));
        } catch (IOException | SAXException e) {
            throw new RuntimeException(e);
        }


        Object[] obj = mSpannableStringBuilder.getSpans(0, mSpannableStringBuilder.length(), ParagraphStyle.class);
        for (Object o : obj) {
            int start = mSpannableStringBuilder.getSpanStart(o);
            int end   = mSpannableStringBuilder.getSpanEnd(o);


            if (end - 2 >= 0) {
                if (mSpannableStringBuilder.charAt(end - 1) == '\n' &&
                    mSpannableStringBuilder.charAt(end - 2) == '\n') {
                    end--;
                }
            }

            if (end == start) {
                mSpannableStringBuilder.removeSpan(o);
            } else {
                mSpannableStringBuilder.setSpan(o, start, end, Spannable.SPAN_PARAGRAPH);
            }
        }

        return mSpannableStringBuilder;
    }

    @Override public void setDocumentLocator(Locator locator) {
    }

    @Override public void startDocument() {
    }

    @Override public void endDocument() {
    }

    @Override public void startPrefixMapping(String prefix, String uri) {
    }

    @Override public void endPrefixMapping(String prefix) {
    }

    @Override public void startElement(String uri, String localName, String qName, Attributes attributes) {
        handleStartTag(localName, attributes);
    }

    private void handleStartTag(String tag, Attributes attributes) {
        if ("br".equalsIgnoreCase(tag)) {

        } else if ("p".equalsIgnoreCase(tag)) {
            handleP(mSpannableStringBuilder);
        } else if ("div".equalsIgnoreCase(tag)) {
            handleP(mSpannableStringBuilder);
        } else if ("strong".equalsIgnoreCase(tag)) {
            start(mSpannableStringBuilder, new Bold());
        } else if ("b".equalsIgnoreCase(tag)) {
            start(mSpannableStringBuilder, new Bold());
        } else if ("em".equalsIgnoreCase(tag)) {
            start(mSpannableStringBuilder, new Italic());
        } else if ("cite".equalsIgnoreCase(tag)) {
            start(mSpannableStringBuilder, new Italic());
        } else if ("dfn".equalsIgnoreCase(tag)) {
            start(mSpannableStringBuilder, new Italic());
        } else if ("i".equalsIgnoreCase(tag)) {
            start(mSpannableStringBuilder, new Italic());
        } else if ("big".equalsIgnoreCase(tag)) {
            start(mSpannableStringBuilder, new Big());
        } else if ("small".equalsIgnoreCase(tag)) {
            start(mSpannableStringBuilder, new Small());
        } else if ("font".equalsIgnoreCase(tag)) {
            startFont(mSpannableStringBuilder, attributes);
        } else if ("blockquote".equalsIgnoreCase(tag)) {
            handleP(mSpannableStringBuilder);
            start(mSpannableStringBuilder, new Blockquote());
        } else if ("tt".equalsIgnoreCase(tag)) {
            start(mSpannableStringBuilder, new Monospace());
        } else if ("a".equalsIgnoreCase(tag)) {
            handleA(mSpannableStringBuilder, attributes, mChan, mNetServ);
        } else if ("u".equalsIgnoreCase(tag)) {
            start(mSpannableStringBuilder, new Underline());
        } else if ("sup".equalsIgnoreCase(tag)) {
            start(mSpannableStringBuilder, new Super());
        } else if ("sub".equalsIgnoreCase(tag)) {
            start(mSpannableStringBuilder, new Sub());
        } else if (tag.length() == 2 &&
            Character.toLowerCase(tag.charAt(0)) == 'h' &&
            tag.charAt(1) >= '1' && tag.charAt(1) <= '6') {
            handleP(mSpannableStringBuilder);
            start(mSpannableStringBuilder, new Header(tag.charAt(1) - '1'));
        } else if ("img".equalsIgnoreCase(tag)) {
            startImg(mSpannableStringBuilder, attributes, mImageGetter);
        } else if ("ping".equalsIgnoreCase(tag)) {
            startPing(mChan, mNetServ);
        } else if ("background".equalsIgnoreCase(tag)) {
            startBackground(mSpannableStringBuilder, attributes);
        } else if ("timestamp".equalsIgnoreCase(tag)) {
            if (mNetServ != null && mNetServ.getSettings().timeStamp) {
                String timestamp = "(" + PokeStrings.timeStamp() + ") ";
                mSpannableStringBuilder.append(timestamp);
            }
        } else if ("strike".equalsIgnoreCase(tag)) {
            start(mSpannableStringBuilder, new Strikethrough());
        } else if (mTagHandler != null) {
            mTagHandler.handleTag(true, tag, mSpannableStringBuilder, mReader);
        }
    }

    private static void handleP(SpannableStringBuilder text) {
        int len = text.length();

        if (len >= 1 && text.charAt(len - 1) == '\n') {
            if (len >= 2 && text.charAt(len - 2) == '\n') {
                return;
            }

            text.append("\n");
            return;
        }

        if (len != 0) {
            text.append("\n\n");
        }
    }

    private static void start(SpannableStringBuilder text, Object mark) {
        int len = text.length();
        text.setSpan(mark, len, len, Spannable.SPAN_MARK_MARK);
    }

    private static void startImg(SpannableStringBuilder text, Attributes attributes, MyHtml.ImageGetter img) {
        String   src = attributes.getValue("", "src");
        Drawable d   = null;

        if (img != null) {
            d = img.getDrawable(src, attributes);
        }

        if (d == null) {
            d = Resources.getSystem().getDrawable(R.drawable.pi_0);
            d.setBounds(0, 0, d.getIntrinsicWidth(), d.getIntrinsicHeight());
        }

        int len = text.length();
        text.append("\uFFFC");

        text.setSpan(new ImageSpan(d, src), len, text.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
    }

    private static void startFont(SpannableStringBuilder text, Attributes attributes) {
        String color = attributes.getValue("", "color");
        String face  = attributes.getValue("", "face");

        int len = text.length();
        text.setSpan(new Font(color, face), len, len, Spannable.SPAN_MARK_MARK);
    }

    private static void handleA(SpannableStringBuilder text, Attributes attributes, Channel channel, NetworkService netServ) {
        String href  = attributes.getValue("", "href");
        String color = attributes.getValue("", "style");
        int    c     = -1;
        if (color != null && !"".equals(color)) {
            color = color.substring(6);
            try {
                c = MyColor.parseColor(color);
            } catch (IllegalArgumentException e) {
                c = MyColor.BLACK;
            }
        }
        int len = text.length();
        if (href != null && href.startsWith("po:")) {
            href = href.substring(3);
            if (href.startsWith("join/")) {
                href = href.substring(5);
                text.setSpan(new Href(href, HrefType.join, c), len, len, Spannable.SPAN_MARK_MARK);
            } else if (href.startsWith("watch/")) {
                href = href.substring(6);
                text.setSpan(new Href(href, HrefType.watch, c), len, len, Spannable.SPAN_MARK_MARK);
            } else if (href.startsWith("watchplayer/")) {
                href = href.substring(12);
                text.setSpan(new Href(href, HrefType.watchplayer, c), len, len, Spannable.SPAN_MARK_MARK);
            } else if (href.startsWith("pm/")) {
                href = href.substring(3);
                text.setSpan(new Href(href, HrefType.pm, c), len, len, Spannable.SPAN_MARK_MARK);
            } else if (href.startsWith("ignore/")) {
                href = href.substring(7);
                text.setSpan(new Href(href, HrefType.ignore, c), len, len, Spannable.SPAN_MARK_MARK);
                // } else if (href.startsWith("info/")) {
                //href = href.substring(5);
                //text.setSpan(new Href(href, HrefType.info, c), len, len, Spannable.SPAN_MARK_MARK);
            } else if (href.startsWith("send/")) {
                href = href.substring(5);
                text.setSpan(new Href(href, HrefType.send, c), len, len, Spannable.SPAN_MARK_MARK);
            } else if (href.startsWith("setmsg/")) {
                href = href.substring(7);
                text.setSpan(new Href(href, HrefType.setmsg, c), len, len, Spannable.SPAN_MARK_MARK);
            } else if (href.startsWith("appendmsg/")) {
                href = href.substring(10);
                text.setSpan(new Href(href, HrefType.appendmsg, c), len, len, Spannable.SPAN_MARK_MARK);
            }
        } else {
            text.setSpan(new Href(href, HrefType.url), len, len, Spannable.SPAN_MARK_MARK);
        }
    }

    private static void startBackground(SpannableStringBuilder text, Attributes attributes) {
        String color = attributes.getValue("", "color");
        int    c     = -1;
        if (color != null && !"".equals(color)) {
            try {
                c = MyColor.parseColor(color);
            } catch (IllegalArgumentException e) {
                c = MyColor.BLACK;
            }
        }
        start(text, new BackgroundColorSpan(c));
    }

    private static void startPing(Channel chan, NetworkService netServ) {
        if (chan != null) {
            netServ.tryFlashChannel(chan);
        }
    }

    @Override public void endElement(String uri, String localName, String qName) {
        handleEndTag(localName);
    }

    private void handleEndTag(String tag) {
        if ("br".equalsIgnoreCase(tag)) {
            handleBr(mSpannableStringBuilder);
        } else if ("p".equalsIgnoreCase(tag)) {
            handleP(mSpannableStringBuilder);
        } else if ("div".equalsIgnoreCase(tag)) {
            handleP(mSpannableStringBuilder);
        } else if ("strong".equalsIgnoreCase(tag)) {
            end(mSpannableStringBuilder, Bold.class, new StyleSpan(Typeface.BOLD));
        } else if ("b".equalsIgnoreCase(tag)) {
            end(mSpannableStringBuilder, Bold.class, new StyleSpan(Typeface.BOLD));
        } else if ("em".equalsIgnoreCase(tag)) {
            end(mSpannableStringBuilder, Italic.class, new StyleSpan(Typeface.ITALIC));
        } else if ("cite".equalsIgnoreCase(tag)) {
            end(mSpannableStringBuilder, Italic.class, new StyleSpan(Typeface.ITALIC));
        } else if ("dfn".equalsIgnoreCase(tag)) {
            end(mSpannableStringBuilder, Italic.class, new StyleSpan(Typeface.ITALIC));
        } else if ("i".equalsIgnoreCase(tag)) {
            end(mSpannableStringBuilder, Italic.class, new StyleSpan(Typeface.ITALIC));
        } else if ("big".equalsIgnoreCase(tag)) {
            end(mSpannableStringBuilder, Big.class, new RelativeSizeSpan(1.25f));
        } else if ("small".equalsIgnoreCase(tag)) {
            end(mSpannableStringBuilder, Small.class, new RelativeSizeSpan(0.8f));
        } else if ("font".equalsIgnoreCase(tag)) {
            endFont(mSpannableStringBuilder);
        } else if ("blockquote".equalsIgnoreCase(tag)) {
            handleP(mSpannableStringBuilder);
            end(mSpannableStringBuilder, Blockquote.class, new QuoteSpan());
        } else if ("tt".equalsIgnoreCase(tag)) {
            end(mSpannableStringBuilder, Monospace.class,
                new TypefaceSpan("monospace"));
        } else if ("a".equalsIgnoreCase(tag)) {
            handleAEnd(mSpannableStringBuilder, mChan, mNetServ);
        } else if ("u".equalsIgnoreCase(tag)) {
            end(mSpannableStringBuilder, Underline.class, new UnderlineSpan());
        } else if ("sup".equalsIgnoreCase(tag)) {
            end(mSpannableStringBuilder, Super.class, new SuperscriptSpan());
        } else if ("sub".equalsIgnoreCase(tag)) {
            end(mSpannableStringBuilder, Sub.class, new SubscriptSpan());
        } else if (tag.length() == 2 &&
            Character.toLowerCase(tag.charAt(0)) == 'h' &&
            tag.charAt(1) >= '1' && tag.charAt(1) <= '6') {
            handleP(mSpannableStringBuilder);
            endHeader(mSpannableStringBuilder);
        } else if ("tr".equalsIgnoreCase(tag)) {
            mSpannableStringBuilder.append("\n");
        } else if ("background".equalsIgnoreCase(tag)) {
            endBackground(mSpannableStringBuilder);
        } else if ("strike".equalsIgnoreCase(tag)) {
            end(mSpannableStringBuilder, Strikethrough.class, new StrikethroughSpan());
        } else if (mTagHandler != null) {
            mTagHandler.handleTag(false, tag, mSpannableStringBuilder, mReader);
        }
    }

    private static void handleBr(SpannableStringBuilder text) {
        text.append("\n");
    }

    private static void end(SpannableStringBuilder text, Class kind,
                            Object repl) {
        int    len   = text.length();
        Object obj   = getLast(text, kind);
        int    where = text.getSpanStart(obj);

        text.removeSpan(obj);

        if (where != len) {
            text.setSpan(repl, where, len, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
        }
    }

    private static Object getLast(Spanned text, Class kind) {

        Object[] objs = text.getSpans(0, text.length(), kind);

        if (objs.length == 0) {
            return null;
        } else {
            return objs[objs.length - 1];
        }
    }

    private static void endFont(SpannableStringBuilder text) {
        int    len   = text.length();
        Object obj   = getLast(text, Font.class);
        int    where = text.getSpanStart(obj);

        text.removeSpan(obj);

        if (where != len) {
            Font f = (Font) obj;

            if (!TextUtils.isEmpty(f.mColor)) {
                if (f.mColor.startsWith("@")) {
                    Resources res      = Resources.getSystem();
                    String    name     = f.mColor.substring(1);
                    int       colorRes = res.getIdentifier(name, "color", "android");
                    if (colorRes != 0) {
                        ColorStateList colors = res.getColorStateList(colorRes);
                        text.setSpan(new TextAppearanceSpan(null, 0, 0, colors, null),
                            where, len,
                            Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
                    }
                } else {
                    int color;
                    color = MyColor.getHtmlColor(f.mColor);
                    if (color != -1) {
                        text.setSpan(new ForegroundColorSpan(color | 0xFF000000),
                            where, len,
                            Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
                    }
                }
            }

            if (f.mFace != null) {
                text.setSpan(new TypefaceSpan(f.mFace), where, len,
                    Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
            }
        }
    }

    private static void handleAEnd(SpannableStringBuilder text, Channel channel, NetworkService netServ) {
        int    len   = text.length();
        Object obj   = getLast(text, Href.class);
        int    where = text.getSpanStart(obj);

        if (where != len) {
            Href h = (Href) obj;

            switch (h.mType) {
                case url: {
                    if (h.mHref != null) {
                        text.setSpan(new URLSpan(h.mHref), where, len, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
                    }
                    break;
                }
                case join: {
                    if (h.mHref != null) {
                        text.setSpan(poJoin(h.mHref, netServ), where, len, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
                    }
                    break;
                }
                case watch: {
                    if (h.mHref != null) {
                        text.setSpan(poWatch(h.mHref, netServ), where, len, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
                    }
                    break;
                }
                case watchplayer: {
                    if (h.mHref != null) {
                        text.setSpan(poWatchPlayer(h.mHref, netServ), where, len, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                    }
                    break;
                }
                case pm: {
                    if (h.mHref != null) {
                        text.setSpan(poPM(h.mHref, netServ), where, len, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                    }
                    break;
                }
                case ignore: {
                    if (h.mHref != null) {
                        text.setSpan(poIgnore(h.mHref, netServ), where, len, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                    }
                    break;
                }
                case info: {

                    break;
                }
                case send: {
                    if (h.mHref != null) {
                        text.setSpan(poSend(h.mHref, channel, netServ, h.mColor), where, len, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
                    }
                    break;
                }
                case setmsg: {
                    if (h.mHref != null) {
                        text.setSpan(poSetMsg(h.mHref, netServ), where, len, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                    }
                    break;
                }
                case appendmsg: {
                    if (h.mHref != null) {
                        text.setSpan(poAppend(h.mHref, netServ), where, len, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
                    }
                    break;
                }
            }
        }
    }

    private static ClickableSpan poIgnore(final String idOrName, final NetworkService netServ) {
        return new ClickableSpan() {
            @Override
            public void onClick(@NonNull View widget) {
                if (netServ != null) {
                    netServ.poIgnore(idOrName);
                }
            }
        };
    }

    private static ClickableSpan poSend(final String message, Channel channel, final NetworkService netServ, final int color) {
        final int id = channel.id;
        if (color == -1) {
            return new ClickableSpan() {
                @Override
                public void onClick(@NonNull View widget) {
                    if (netServ != null) {
                        Baos b = new Baos();
                        b.write(1);
                        b.write(0);
                        b.putInt(id);
                        b.putString(message);
                        netServ.socket.sendMessage(b, Command.SendMessage);
                    }
                }
            };
        } else {
            return new ClickableSpan() {
                @Override
                public void onClick(@NonNull View widget) {
                    if (netServ != null) {
                        Baos b = new Baos();
                        b.write(1);
                        b.write(0);
                        b.putInt(id);
                        b.putString(message);
                        netServ.socket.sendMessage(b, Command.SendMessage);
                    }
                }

                @Override
                public void updateDrawState(TextPaint ds) {
                    ds.setColor(color);
                    ds.setUnderlineText(true);
                }
            };
        }
    }

    private static ClickableSpan poJoin(final String channel, final NetworkService netServ) {
        return new ClickableSpan() {
            @Override
            public void onClick(@NonNull View widget) {
                Baos join = new Baos();
                join.putString(channel);
                if (netServ != null && netServ.socket != null && netServ.socket.isConnected()) {
                    netServ.socket.sendMessage(join, Command.JoinChannel);
                }
            }
        };
    }

    private static ClickableSpan poPM(final String idOrName, final NetworkService netServ) {
        return new ClickableSpan() {
            @Override
            public void onClick(@NonNull View widget) {
                if (netServ != null) {
                    netServ.poPM(idOrName);
                }
            }
        };
    }

    private static ClickableSpan poSetMsg(final String message, final NetworkService netServ) {
        return new ClickableSpan() {
            @Override
            public void onClick(@NonNull View widget) {
                if (netServ != null && netServ.chatActivity != null) {
                    netServ.chatActivity.chatSetMsg(message);
                }
            }
        };
    }

    private static ClickableSpan poAppend(final String message, final NetworkService netServ) {
        return new ClickableSpan() {
            @Override
            public void onClick(@NonNull View widget) {
                if (netServ != null && netServ.chatActivity != null) {
                    netServ.chatActivity.chatAppend(message);
                }
            }
        };
    }

    private static ClickableSpan poWatch(final String s, final NetworkService netServ) {
        final int id = AggrxNumbers.parseInt(s,0);
        return new ClickableSpan() {
            @Override
            public void onClick(@NonNull View widget) {
                if (netServ != null) {
                    netServ.startWatching(id);
                }
            }
        };
    }

    private static ClickableSpan poWatchPlayer(final String s, final NetworkService netServ) {
        final int id = AggrxNumbers.parseInt(s,0);
        return new ClickableSpan() {
            @Override
            public void onClick(@NonNull View widget) {
                if (netServ != null) {
                    netServ.poWatchPlayer(s);
                }
            }
        };
    }

    private static void endBackground(SpannableStringBuilder text) {
        Object last = getLast(text, BackgroundColorSpan.class);
        end(text, BackgroundColorSpan.class, last);
    }

    private static void endHeader(SpannableStringBuilder text) {
        int    len = text.length();
        Object obj = getLast(text, Header.class);

        int where = text.getSpanStart(obj);

        text.removeSpan(obj);


        while (len > where && text.charAt(len - 1) == '\n') {
            len--;
        }

        if (where != len) {
            Header h = (Header) obj;

            text.setSpan(new RelativeSizeSpan(HEADER_SIZES[h.mLevel]),
                where, len, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
            text.setSpan(new StyleSpan(Typeface.BOLD),
                where, len, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
        }
    }

    @Override public void characters(char[] ch, int start, int length) {
        StringBuilder sb = new StringBuilder();

        for (int i = 0; i < length; i++) {
            char c = ch[i + start];

            if (c == ' ' || c == '\n') {
                char pred;
                int  len = sb.length();

                if (len == 0) {
                    len = mSpannableStringBuilder.length();

                    if (len == 0) {
                        pred = '\n';
                    } else {
                        pred = mSpannableStringBuilder.charAt(len - 1);
                    }
                } else {
                    pred = sb.charAt(len - 1);
                }

                if (pred != ' ' && pred != '\n') {
                    sb.append(' ');
                }
            } else {
                sb.append(c);
            }
        }

        mSpannableStringBuilder.append(sb);
    }

    @Override public void ignorableWhitespace(char[] ch, int start, int length) {
    }

    @Override public void processingInstruction(String target, String data) {
    }

    @Override public void skippedEntity(String name) {
    }

    private enum HrefType {
        url,
        join,
        watch,
        watchplayer,
        pm,
        ignore,
        info,
        send,
        setmsg,
        appendmsg
    }

    private static class Bold {
    }

    private static class Italic {
    }

    private static class Underline {
    }

    private static class Big {
    }

    private static class Small {
    }

    private static class Monospace {
    }

    private static class Blockquote {
    }

    private static class Super {
    }

    private static class Sub {
    }

    private static class Strikethrough {
    }

    private static class Font {
        public final String mColor;
        public final String mFace;

        public Font(String color, String face) {
            mColor = color;
            mFace = face;
        }
    }

    private static class Href {
        final String   mHref;
        final HrefType mType;
        int      mColor = -1;

        Href(String href, HrefType type) {
            mHref = href;
            mType = type;
        }

        Href(String href, HrefType type, int color) {
            mHref = href;
            mType = type;
            mColor = color;
        }
    }

    private static class Header {
        private final int mLevel;

        Header(int level) {
            mLevel = level;
        }
    }
}
