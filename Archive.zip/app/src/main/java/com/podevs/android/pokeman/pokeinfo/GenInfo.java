package com.podevs.android.pokeman.pokeinfo;

import android.util.SparseArray;
import android.util.SparseIntArray;

import com.podevs.android.pokeman.poke.Gen;

public class GenInfo {
    private static int genMin = 0;
    private static int genMax = 0;
    private static SparseArray<String> genNames = null;
    private static SparseArray<String> versionNames = null;
    private static SparseIntArray maxSubgen = null;

    public static Gen lastGen() {
        return new Gen(genMax, maxSubgen(genMax));
    }

    public static int maxSubgen(int gen) {
        loadGenNames();
        return maxSubgen.get(gen);
    }

    private static void loadGenNames() {
        if (genNames != null) {
            return;
        }
        genNames = new SparseArray<>();
        versionNames = new SparseArray<>();
        maxSubgen = new SparseIntArray();

        String path = PokemonStorage.getGensPath();

        InfoFiller.fill(path, (i, s, o) -> {
            genNames.put(i, s);
            if (i < genMin || (genMin == 0)) {
                genMin = i;
            }
            if (i > genMax || (genMax == 0)) {
                genMax = i;
            }
            genNames.put(i, s);
        });

        path = PokemonStorage.getVersionsPath();

        InfoFiller.uID_fill(path, (i, s, o) -> {
            int gen = i.main;//i % 65536;
            int subGen = i.sub;// i / 65536;

            if (maxSubgen.get(gen) < subGen) {
                maxSubgen.put(gen, subGen);
            }

            versionNames.put(i.hashCode(), s);
        });

        // JxLogger.i("versions", versionNames);
    }

    public static int genMin() {
        loadGenNames();
        return genMin;
    }

    public static int genMax() {
        loadGenNames();
        return genMax;
    }

    public static String name(int gen) {
        loadGenNames();
        return genNames.get(gen, "");
    }

    public static Gen version(String name) {
        return new Gen(versionNames.keyAt(versionNames.indexOfValue(name)));
    }

    public static String name(Gen gen) {
        loadGenNames();
        return versionNames.get(gen.hashCode(), "");
    }
}
