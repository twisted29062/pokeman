package com.podevs.android.pokeman;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager.NameNotFoundException;
import android.graphics.Color;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.os.Binder;
import android.os.Build;
import android.os.Bundle;
import android.os.IBinder;
import android.os.Vibrator;
import android.preference.PreferenceManager;
import android.provider.Settings;

import androidx.annotation.DrawableRes;
import androidx.core.app.NotificationCompat;
import androidx.core.app.TaskStackBuilder;

import com.aggrx.scaffold.AggrxNumbers;
import com.jx.scaffold.JxFunc;
import com.jx.scaffold.JxLogger;
import com.jx.scaffold.JxThreadPool;
import com.podevs.android.pokeman.battle.Battle;
import com.podevs.android.pokeman.battle.BattleActivity;
import com.podevs.android.pokeman.battle.BattleConf;
import com.podevs.android.pokeman.battle.BattleDesc;
import com.podevs.android.pokeman.battle.ChallengeEnums;
import com.podevs.android.pokeman.battle.SpectatingBattle;
import com.podevs.android.pokeman.chat.Channel;
import com.podevs.android.pokeman.chat.ChatActivity;
import com.podevs.android.pokeman.player.FullPlayerInfo;
import com.podevs.android.pokeman.player.PlayerInfo;
import com.podevs.android.pokeman.player.UserInfo;
import com.podevs.android.pokeman.pms.PrivateMessageActivity;
import com.podevs.android.pokeman.pms.PrivateMessageList;
import com.podevs.android.pokeman.poke.PokeParser;
import com.podevs.android.pokeman.poke.ShallowBattlePoke;
import com.podevs.android.pokeman.poke.Team;
import com.podevs.android.pokeman.pokeinfo.InfoConfig;
import com.podevs.android.utilities.Bais;
import com.podevs.android.utilities.Baos;
import com.podevs.android.utilities.FileContent;
import com.podevs.android.utilities.ImageParser;
import com.podevs.android.utilities.MyHtml;
import com.podevs.android.utilities.Security;
import com.podevs.android.utilities.PokeStrings;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.LinkedList;
import java.util.ListIterator;
import java.util.Set;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

//import android.support.v4.app.NotificationCompat;
//import android.support.v4.app.TaskStackBuilder;

@SuppressLint({"ObsoleteSdkInt", "HardwareIds"})
public class NetworkService extends Service {
    public static final Pattern URL_PATTERN = Pattern.compile("(https?://[-\\w.]+)+(:\\d+)?(/([\\S/_.]*(\\?\\S+)?)?)?");
    final static String TAG = "Network Service";
    final static String PKG_NAME = "com.podevs.android.poAndroid";
    final static String DEFAULT_KEY = "default chan for ";
    static final String NOTIFICATION_CHANNEL_ID = "com.podevs.android.poAndroid.notification";
    public static final int MAX_COOKIE_SIZE = 4000;
    static public final HashSet<Integer> pmedPlayers = new HashSet<>();
    public static SharedPreferences POPreferences = null;
    private static final Pattern hashTagPattern = Pattern.compile("(#\\S*\\s??)");
    private static final ChatPrefs chatSettings = new ChatPrefs();
    public final ProtocolVersion version = new ProtocolVersion();
    private final IBinder binder = new LocalBinder();
    //public Channel currentChannel = null;
    public final LinkedList<Channel> joinedChannels = new LinkedList<>();
    // Thread sThread, rThread;
    volatile public PokeClientSocket socket = null;
    public boolean findingBattle = false;
    public boolean registered = false;
    public ChatActivity chatActivity = null;
    public final LinkedList<IncomingChallenge> challenges = new LinkedList<>();
    public boolean askedForPass = false;
    public boolean askedForServerPass = false;
    public boolean failedConnect = false;
    public String serverName = "Not Connected";
    public ProtocolVersion serverVersion = version;
    public boolean serverSupportsZipCompression = false;
    public final ArrayList<Integer> ignoreList = new ArrayList<>();
    public FullPlayerInfo meLoginPlayer;
    public final Hashtable<Integer, Battle> activeBattles = new Hashtable<>();
    public final Hashtable<Integer, SpectatingBattle> spectatedBattles = new Hashtable<>();
    public final Tier superTier = new Tier();
    public int myid = -1;
    public final PlayerInfo me = new PlayerInfo();
    public final Hashtable<Integer, Channel> channels = new Hashtable<>();
    public final Hashtable<Integer, PlayerInfo> players = new Hashtable<>();
    public final Hashtable<Integer, BattleDesc> battles = new Hashtable<>();
    public final PrivateMessageList pms = new PrivateMessageList(me);
    private String salt = null;
    private byte[] salty = null;
    private boolean reconnectDenied = false;
    private volatile boolean halted = false;
    private byte[] reconnectSecret = null;
    private ImageParser imageParser;
    private String ip;
    private int port;

    public static boolean getPMSettings() {
        return chatSettings.timeStampPM;
    }

    /**
     * Are we engaged in a battle?
     *
     * @return True if we are at least in one battle
     */
    public boolean isBattling() {
        return !activeBattles.isEmpty();
    }

    /**
     * Called by a channel when a player leaves. If the player is not on any channel
     * and there's no special circumstances (as in PM), the player will get removed
     *
     * @param pid The id of the player that left
     */
    public void onPlayerLeaveChannel(int pid) {
        if (!isOnAnyChannel(pid) && !pmedPlayers.contains(pid)) {
            removePlayer(pid);
        }
    }

    /**
     * Is the player in any of the same channels as us?
     *
     * @param pid the id of the player we are interested in
     * @return true if the player shares a channel with us, false otherwise
     */
    public boolean isOnAnyChannel(int pid) {
        for (Channel c : channels.values()) {
            if (c.players.containsKey(pid)) {
                return true;
            }
        }
        return false;
    }

    /**
     * Removes a player from memory
     *
     * @param pid The id of the player to remove
     */
    public void removePlayer(int pid) {
        PlayerInfo player = players.remove(pid);
        //TODO: close the PM?
        pmedPlayers.remove(pid);

        if (player != null) {
            for (Integer battleId : player.battles) {
                testRemoveBattle(battleId);
            }
        }
    }

    /**
     * Checks if the players of the battle are online, and remove the battle from memory if not
     *
     * @param battleid the id of the battle to check
     */
    private void testRemoveBattle(Integer battleid) {
        BattleDesc battle = battles.get(battleid);

        if (battle != null) {
            if (!players.containsKey(battle.p1) && !players.containsKey(battle.p2)) {
                battles.remove(battleid);
            }
        }
    }

    /**
     * Checks all battles spectated or fought and removes/destroys the ones
     * that are finished
     */
    public void checkBattlesToEnd() {
        for (SpectatingBattle battle : getBattles()) {
            if (battle.gotEnd) {
                closeBattle(battle.bID);
            }
        }
    }

    /**
     * Returns a list of all the battles fought or spectated
     *
     * @return the battles fought/spectated
     */
    public Collection<SpectatingBattle> getBattles() {
        LinkedList<SpectatingBattle> ret = new LinkedList<>();
        ret.addAll(activeBattles.values());
        ret.addAll(spectatedBattles.values());

        return ret;
    }

    /**
     * Removes a battle spectated/fought from memory and destroys it
     *
     * @param bID The id of the battle to remove
     */
    public void closeBattle(int bID) {
        if (isBattling(bID)) {
            JxFunc.of(activeBattles.remove(bID)).with(Battle::destroy);
        }
        if (spectatedBattles.containsKey(bID)) {
            JxFunc.of(spectatedBattles.remove(bID)).with(SpectatingBattle::destroy);
        }
        /* Remove the battle notification */
        NotificationManager mNotificationManager = getNotificationManager();
        mNotificationManager.cancel("battle", bID);
    }

    /**
     * Are we engaged in a battle with that particular battle ID?
     *
     * @param battleId the battle ID
     * @return true if we are a player of the battle with the battle ID
     */
    public boolean isBattling(int battleId) {
        return activeBattles.containsKey(battleId);
    }

    NotificationManager getNotificationManager() {
        return (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
    }

    public int getChannelID(String name) {
        Set<Integer> keys = channels.keySet();
        for (Integer id : keys) {
            if (channels.get(id).name().equals(name)) {
                return id;
            }
        }
        return -1;
    }


    // This is called once
    @Override
    public void onCreate() {
        super.onCreate();

        /* The context needed for the database */
        InfoConfig.setContext(this);

        NotificationCompat.Builder builder = buildNotificationBuilder(R.drawable.icon, "Chat - Pokemon Online", "Pokemon Online is running")
//            new NotificationCompat.Builder(this, createNotificationChannel())
//                .setSmallIcon(R.drawable.icon)
//                .setContentTitle("Chat - Pokemon Online")
//                .setContentText("Pokemon Online is running")
                .setOngoing(true);

        // Creates an explicit intent for an Activity in your app
        Intent resultIntent = new Intent(this, ChatActivity.class);
        resultIntent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP + Intent.FLAG_ACTIVITY_NEW_TASK);

        builder.setContentIntent(PendingIntent.getActivity(this, 0, resultIntent, PendingIntent.FLAG_UPDATE_CURRENT));

        startForeground(R.id.networkService, builder.build());

        loadPOPreferences(getBaseContext());
        loadSettings();
        //hashTagPattern = Pattern.compile("(#\\S*\\s??)");
        imageParser = new ImageParser(this);
    }

    private NotificationCompat.Builder buildNotificationBuilder(@DrawableRes int smallIcon, String title, String content) {
        return new NotificationCompat.Builder(this, createNotificationChannel())
                .setSmallIcon(smallIcon)
                .setContentTitle(title)
                .setContentText(content);
    }

    private String createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel chan = new NotificationChannel(NOTIFICATION_CHANNEL_ID,
                    NOTIFICATION_CHANNEL_ID, NotificationManager.IMPORTANCE_NONE);
            chan.setLightColor(Color.BLUE);
            chan.setLockscreenVisibility(Notification.VISIBILITY_PRIVATE);
            NotificationManager service = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            if (service != null) {
                service.createNotificationChannel(chan);
            }
        }
        return NOTIFICATION_CHANNEL_ID;
    }

    public static void loadSettings() {
        chatSettings.color = POPreferences.getString("flashColor", "#FFFF00");
        chatSettings.flashing = POPreferences.getBoolean("flashing", true);
        chatSettings.timeStamp = POPreferences.getBoolean("timeStamp", false);
        chatSettings.timeStampPM = POPreferences.getBoolean("timeStampPM", true);
        chatSettings.notificationsPM = POPreferences.getBoolean("notificationsPM", true);
        chatSettings.notificationsFlash = POPreferences.getBoolean("notificationsFlash", false);
        chatSettings.cry = POPreferences.getBoolean("crySound", false);
        chatSettings.pokeNumber = AggrxNumbers.parseInt(POPreferences.getString("pokemonNumber", "648"),0);
        chatSettings.soundVolume = AggrxNumbers.parseInt(POPreferences.getString("soundVolume", "10"),0);
        MessageListAdapter.copyandpaste = POPreferences.getBoolean("copyandpaste", false);
    }

    private static void loadPOPreferences(Context context) {
        POPreferences = PreferenceManager.getDefaultSharedPreferences(context);
        MessageListAdapter.copyandpaste = PreferenceManager.getDefaultSharedPreferences(context).getBoolean("copyandpaste", false);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        super.onStartCommand(intent, flags, startId);
        Bundle bundle = null;
        if (intent != null) // Intent can be null if service restarts after being killed
        // XXX We probably don't handle such restarts very gracefully
        {
            bundle = intent.getExtras();
        }
        if (bundle != null && bundle.containsKey("loginPlayer")) {
            meLoginPlayer = new FullPlayerInfo(new Bais(bundle.getByteArray("loginPlayer")));
            me.setTo(new PlayerInfo(meLoginPlayer));
        }
        if (bundle != null && bundle.containsKey("ip") && bundle.containsKey("port")) {
            connect(bundle.getString("ip"), bundle.getInt("port"));
        }

        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        // XXX TODO be more graceful
        JxLogger.d("NETWORK SERVICE DESTROYED; EXPECT BAD THINGS TO HAPPEN");

        for (SpectatingBattle battle : getBattles()) {
            closeBattle(battle.bID);
        }

        stopForeground(true);
        halted = true;
    }

    @Override
    // This is *NOT* called every time someone binds to us, I don't really know why
    // but onServiceConnected is correctly called in the activity sooo....
    public IBinder onBind(Intent intent) {
        return binder;
    }

    public void connect(String ip, int port) {
        this.ip = ip;
        this.port = port;

        String cookie = FileContent.getFileContent(this, "cookie-" + Security.md5(ip));
        // XXX This should probably have a timeout
        JxThreadPool.shared().post("connect", this, value -> {
            //new Thread(() -> {
            try {
                socket = new PokeClientSocket(NetworkService.this.ip, NetworkService.this.port);
            } catch (IOException e) {
                failedConnect = true;
                if (chatActivity != null) {
                    chatActivity.notifyFailedConnection();
                }
                return;
            }

            Baos loginCmd = new Baos();
            loginCmd.putBaos(version); //Protocol version

            String defaultChannel;
            Set<String> autoJoinChannels = null;

            SharedPreferences prefs = getSharedPreferences("autoJoinChannels", MODE_PRIVATE);
            String key = NetworkService.this.ip + ":" + NetworkService.this.port;

            if (prefs.contains(key)) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB) {
                    autoJoinChannels = prefs.getStringSet(key, null);
                }
            }
            defaultChannel = prefs.getString(DEFAULT_KEY + key, null);

            /* Network Flags: hasClientType, hasVersionNumber, hasReconnect, hasDefaultChannel, hasAdditionalChannels,
             * hasColor, hasTrainerInfo, hasNewTeam, hasEventSpecification, hasPluginList. */                //hasCookie hasID
            loginCmd.putFlags(new boolean[]{true, true, true, defaultChannel != null, autoJoinChannels != null,
                    meLoginPlayer.color().isValid(), true, meLoginPlayer.team.isValid(), false, false, cookie.length() > 0, true}); //Network flags
            loginCmd.putString("android");
            short versionCode;
            try {
                versionCode = (short) getPackageManager().getPackageInfo(getPackageName(), 0).versionCode;
            } catch (NameNotFoundException e1) {
                versionCode = 404;
            }
            loginCmd.putShort(versionCode);
            loginCmd.putString(meLoginPlayer.nick());
            /* Data Flags: supportsZipCompression, isLadderEnabled, wantsIdsWithMessages, isIdle */
            loginCmd.putFlags(new boolean[]{false, true, true, getSharedPreferences("clientOptions", MODE_PRIVATE).getBoolean("idle", false)});

            /* Reconnect even if all the bits are different */
            loginCmd.write(0);

            if (defaultChannel != null) {
                loginCmd.putString(defaultChannel);
            }
            if (autoJoinChannels != null) {
                Object[] channels = autoJoinChannels.toArray();
                loginCmd.putInt(channels.length);
                for (Object chan : channels) {
                    loginCmd.putString(chan.toString());
                }
            }

            if (meLoginPlayer.color().isValid()) {
                loginCmd.putBaos(meLoginPlayer.color());
            }

            loginCmd.putBaos(meLoginPlayer.profile.trainerInfo);

            if (meLoginPlayer.team.isValid()) {
                loginCmd.write(1); // number of teams
                loginCmd.putBaos(meLoginPlayer.team);
            }

            if (cookie.length() > 0) {
                loginCmd.putString(cookie);
            }

            loginCmd.putBool(getUniqueIdFlag());

            loginCmd.putString(getUniqueId());

            socket.sendMessage(loginCmd, Command.Login);

            do {
                readSocketMessages(socket);

                if (halted) {
                    return;
                }

                writeMessage("(" + PokeStrings.timeStamp() + ") Disconnected from server");

                reconnect();
            } while (!reconnectDenied && !halted);
            //}).start();
        });
    }

    private void reconnect() {
        /* Impossible to reconnect with -1 id */
        if (myid == -1 || reconnectSecret == null) {
            reconnectDenied = true;
            return;
        }
        while (!halted) {
            try {
                socket = new PokeClientSocket(ip, port);
            } catch (IOException e) {
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException e2) {
                    e2.printStackTrace();
                }
                continue;
            }

            Baos msgToSend = new Baos();
            msgToSend.putInt(me.id);
            msgToSend.putBytes(reconnectSecret);

            socket.sendMessage(msgToSend, Command.Reconnect);

            return;
        }
    }

    private void readSocketMessages(PokeClientSocket socket) {
        while (!halted && socket.isConnected()) {
            try {
                handleMsg(socket.getMsg());
            } catch (IOException | ParseException e) {
                // Disconnected
                break;
            } // Got message that overflowed length from server.
            // No way to recover.
            // TODO die completely

        }
    }

    public void handleMsg(Bais msg) {
        byte i = msg.readByte();

        if (i < 0 || i >= Command.values().length) {
            JxLogger.w("Command out of bounds: " + i);
        }

        Command c = Command.values()[i];
        //JxLogger.d("%s","Received: " + c);
        switch (c) {
            case ChannelPlayers:
            case JoinChannel:
            case LeaveChannel: {
                Channel ch = channels.get(msg.readInt());
                if (ch != null) {
                    ch.handleChannelMsg(c, msg);
                } else {
                    JxLogger.e("Received message for nonexistent channel");
                }
                break;
            }
            case VersionControl: {
                handleVersionControlMsg(msg);
                break;
            }
            case Cookie: {
                handleCookieMsg(msg);
                break;
            }
            case KeepAlive: {
                handleKeepAliveMsg();
                break;
            }
            case Register: {
                // Username not registered
                break;
            }
            case Login: {
                handleLoginMsg(msg);
                break;
            }
            case TierSelection: {
                handleTierSelectionMsg(msg);
                break;
            }
            case ChannelsList: {
                handleChannelsListMsg(msg);
                break;
            }
            case PlayersList: {
                handlePlayersListMsg(msg);
                break;
            }
            case OptionsChanged: {
                handleOptionsChangedMsg(msg);
                break;
            }
            case GetUserInfo: {
                handleGetUserInfoMsg(msg);
                break;
            }
            case GetUserAlias: {
                handleGetUserAliasMsg(msg);
                break;
            }
            case ShowRankings: {
                handleShowRankingsMsg(msg);
                break;
            }
            case SendMessage: {
                handleSendMessageMsg(msg);
                break;
            }
            case BattleList: {
                handleBattleListMsg(msg);
                break;
            }
            case ChannelBattle: {
                handleChannelBattleMsg(msg);
                break;
            }
            case ChallengeStuff: {
                handleChallengeStuffMsg(msg);
                break;
            }
            case Reconnect: {
                handleReconnectMsg(msg);
                break;
            }
            case Logout: {
                handleLogoutMsg(msg);
                break;
            }
            case BattleFinished: {
                handleBattleFinishedMsg(msg);
                break;
            }
            case SendPM: {
                handleSendPMMsg(msg);
                break;
            }
            case SendTeam: {
                handleSendTeamMsg(msg);
                break;

            }
            case BattleMessage: {
                handleBattleMessageMsg(msg);
                break;
            }
            case EngageBattle: {
                handleEngageBattleMsg(msg);
                break;
            }
            case SpectateBattle: {
                handleSpectateBattleMsg(msg);

                break;
            }
            case SpectateBattleMessage: {
                handleSpectateBattleMessageMsg(msg);
                break;
            }
            case AskForPass: {
                handleAskForPassMsg(msg);
                break;
            }
            case AddChannel: {
                handleAddChannelMsg(msg);
                break;
            }
            case RemoveChannel: {
                handleRemoveChannelMsg(msg);
                break;
            }
            case ChanNameChange: {
                handleChanNameChangeMsg(msg);
                break;
            }
            case ServerPassword: {
                handleServerPasswordMsg(msg);
                break;
            }
            case PlayerKick: {
                handlePlayerKickMsg(msg);
                break;
            }
            case PlayerBan: {
                handlePlayerBanMsg(msg);
                break;
            }
            // case AndroidID: {
            //    handleAndroidIDMsg();
            //    break;
            // }
            default: {
                JxLogger.w("Unimplemented message: %s", c.toString());
            }
        }
        for (SpectatingBattle battle : getBattles()) {
            if (battle.activity != null && battle.histDelta.length() != 0) {
                battle.activity.updateBattleInfo(false);
            }
        }
        if (chatActivity != null && chatActivity.currentChannel() != null) {
            chatActivity.updateChat();
        }
    }

//    private void handleAndroidIDMsg() {
//        new Thread(new Runnable() {
//            @Override public void run() {
//                try {
//                    socket = new PokeClientSocket(NetworkService.this.ip, NetworkService.this.port);
//                } catch (IOException e) {
//                    return;
//                }
//                socket.sendMessage(getUniqueId(), Command.AndroidID);
//            }
//        }).start();
//    }

    private void handleServerPasswordMsg(Bais msg) {
        salty = msg.readQByteArray();
        askedForServerPass = true;
        if (chatActivity != null && (chatActivity.hasWindowFocus() || chatActivity.progressDialog.isShowing())) {
            chatActivity.notifyAskForServerPass();
        }
    }

    private void handleChanNameChangeMsg(Bais msg) {
        int chanId = msg.readInt();
        if (chatActivity != null) {
            chatActivity.removeChannel(channels.get(chanId));
        }
        channels.remove(chanId);
        channels.put(chanId, new Channel(chanId, msg.readString(), this));
    }

    private void handleRemoveChannelMsg(Bais msg) {
        int chanId = msg.readInt();
        if (chatActivity != null) {
            chatActivity.removeChannel(channels.get(chanId));
        }
        channels.remove(chanId);
    }

    private void handleAddChannelMsg(Bais msg) {
        addChannel(msg.readString(), msg.readInt());
    }

    private void handleAskForPassMsg(Bais msg) {
        salt = msg.readString();
        // XXX not sure what the second half is supposed to check
        // from analyze.cpp : 265 of PO's code
        if (salt.length() < 6) { //  || strlen((" " + salt).toUtf8().data()) < 7)
            System.out.println("Protocol Error: The server requires insecure authentication");
            return;
        }
        askedForPass = true;
        if (chatActivity != null && (chatActivity.hasWindowFocus() || chatActivity.progressDialog.isShowing())) {
            chatActivity.notifyAskForPass();
        }
    }

    private void handleSpectateBattleMessageMsg(Bais msg) {
        int battleId = msg.readInt();
        msg.readInt(); // discard the size, unneeded
        if (spectatedBattles.containsKey(battleId)) {
            spectatedBattles.get(battleId).receiveCommand(msg);
        }
    }

    private void handlePlayerKickMsg(Bais msg) {
        int dest = msg.readInt();
        int src = msg.readInt();

        String message;
        if (src == 0) {
            message = "<font color=#ff0000><b> " + getName(dest) + " was kicked by the server!</b></font>";
        } else {
            message = "<font color=#ff0000><b> " + getName(src) + " kicked " + getName(dest) + "</b></font>";
        }
        for (Channel next : joinedChannels) {
            next.writeToHist(MyHtml.fromHtml(message), false, null);
        }
    }

    private void handlePlayerBanMsg(Bais msg) {
        int dest = msg.readInt();
        int src = msg.readInt();

        String message;
        if (src == 0) {
            message = "<font color=#ff0000><b> " + getName(dest) + " was banned by the server!</b></font>";
        } else {
            message = "<font color=#ff0000><b> " + getName(src) + " banned " + getName(dest) + "</b></font>";
        }
        for (Channel next : joinedChannels) {
            next.writeToHist(MyHtml.fromHtml(message), false, null);
        }
    }

    void handleSpectateBattleMsg(Bais msg) {
        Bais flags = msg.readFlags();
        int battleId = msg.readInt();

        if (flags.readBool()) {
            if (spectatedBattles.contains(battleId)) {
                JxLogger.e("Already watching battle " + battleId);
                socket.sendMessage(new Baos().putInt(battleId).putBool(false), Command.SpectateBattle);
                return;
            }
            BattleConf conf = new BattleConf(msg, serverVersion.compareTo(new ProtocolVersion(1, 0)) < 0);

            PlayerInfo p1 = getNonNullPlayer(conf.id(0));
            PlayerInfo p2 = getNonNullPlayer(conf.id(1));
            SpectatingBattle battle = new SpectatingBattle(conf, p1, p2, battleId, this);
            spectatedBattles.put(battleId, battle);

            Intent intent = new Intent(this, BattleActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            intent.putExtra("battleId", battleId);
            startActivity(intent);

            showBattleNotification("Spectated Battle", battleId, conf);
        } else {
            closeBattle(battleId);
        }
    }

    private void handleEngageBattleMsg(Bais msg) {
        int battleId;// = msg.readInt();
        Bais flags;// = msg.readFlags();
        BattleDesc info = new BattleDesc();

        if (ProtocolVersion.lessThan(serverVersion, 2, 0)) {
            battleId = msg.readInt();
            flags = msg.readFlags();
            info.mode = msg.readByte();
            info.readOld(msg);
        } else {
            flags = msg.readFlags();
            battleId = msg.readInt();
            info.read(msg);
        }

        boolean isOurBattle = flags.readBool();

        if (isOurBattle) {
            String test = "";
        }

        addBattle(battleId, info, true);

        if (isOurBattle) { // This is us!
            BattleConf conf = new BattleConf(msg, ProtocolVersion.lessThan(serverVersion, 1, 0));
            // Start the battle
            Battle battle = new Battle(conf, msg, getNonNullPlayer(conf.id(0)), getNonNullPlayer(conf.id(1)), myid, battleId, this);
            activeBattles.put(battleId, battle);

            joinedChannels.peek().writeToHist("Battle between " + playerName(info.p1) +
                    " and " + playerName(info.p2) + " started!", false, null);
            Intent intent = new Intent(this, BattleActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            intent.putExtra("battleId", battleId);
            startActivity(intent);
            findingBattle = false;

            showBattleNotification("Battle", battleId, conf);
        }

        if (chatActivity != null) {
            chatActivity.updatePlayer(players.get(info.p1), players.get(info.p1));
            chatActivity.updatePlayer(players.get(info.p2), players.get(info.p2));
        }
    }

    private void handleBattleMessageMsg(Bais msg) {
        int battleId = msg.readInt(); // currently support only one battle, unneeded
        msg.readInt(); // discard the size, unneeded
        if (isBattling(battleId)) {
            activeBattle(battleId).receiveCommand(msg);
        }
    }

    private void handleSendTeamMsg(Bais msg) {
        Bais flags = msg.readFlags();
        if (flags.readBool()) {
            String name = msg.readString();
        }
        if (flags.readBool()) {
            ArrayList<String> tiers = msg.readQStringList();
            if (tiers != null) {
                chatActivity.makeToast("Loaded " + tiers.get(0), "short");
            }
        }
    }

    private void handleSendPMMsg(Bais msg) {
        int playerId = msg.readInt();
        if (ignoreList.contains(playerId)) {
            return;
        }
        String message = msg.readString();

        dealWithPM(playerId, message);
    }

    private void handleBattleFinishedMsg(Bais msg) {
        int battleID = msg.readInt();
        byte battleDesc = msg.readByte();
        msg.readByte(); // battle mode
        int id1 = msg.readInt();
        int id2 = msg.readInt();

        // JxLogger.i("%s", "bID " + battleID + " battleDesc " + battleDesc + " id1 " + id1 + " id2 " + id2);
        String[] outcome = new String[]{" won by forfeit against ", " won against ", " tied with "};
        if (isBattling(battleID) || spectatedBattles.containsKey(battleID)) {
//				if (isBattling(battleID)) {
            //TODO: notification on win/lose
//					if (mePlayer.id == id1 && battleDesc < 2) {
//						showNotification(ChatActivity.class, "Chat", "You won!");
//					} else if (mePlayer.id == id2 && battleDesc < 2) {
//						showNotification(ChatActivity.class, "Chat", "You lost!");
//					} else if (battleDesc == 2) {
//						showNotification(ChatActivity.class, "Chat", "You tied!");
//					}
//				}

            if (battleDesc < 2) {
                joinedChannels.peek().writeToHist(MyHtml.fromHtml("<b><i>" +
                        PokeStrings.escapeHtml(playerName(id1)) + outcome[battleDesc] +
                        PokeStrings.escapeHtml(playerName(id2)) + ".</b></i>"), false, null);
            }

            if (battleDesc == 0 || battleDesc == 3) {
                closeBattle(battleID);
            }
        }

        removeBattle(battleID);
    }

    private void handleLogoutMsg(Bais msg) {
        // Only sent when player is in a PM with you and logs out
        int playerID = msg.readInt();
        removePlayer(playerID);
        // logout event
        //System.out.println("Player " + playerID + " logged out.");
    }

    private void handleReconnectMsg(Bais msg) {
        boolean success = msg.readBool();

        if (success) {
            reconnectDenied = false;

            writeMessage("(" + PokeStrings.timeStamp() + ") Reconnected to server");

            for (Channel ch : joinedChannels) {
                ch.clearData();
            }
            joinedChannels.clear();
        } else {
            reconnectDenied = true;
        }
    }

    private void handleChallengeStuffMsg(Bais msg) {
        IncomingChallenge challenge = new IncomingChallenge(msg);
        challenge.setNick(players.get(challenge.opponent));

        if (challenge.desc < 0 || challenge.desc >= ChallengeEnums.ChallengeDesc.values().length) {
            JxLogger.w("Challenge description out of bounds: " + challenge.desc);
            return;
        }
        switch (ChallengeEnums.ChallengeDesc.values()[challenge.desc]) {
            case Sent:
                if (challenge.isValidChallenge(players)) {
                    if (ignoreList.contains(challenge.opponent)) {
                        break;
                    }
                    challenges.addFirst(challenge);
                    if (chatActivity != null && chatActivity.hasWindowFocus()) {
                        chatActivity.notifyChallenge();
                    } else {
                        NotificationCompat.Builder builder = buildNotificationBuilder(R.drawable.icon, "Pokemon Online", "You've been challenged by " + challenge.oppName + "!");
//                            new NotificationCompat.Builder(this, createNotificationChannel())
//                                .setSmallIcon(R.drawable.icon)
//                                .setContentTitle("Pokemon Online")
//                                .setContentText("You've been challenged by " + challenge.oppName + "!");

                        // Because clicking the notification opens a new ("special") activity, there's
                        // no need to create an artificial back stack.
                        PendingIntent resultPendingIntent =
                                PendingIntent.getActivity(
                                        this,
                                        0,
                                        new Intent(NetworkService.this, ChatActivity.class),
                                        PendingIntent.FLAG_UPDATE_CURRENT
                                );

                        builder.setContentIntent(resultPendingIntent);

                        // Sets an ID for the notification
                        int notificationId = IncomingChallenge.note;
                        // Gets an instance of the NotificationManager service
                        NotificationManager manager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
                        // Builds the notification and issues it.
                        manager.notify(notificationId, builder.build());
                    }
                }
                break;
            case Refused:
                if (challenge.oppName != null && chatActivity != null) {
                    chatActivity.makeToast(challenge.oppName + " refused your challenge", "short");
                }
                break;
            case Busy:
                if (challenge.oppName != null && chatActivity != null) {
                    chatActivity.makeToast(challenge.oppName + " is busy", "short");
                }
                break;
            case InvalidTeam:
                if (chatActivity != null) {
                    chatActivity.makeToast("Challenge failed due to invalid team", "long");
                }
                break;
            case InvalidGen:
                if (chatActivity != null) {
                    chatActivity.makeToast("Challenge failed due to invalid gen", "long");
                }
                break;
            case InvalidTier:
                if (chatActivity != null) {
                    chatActivity.makeToast("Challenge failed due to invalid tier", "long");
                }
                break;
        }
    }

    private void handleChannelBattleMsg(Bais msg) {
        msg.readInt(); //channel, but irrelevant
        int battleId = msg.readInt();
        //byte mode = msg.readByte();
        int player1 = msg.readInt();
        int player2 = msg.readInt();

        addBattle(battleId, new BattleDesc(player1, player2), false);
    }

    private void handleBattleListMsg(Bais msg) {
        msg.readInt(); //channel, but irrelevant
        int numBattles = msg.readInt();
        for (; numBattles > 0; numBattles--) {
            int battleId = msg.readInt();
            //byte mode = msg.readByte(); /* protocol is messed up */
            int player1 = msg.readInt();
            int player2 = msg.readInt();

            addBattle(battleId, new BattleDesc(player1, player2), false);
        }
    }

    private void handleSendMessageMsg(Bais msg) {
        Bais netFlags = msg.readFlags();
        boolean hasChannel = netFlags.readBool();
        boolean hasId = netFlags.readBool();
        Bais dataFlags = msg.readFlags();
        boolean isHtml = dataFlags.readBool();

        Channel chan = null;
        PlayerInfo player = null;
        int pId = 0;
        if (hasChannel) {
            chan = channels.get(msg.readInt());
        }
        if (hasId) {
            player = players.get(pId = msg.readInt());
        }
        CharSequence message = msg.readString();
        Matcher hashTagMatcher;
        if (hasId) {
            if (ignoreList.contains(pId)) {
                return;
            }
            CharSequence color = (player == null ? "orange" : player.color.toHexString());
            CharSequence name = playerName(pId);
            String test;
            if (chatSettings.timeStamp) {
                test = "(" + PokeStrings.timeStamp() + ") ";
            } else {
                test = "";
            }
            String beg = "<font color='" + color + "'><b>" + test;
            if (playerAuth(pId) > 0 && playerAuth(pId) < 4) {
                beg += "+<i>" + name + ": </i></b></font>";
            } else {
                beg += name + ": </b></font>";
            }
            if (isHtml) {
                message = MyHtml.fromHtml(beg + message);
            } else {
                if (chatSettings.flashing) {
                    if (message.toString().toLowerCase().contains(me.nick.toLowerCase())) {
                        // Be certain!
                        Pattern myName = Pattern.compile("(?<!\\S)(" + me.nick.toLowerCase() + ")(?!\\w)");
                        Matcher myMatcher = myName.matcher(message.toString().toLowerCase());
                        if (myMatcher.find()) {
                            message = MyHtml.fromHtml(beg + PokeStrings.escapeHtml((String) message));
                            int left = (String.valueOf(message)).toLowerCase().indexOf(me.nick.toLowerCase());
                            int right = me.nick.length() + left;
                            if (!hasChannel) {
                                // Broadcast message
                                if (chatActivity != null && message.toString().contains("Wrong password for this name.")) // XXX Is this still the message sent?
                                {
                                    chatActivity.makeToast(message.toString(), "long");
                                } else {
                                    for (Channel next : joinedChannels) {
                                        next.writeToHist(message, left, right, chatSettings.color, false, null);
                                    }
                                }
                            } else {
                                if (chan == null) {
                                    JxLogger.e("Received message for nonexistent channel");
                                } else {
                                    boolean click = false;
                                    String command = null;
                                    hashTagMatcher = hashTagPattern.matcher(message);
                                    if (hashTagMatcher.find()) {
                                        command = hashTagMatcher.group(0);
                                        if (channelNameTagger(command.toLowerCase().replace("#", ""))) {
                                            click = true;
                                        } else {
                                            command = null;
                                        }
                                    }
                                    chan.writeToHist(message, left, right, chatSettings.color, click, command);
                                    if (chan != joinedChannels.getFirst()) {
                                        chan.flashed = true;
                                        chatActivity.notifyChannelList();
                                        if (chatSettings.notificationsFlash) {
                                            chatActivity.makeToast(playerName(pId) + " flashed you in " + chan.name() + ".", "long");
                                        }
                                    }
                                }
                            }
                            return;
                        }
                    }
                }
                message = MyHtml.fromHtml(beg + PokeStrings.escapeHtml((String) message));
            }
        } else {
            if (isHtml) {
                message = MyHtml.fromHtml((String) message, imageParser, null, chan, this);
            } else {
                String str = PokeStrings.escapeHtml((String) message);
                int index = str.indexOf(':');

                if (str.startsWith("*** ")) {
                    message = MyHtml.fromHtml("<font color='#FF00FF'>" + str + "</font>");
                } else if (index != -1) {
                    String firstPart = str.substring(0, index);
                    String secondPart;

                    try {
                        secondPart = str.substring(index + 2);
                    } catch (IndexOutOfBoundsException ex) {
                        secondPart = "";
                    }

                    CharSequence color = "#318739";
                    if ("Welcome Message".equals(firstPart)) {
                        color = "blue";
                    } else if ("~~Server~~".equals(firstPart)) {
                        color = "orange";
                    }

                    message = MyHtml.fromHtml("<font color='" + color + "'><b>" + firstPart +
                            ": </b></font>" + secondPart);
                }
            }
        }

        if (!hasChannel) {
            // Broadcast message
            if (chatActivity != null && message.toString().contains("Wrong password for this name.")) // XXX Is this still the message sent?
            {
                chatActivity.makeToast(message.toString(), "long");
            } else {
                for (Channel next : joinedChannels) {
                    next.writeToHist(message, false, null);
                }
            }
        } else {
            if (chan == null) {
                JxLogger.e("Received message for nonexistent channel");
            } else {
                boolean click = false;
                String command = null;
                hashTagMatcher = hashTagPattern.matcher(message);
                if (hashTagMatcher.find()) {
                    command = hashTagMatcher.group(0);
                    if (command != null && channelNameTagger(command.toLowerCase().replace("#", ""))) {
                        click = true;
                    } else {
                        command = null;
                    }
                }
                chan.writeToHist(message, click, command);
                if (chan != joinedChannels.getFirst()) {
                    chan.newMessage = true;
                }
            }
        }
    }

    private void handleShowRankingsMsg(Bais msg) {
        boolean starting = msg.readBool();
        if (starting) {
            int startingPage = msg.readInt();
            int startingRank = msg.readInt();
            int total = msg.readInt();
            // Add Ranking window
            chatActivity.updateViewRanking(startingPage, startingRank, total);
        } else {
            String name = msg.readString();
            int points = msg.readInt();
            // Add ranking
            chatActivity.updateViewRanking(name, points);
        }
    }

    private void handleGetUserAliasMsg(Bais msg) {
        chatActivity.updateControlPanel(msg.readString());
    }

    private void handleGetUserInfoMsg(Bais msg) {
        UserInfo info = new UserInfo(msg);
        if (getID(info.name) != -1) {
            info.flags |= UserInfo.FLAG_ONLINE;
        }
        chatActivity.updateControlPanel(info);
    }

    private void handleOptionsChangedMsg(Bais msg) {
        int id = msg.readInt();
        Bais dataFlags = msg.readFlags();

        PlayerInfo p = players.get(id);
        if (p != null) {
            p.hasLadderEnabled = dataFlags.readBool();
            p.isAway = dataFlags.readBool();

            if (p.id == myid) {
                me.setTo(p);
            }
            chatActivity.updatePlayer(p, p);
        }
    }

    private void handlePlayersListMsg(Bais msg) {
        while (msg.available() != 0) { // While there's playerInfo's available
            PlayerInfo p = new PlayerInfo(msg);
            PlayerInfo oldPlayer = players.get(p.id);
            players.put(p.id, p);

            if (oldPlayer != null) {
                if (!p.nick().equals(oldPlayer.nick())) {
                    for (Channel chan : channels.values()) {
                        if (chan.joined && chan.channelEvents) {
                            if (chan.players.contains(p) || chan.players.contains(oldPlayer)) {
                                CharSequence message = MyHtml.fromHtml("<i><font color=\"#A0A0A0\">" + oldPlayer.nick() + " changed names to " + p.nick() + "</font></i>");
                                chan.writeToHistSmall(message);
                            }
                        }
                    }
                }
                p.battles = oldPlayer.battles;
                // name change event
                if (chatActivity != null) {

                    /* Updates the player in the adapter memory */
                    chatActivity.updatePlayer(p, oldPlayer);
                }
            }
            /* Updates self player */
            if (p.id == myid) {
                me.setTo(p);
            }
        }
    }

    private void handleChannelsListMsg(Bais msg) {
        int numChannels = msg.readInt();

        for (int j = 0; j < numChannels; j++) {
            int chanId = msg.readInt();

            if (hasChannel(chanId)) {
                Channel ch = channels.get(chanId);
                if (ch != null) {
                    ch.name = msg.readString();
                }
            } else {
                Channel ch = new Channel(chanId, msg.readString(), this);
                channels.put(chanId, ch);
            }

            //addChannel(msg.readQString(),chanId);
        }
        JxLogger.d("%s", channels.toString());
    }

    private void handleTierSelectionMsg(Bais msg) {
        superTier.reset();

        msg.readInt(); // Number of tiers
        Tier prevTier = new Tier(msg.readByte(), msg.readString());
        prevTier.parentTier = superTier;
        superTier.subTiers.add(prevTier);
        while (msg.available() != 0) { // While there's another tier available
            Tier t = new Tier(msg.readByte(), msg.readString());
            if (t.level == prevTier.level) { // Sibling case
                prevTier.parentTier.addSubTier(t);
                t.parentTier = prevTier.parentTier;
            } else if (t.level < prevTier.level) { // Uncle case
                while (t.level < prevTier.level) {
                    prevTier = prevTier.parentTier;
                }
                prevTier.parentTier.addSubTier(t);
                t.parentTier = prevTier.parentTier;
            } else if (t.level > prevTier.level) { // Child case
                prevTier.addSubTier(t);
                t.parentTier = prevTier;
            }
            prevTier = t;
        }

        superTier.save(this);
    }

    private void handleLoginMsg(Bais msg) {
        reconnectDenied = false;

        Bais flags = msg.readFlags();
        boolean hasReconnPass = flags.readBool();
        if (hasReconnPass) {
            reconnectSecret = msg.readQByteArray();
        } else {
            reconnectSecret = null;
        }

        me.setTo(new PlayerInfo(msg));
        myid = me.id;
        int numTiers = msg.readInt();
        for (int j = 0; j < numTiers; j++) {
            // Tiers for each of our teams
            // TODO Do something with this info?
            msg.readString();
        }
        players.put(myid, me);
    }

    private void handleKeepAliveMsg() {
        socket.sendMessage(null, Command.KeepAlive);
    }

    private void handleCookieMsg(Bais msg) {
        Bais network = msg.readFlags();
        if (network.readBool()) {
            String content = msg.readString();
            if (content.length() > MAX_COOKIE_SIZE) {
                JxLogger.w("Cookie too long, not saving");
            } else {
                FileContent.setFileContent(this, "cookie-" + Security.md5(ip), content);
            }
        } else {
            FileContent.removeFile(this, "cookie-" + Security.md5(ip));
        }
    }

    private void handleVersionControlMsg(Bais msg) {
        serverVersion = new ProtocolVersion(msg);

			/* Toast messages there trigger an exception:
			 *
			 * java.lang.RuntimeException: Can't create handler inside thread that has not called Looper.prepare()
				at android.os.Handler.<init>(Handler.java:121)
				at android.widget.Toast.<init>(Toast.java:73)
				at android.widget.Toast.makeText(Toast.java:249)
				at com.podevs.android.poAndroid.NetworkService.handleMsg(NetworkService.java:523)
				at com.podevs.android.poAndroid.NetworkService.readSocketMessages(NetworkService.java:468)
				at com.podevs.android.poAndroid.NetworkService.access$2(NetworkService.java:450)
				at com.podevs.android.poAndroid.NetworkService$1.run(NetworkService.java:408)
				at java.lang.Thread.run(Thread.java:1019)
			 */
        if (serverVersion.compareTo(version) > 0) {
            JxLogger.d("Server has newer protocol version than we expect");
        } // else if (serverVersion.compareTo(version) < 0) {
        //Toast.makeText(this, "PO Android uses newer network protocol than Server", Toast.LENGTH_LONG);
        // }

        serverSupportsZipCompression = msg.readBool();

        // ProtocolVersion lastVersionWithoutFeatures = new ProtocolVersion(msg);
        // ProtocolVersion lastVersionWithoutCompatBreak = new ProtocolVersion(msg);
        // ProtocolVersion lastVersionWithoutMajorCompatBreak = new ProtocolVersion(msg);

        //if (serverVersion.compareTo(version) > 0) {
        // if (lastVersionWithoutFeatures.compareTo(version) > 0) {
        //Toast.makeText(this, R.string.new_server_feaantures_warning, Toast.LENGTH_SHORT).show();
        //} else if (lastVersionWithoutCompatBreak.compareTo(version) > 0) {
        //Toast.makeText(this, R.string.minor_compat_break_warning, Toast.LENGTH_SHORT).show();
        //} else if (lastVersionWithoutMajorCompatBreak.compareTo(version) > 0) {
        //Toast.makeText(this, R.string.major_compat_break_warning, Toast.LENGTH_LONG).show();
        //}
        //}
        serverName = msg.readString();
        if (chatActivity != null) {
            chatActivity.updateTitle();
        }
    }

    private Battle activeBattle(int battleId) {
        return activeBattles.get(battleId);
    }

    public void addBattle(int battleid, BattleDesc desc, boolean show) {
        battles.put(battleid, desc);
        // battle event
        // String n1 = "";
        if (players.containsKey(desc.p1)) {
            JxFunc.of(players.get(desc.p1)).with(v -> v.addBattle(battleid));
            //	n1 = players.get(desc.p1).nick();
        }
        // String n2 = "";
        if (players.containsKey(desc.p2)) {
            JxFunc.of(players.get(desc.p2)).with(v -> v.addBattle(battleid));
            // n2 = players.get(desc.p2).nick();
        }
		/*
		if (show) {
			for (Channel chan : channels.values()) {
				if (chan.joined && chan.channelEvents) {
					if (chan.players.contains(players.get(desc.p1)) || chan.players.contains(players.get(desc.p2))) {
						// needs better method.
						// Maybe create an array of channels to check?
						CharSequence message = MyHtml.fromHtml("<i><font color=\"#A0A0A0\">Battle started between " + n1 + " and " + n2 + ".</font></i>");
						chan.writeToHistSmall(message);
					}
				}
			}
		}
		*/
    }

    /**
     * Removes a battle from memory
     *
     * @param battleId the battle id of the battle to remove
     */
    private void removeBattle(int battleId) {
        if (!battles.containsKey(battleId)) {
            return;
        }
        BattleDesc battle = battles.get(battleId);
        if (battle == null) {
            return;
        }
        JxFunc.of(players.get(battle.p1)).with(value -> value.removeBattle(battleId));
        JxFunc.of(players.get(battle.p2)).with(value -> value.removeBattle(battleId));
    }

    /**
     * Does the player exist in memory
     *
     * @param pid the id of the player we're interested in
     * @return true if the player is in memory, or false
     */
    public boolean hasPlayer(int pid) {
        return players.containsKey(pid);
    }

    public int getID(String name) {
        Set<Integer> keys = players.keySet();
        for (Integer id : keys) {
            PlayerInfo playerInfo = players.get(id);
            if (playerInfo != null && playerInfo.nick().equals(name)) {
                return id;
            }
        }
        return -1;
    }

    public String getName(int id) {
        PlayerInfo info = players.get(id);
        if (info == null) {
            return "~Unknown~";
        }
        return info.nick();
    }

    public boolean hasChannel(int cid) {
        return channels.containsKey(cid);
    }

    /**
     * Gets the name of a player or "???" if the player couldn't be found
     *
     * @param playerId id of the player we're interested in
     * @return name of the player or "???" if not found
     */
    public String playerName(int playerId) {
        PlayerInfo player = players.get(playerId);

        if (player == null) {
            return "???";
        } else {
            return player.nick();
        }
    }

    public int playerAuth(int playerId) {
        PlayerInfo player = players.get(playerId);

        if (player == null) {
            return 0;
        } else {
            return player.auth;
        }
    }

    private void writeMessage(String s) {
        if (chatActivity != null && chatActivity.currentChannel() != null) {
            chatActivity.currentChannel().writeToHist("\n" + s, false, null);
            chatActivity.updateChat();
        } else if (joinedChannels.size() > 0) {
            for (Channel c : joinedChannels) {
                c.writeToHist("\n" + s, false, null);
            }
        }
    }

    private PlayerInfo getNonNullPlayer(int id) {
        PlayerInfo p = players.get(id);

        if (p == null) {
            p = new PlayerInfo();
            p.nick = "???";
            p.id = id;
        }

        return p;
    }

    public boolean channelNameTagger(String channelName) {
        for (Channel c : channels.values()) {
            if (c.name().toLowerCase().equals(channelName)) {
                return true;
            }
        }
        return false;
    }

    private void dealWithPM(int playerId, String message) {
        pmedPlayers.add(playerId);
        createPM(playerId);
        pms.newMessage(players.get(playerId), message);

        if (chatSettings.notificationsPM && !PrivateMessageActivity.onTop()) {
            showPMNotification(playerId);
            if (chatSettings.cry) {
                long time = System.currentTimeMillis();
                if (time - 10000 > chatSettings.lastCall) {
                    playPMCry(chatSettings.pokeNumber);
                    chatSettings.lastCall = time;
                }
            }
        }
        chatActivity.runOnUiThread(() -> chatActivity.invalidateOptionsMenu());
    }

    /**
     * Creates a PM window with the other guy
     *
     * @param playerId the other guy's id
     */
    public void createPM(int playerId) {
        if (players != null) {
            PlayerInfo info = players.get(playerId);
            if (info != null) {
                pms.createPM(info);
            }
        }
    }

    private void showPMNotification(int playerId) {
        PlayerInfo p = players.get(playerId);
        if (p == null) {
            p = new PlayerInfo();
        }

        NotificationCompat.Builder mBuilder = buildNotificationBuilder(R.drawable.ic_action_mail, "PM - Pokemon Online", "New message from " + p.nick())
//            new NotificationCompat.Builder(this, createNotificationChannel())
//                .setSmallIcon(R.drawable.ic_action_mail)
//                .setContentTitle("PM - Pokemon Online")
//                .setContentText("New message from " + p.nick())
                .setOngoing(true);

        // Creates an explicit intent for an Activity in your app
        Intent resultIntent = new Intent(this, PrivateMessageActivity.class);
        resultIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        resultIntent.putExtra("playerId", playerId);

        // The stack builder object will contain an artificial back stack for the
        // started Activity.
        // This ensures that navigating backward from the Activity leads out of
        // your application to the Home screen.
        TaskStackBuilder stackBuilder = TaskStackBuilder.create(this);
        // Adds the back stack for the Intent (but not the Intent itself)
        stackBuilder.addParentStack(ChatActivity.class);
        // Adds the Intent that starts the Activity to the top of the stack
        stackBuilder.addNextIntent(resultIntent);
        PendingIntent resultPendingIntent = stackBuilder.getPendingIntent(0, PendingIntent.FLAG_UPDATE_CURRENT);

        //PendingIntent resultPendingIntent = PendingIntent.getActivity(this, battleId, resultIntent, PendingIntent.FLAG_UPDATE_CURRENT);
        mBuilder.setContentIntent(resultPendingIntent);
        NotificationManager mNotificationManager = getNotificationManager();
        // mId allows you to update the notification later on.
        mNotificationManager.notify("pm", 0, mBuilder.build());
    }

    public void playPMCry(Integer pokemon) {
        AudioManager audioManager = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
        if (audioManager == null) {
            return;
        }
        int ringMode = audioManager.getRingerMode();

        /* Don't ring if in silent mode */
        if (ringMode == AudioManager.RINGER_MODE_NORMAL) {
            new Thread(new CryPlayer(pokemon)).start();
        } else if (ringMode == AudioManager.RINGER_MODE_VIBRATE) {
            Vibrator v = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
            // Vibrate for 700 milliseconds
            if (v != null) {
                v.vibrate(700);
            }
        }
    }

    private void showBattleNotification(String title, int battleId, BattleConf conf) {
        PlayerInfo p1 = getNonNullPlayer(conf.id(0));
        PlayerInfo p2 = getNonNullPlayer(conf.id(1));

        NotificationCompat.Builder mBuilder = buildNotificationBuilder(R.drawable.icon, title, p1.nick() + " vs " + p2.nick())
//            new NotificationCompat.Builder(this, createNotificationChannel())
//                .setSmallIcon(R.drawable.icon)
//                .setContentTitle(title)
//                .setContentText(p1.nick() + " vs " + p2.nick())
                .setOngoing(true);
        // Creates an explicit intent for an Activity in your app
        Intent resultIntent = new Intent(this, BattleActivity.class);
        resultIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        resultIntent.putExtra("battleId", battleId);

        // The stack builder object will contain an artificial back stack for the
        // started Activity.
        // This ensures that navigating backward from the Activity leads out of
        // your application to the Home screen.
        TaskStackBuilder stackBuilder = TaskStackBuilder.create(this);
        // Adds the back stack for the Intent (but not the Intent itself)
        stackBuilder.addParentStack(ChatActivity.class);
        // Adds the Intent that starts the Activity to the top of the stack
        stackBuilder.addNextIntent(resultIntent);
        PendingIntent resultPendingIntent =
                stackBuilder.getPendingIntent(
                        battleId,
                        PendingIntent.FLAG_UPDATE_CURRENT
                );

        //PendingIntent resultPendingIntent = PendingIntent.getActivity(this, battleId, resultIntent, PendingIntent.FLAG_UPDATE_CURRENT);
        mBuilder.setContentIntent(resultPendingIntent);
        NotificationManager mNotificationManager = getNotificationManager();
        // mId allows you to update the notification later on.
        mNotificationManager.notify("battle", battleId, mBuilder.build());
    }

    protected void addChannel(String chanName, int chanId) {
        Channel c = new Channel(chanId, chanName, this);
        channels.put(chanId, c);
        if (chatActivity != null) {
            chatActivity.addChannel(c);
        }
    }

    @SuppressLint({"ObsoleteSdkInt", "HardwareIds"})
    public String getUniqueId() {
        String msg;
        try {

            if (Build.VERSION.SDK_INT > Build.VERSION_CODES.FROYO) {
                String androidId;
                androidId = Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID);
                if (androidId != null) {
                    if (androidId.length() > 2) {
                        String serial;
                        try {
                            serial = Build.class.getField("SERIAL").get(null).toString();
                        } catch (Exception e) {
                            serial = "PokemonOnline";
                        }
                        androidId += ip;
                        serial += ip;
                        UUID android = new UUID(androidId.hashCode(), serial.hashCode());
                        msg = android.toString();
                    } else {
                        msg = getPseudoUniqueId();
                    }
                } else {
                    msg = getPseudoUniqueId();
                }
            } else {
                msg = getPseudoUniqueId();
            }
            if (msg == null || msg.length() < 2) {
                return "SomethingBadHappened";
            }
        } catch (Exception e) {
            return "SomethingBadHappened";
        }
        return msg;
    }

    private String getPseudoUniqueId() {
        try {
            String serial;
            try {
                serial = Build.class.getField("SERIAL").get(null).toString();
            } catch (Exception e) {
                serial = "PokemonOnline";
            }
            String pseudoId = "13" + (Build.BOARD.length() % 5) + (Build.BRAND.length() % 10) + (Build.DEVICE.length() % 10) + (Build.MANUFACTURER.length() % 10) + (Build.MODEL.length() % 10) + (Build.PRODUCT.length() % 10);
            pseudoId += ip;
            serial += ip;
            UUID pseudo = new UUID(pseudoId.hashCode(), serial.hashCode());
            String pseudoString = pseudo.toString();
            if (pseudoString.length() < 2) {
                return "SomethingBadHappened";
            }
            return pseudoString;
        } catch (Exception e) {
            return "SomethingBadHappened";
        }
    }

    @SuppressLint("ObsoleteSdkInt")
    public Boolean getUniqueIdFlag() {
        boolean flag;
        if (Build.VERSION.SDK_INT > Build.VERSION_CODES.FROYO) {
            @SuppressLint("HardwareIds") String androidId = Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID);
            flag = androidId != null;
        } else {
            flag = false;
        }
        return flag;
    }

    public void changeConnect(String newNick) {
        registered = false;
        Baos b = new Baos();
        b.putFlags(new boolean[]{true});
        b.putString(newNick);
        socket.sendMessage(b, Command.SendTeam);
    }

    public void changeTeam(String path) {
        Team team = new PokeParser(NetworkService.this, path, true).getTeam();
        Baos b = new Baos();
        b.putFlags(new boolean[]{true, meLoginPlayer.color().isValid(), true, true});
        b.putString(meLoginPlayer.nick());
        if (meLoginPlayer.color().isValid()) {
            b.putBaos(meLoginPlayer.color());
        }

        b.putBaos(meLoginPlayer.profile.trainerInfo);

        b.write(0);
        b.write(1);
        b.putBaos(team);

        socket.sendMessage(b, Command.SendTeam);
    }

    public ChatPrefs getSettings() {
        return chatSettings;
    }

    public void tryFlashChannel(Channel chan) {
        if (chan != joinedChannels.getFirst()) {
            chan.flashed = true;
            chatActivity.notifyChannelList();
            if (chatSettings.notificationsFlash) {
                chatActivity.makeToast("You were flashed in " + chan.name() + ".", "short");
            }
        }
    }

    public void joinChannel(String channelName) {
        int i = inChannelIndex(channelName);
        if (i == -1) {
            Baos join = new Baos();
            join.putString(channelName);
            if (socket.isConnected()) {
                socket.sendMessage(join, Command.JoinChannel);
            }
        } else {
            Channel c = joinedChannels.get(i);
            joinedChannels.remove(c);
            joinedChannels.addFirst(c);
            updateJoinedChannels();
        }
    }

    public int inChannelIndex(String name) {
        ListIterator<Channel> iterator = joinedChannels.listIterator();
        int i = 0;
        while (iterator.hasNext()) {
            Channel c = iterator.next();
            if (c.name().equalsIgnoreCase(name)) {
                return i;
            }
            i++;
        }
        return -1;
    }

    @TargetApi(Build.VERSION_CODES.HONEYCOMB)
    public void updateJoinedChannels() {
        if (chatActivity != null) {
            chatActivity.populateUI(true);
            if (chatActivity.progressDialog != null) {
                chatActivity.networkDismissDialog();
            }
        }

        SharedPreferences prefs = getSharedPreferences("autoJoinChannels", MODE_PRIVATE);
        SharedPreferences.Editor edit = prefs.edit();

        String key = ip + ":" + port;

        if (joinedChannels.size() == 1 && joinedChannels.getFirst().id == 0) {
            /* Only joined default channel! */
            edit.remove(key).remove(DEFAULT_KEY + key);
        } else {
            boolean hasDefault = false;
            HashSet<String> autoJoin = new HashSet<>();

            for (Channel chan : joinedChannels) {
                if (chan.id == 0) {
                    hasDefault = true;
                } else {
                    autoJoin.add(chan.name);
                }
            }

            if (hasDefault) {
                edit.remove(DEFAULT_KEY + key);
            } else {
                String firstChan = joinedChannels.getFirst().name;
                autoJoin.remove(firstChan);

                edit.putString(DEFAULT_KEY + key, firstChan);
            }

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB) {
                edit.putStringSet(key, autoJoin);
            }
        }
        edit.apply();
    }

    public void sendPass(String s, boolean isUserPass) {
        MessageDigest md5;
        if (isUserPass) {
            getSharedPreferences("passwords", MODE_PRIVATE).edit().putString(salt, s).apply();
            askedForPass = false;
            try {
                md5 = MessageDigest.getInstance("MD5");
                Baos hashPass = new Baos();
                hashPass.putBytes(md5.digest(mashBytes(toHex(md5.digest(s.getBytes("ISO-8859-1"))).getBytes("ISO-8859-1"), salt.getBytes("ISO-8859-1"))));
                socket.sendMessage(hashPass, Command.AskForPass);
            } catch (NoSuchAlgorithmException | UnsupportedEncodingException e) {
                e.printStackTrace();
            }
        } else {
            try {
                askedForServerPass = false;
                md5 = MessageDigest.getInstance("MD5");
                Baos hashPass = new Baos();
                hashPass.putBytes(md5.digest(mashBytes(md5.digest(s.getBytes("ISO-8859-1")), salty)));
                socket.sendMessage(hashPass, Command.ServerPassword);
                salty = null;
            } catch (NoSuchAlgorithmException | UnsupportedEncodingException e) {
                e.printStackTrace();
            }
        }
    }

    private byte[] mashBytes(byte[] a, byte[] b) {
        byte[] ret = new byte[a.length + b.length];
        System.arraycopy(a, 0, ret, 0, a.length);
        System.arraycopy(b, 0, ret, a.length, b.length);
        return ret;
    }

    private String toHex(byte[] b) {
        StringBuilder ret = new StringBuilder(new BigInteger(1, b).toString(16));
        while (ret.length() < 32) {
            ret.insert(0, "0");
        }
        return ret.toString();
    }

    public void playCry(SpectatingBattle battle, ShallowBattlePoke poke) {
        int ringMode = ((AudioManager) getSystemService(Context.AUDIO_SERVICE)).getRingerMode();

        /* Don't ring if in silent mode */
        if (ringMode == AudioManager.RINGER_MODE_NORMAL) {
            new Thread(new CryPlayer(poke, battle)).start();
        } else if (ringMode == AudioManager.RINGER_MODE_VIBRATE) {
            Vibrator v = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
            // Vibrate for 700 milliseconds
            v.vibrate(700);
        }

        /* In other cases, the cry's end will call notify on its own */
        if (ringMode != AudioManager.RINGER_MODE_NORMAL) {
            /* Can't notify right away, would be before the wait */
            new Thread(() -> {
                try {
                    Thread.sleep(ringMode == AudioManager.RINGER_MODE_VIBRATE ? 1000 : 100);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                synchronized (battle) {
                    battle.notify();
                }
            });
        }
    }

    /*
	public PlayerInfo getPlayerByName(String playerName) {
		Enumeration<Integer> e = players.keys();
		while(e.hasMoreElements()) {
			PlayerInfo info = players.get(e.nextElement());
			if (info.nick().equals(playerName))
				return info;
		}
		return null;
	}
	*/

    public void disconnect() {
        if (socket != null && socket.isConnected()) {
            halted = true;
            socket.close();
        }
        stopForeground(true);
        stopSelf();
    }

    public BattleDesc battle(Integer battleId) {
        return battles.get(battleId);
    }

    /**
     * Tells the server we're not spectating a battle anymore, and close the appropriate
     * spectating window
     *
     * @param bID the battle we're not watching anymore
     */
    public void stopWatching(int bID) {
        socket.sendMessage(new Baos().putInt(bID).putBool(false), Command.SpectateBattle);
        closeBattle(bID);
    }

    /**
     * Sends a private message to a user
     *
     * @param id      Id of the user dest
     * @param message message to send
     */
    public void sendPM(int id, String message) {
        Baos bb = new Baos();
        bb.putInt(id);
        bb.putString(message);
        socket.sendMessage(bb, Command.SendPM);

        pmedPlayers.add(id);
    }


    public void requestUserInfo(String name) {
        Baos b = new Baos();
        b.putString(name);
        socket.sendMessage(b, Command.GetUserInfo);
    }

    public void requestRanking(String tier, String name) {
        Baos b = new Baos();
        b.putString(tier);
        b.putBool(false);
        b.putString(name);
        socket.sendMessage(b, Command.ShowRankings);
    }

    public void requestRanking(String tier, int page) {
        Baos b = new Baos();
        b.putString(tier);
        b.putBool(true);
        b.putInt(page);
        socket.sendMessage(b, Command.ShowRankings);
    }

    public void playerKick(int id) {
        Baos b = new Baos();
        b.putInt(id);
        socket.sendMessage(b, Command.PlayerKick);
    }

    public void playerBan(int id) {
        Baos b = new Baos();
        b.putInt(id);
        socket.sendMessage(b, Command.PlayerBan);
    }

    public void playerTBan(int id, int time) {
        Baos b = new Baos();
        b.putInt(id);
        b.putInt(time);
        socket.sendMessage(b, Command.PlayerTBan);
    }

    public void playerBan(String name) {
        Baos b = new Baos();
        b.putString(name);
        socket.sendMessage(b, Command.CPBan);
    }

    public void playerTBan(String name, int time) {
        Baos b = new Baos();
        b.putString(name);
        b.putInt(time);
        socket.sendMessage(b, Command.CPBan);
    }

    public void playerUnban(String name) {
        Baos b = new Baos();
        b.putString(name);
        socket.sendMessage(b, Command.CPUnban);
    }

    public void poIgnore(String idOrName) {
        if (PokeStrings.isNumeric(idOrName)) {
            Integer id = AggrxNumbers.parseInt(idOrName, 0);
            ignoreList.add(id);
        } else {
            Integer id = getID(idOrName);
            ignoreList.add(id);
        }
    }

    public void poWatchPlayer(String idOrName) {
        int id;
        if (PokeStrings.isNumeric(idOrName)) {
            id = AggrxNumbers.parseInt(idOrName, 0);
        } else {
            id = getID(idOrName);
        }
        Set<Integer> keys = activeBattles.keySet();
        for (Integer battleID : keys) {
            Battle battle = activeBattle(battleID);
            if (battle.players[0].id == id || battle.players[1].id == id) {
                startWatching(battleID);
                break;
            }
        }
    }

    public void startWatching(int bID) {
        if (bID != 0) {
            Baos watch = new Baos();
            watch.putInt(bID);
            watch.putBool(true); // watch, not leaving
            socket.sendMessage(watch, Command.SpectateBattle);
        }
    }

    public void poPM(String idOrName) {
        int id;
        if (PokeStrings.isNumeric(idOrName)) {
            id = AggrxNumbers.parseInt(idOrName, 0);
        } else {
            id = getID(idOrName);
        }
        createPM(id);

        Intent intent = new Intent(chatActivity, PrivateMessageActivity.class);
        intent.putExtra("playerId", id);
        startActivity(intent);
    }

    public void loadJoinedChannelSettings() {
        SharedPreferences prefs = getSharedPreferences("autoJoinChannelsSettings", MODE_PRIVATE);

        String key = ip + ":" + port;

        Set<String> hasSettings = prefs.getStringSet(key, null);

        if (hasSettings != null) {
            for (Channel chan : joinedChannels) {
                if (hasSettings.contains(chan.name())) {
                    joinedChannels.get(joinedChannels.indexOf(chan)).channelEvents = true;
                }
            }
        }
    }

    public void updateJoinedChannelSettings() {
        SharedPreferences prefs = getSharedPreferences("autoJoinChannelsSettings", MODE_PRIVATE);
        SharedPreferences.Editor edit = prefs.edit();

        String key = ip + ":" + port;

        edit.remove(key);

        HashSet<String> settings = new HashSet<>();

        for (Channel chan : joinedChannels) {
            if (chan.channelEvents) {
                settings.add(chan.name());
            }
        }

        edit.putStringSet(key, settings).apply();
    }

    public String getDefaultPass() {
        return getSharedPreferences("passwords", MODE_PRIVATE).getString(salt, "");
    }

    public static class ChatPrefs {
        public boolean timeStamp = false;
        public boolean notificationsPM = true;
        // Chat
        boolean flashing = true;
        String color = "#FFFF00";
        boolean notificationsFlash = false;
        // PM
        boolean timeStampPM = true;
        boolean cry = false;
        int pokeNumber = 648;
        long lastCall = 0;
        int soundVolume = 10;
    }

    public class LocalBinder extends Binder {
        public NetworkService getService() {
            return NetworkService.this;
        }
    }

    class CryPlayer implements Runnable {
        final ShallowBattlePoke poke;
        final SpectatingBattle battle;

        public CryPlayer(ShallowBattlePoke poke, SpectatingBattle battle) {
            this.poke = poke;
            this.battle = battle;
        }

        public CryPlayer(int num) {
            poke = new ShallowBattlePoke();
            poke.uID.main = (short) num;
            battle = null;
        }

        @Override
        public void run() {
            int resID = getResources().getIdentifier("p" + poke.uID.main,
                    "raw", PKG_NAME);
            if (resID != 0) {
                MediaPlayer cryPlayer = MediaPlayer.create(NetworkService.this, resID);
                float logarithmicVolume = (float) (Math.log(100 - chatSettings.soundVolume) / 10);
                cryPlayer.setVolume(logarithmicVolume, logarithmicVolume);
                cryPlayer.setOnCompletionListener(mp -> {
                    synchronized (mp) {
                        mp.notify();
                    }
                });
                synchronized (cryPlayer) {
                    cryPlayer.start();
                    try {
                        cryPlayer.wait(5000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
                cryPlayer.release();
                if (battle != null) {
                    synchronized (battle) {
                        battle.notify();
                    }
                }
            }
        }
    }
}
