package com.podevs.android.pokeman.pokeinfo;


public class DamageClassInfo {
    public static String name(int num) {
        return damageClass.values()[num].toString();
    }

    public static int damageClassRes(int num) {
        return InfoConfig.context.getResources().getIdentifier("cat_" + num, "drawable", InfoConfig.PKG_NAME);
    }

    public enum damageClass {
        Other, //0
        Physical, //1
        Special, // 2
        Varies // 3
    }
}
