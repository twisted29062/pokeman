package com.podevs.android.pokeman.settings;

import android.os.Bundle;
import android.os.Environment;
import android.preference.CheckBoxPreference;
import android.preference.Preference;
import android.preference.PreferenceFragment;
import android.widget.Toast;

import com.aggrx.scaffold.AggrxNumbers;
import com.jx.scaffold.JxLogger;
import com.podevs.android.pokeman.MessageListAdapter;
import com.podevs.android.pokeman.R;
import com.podevs.android.pokeman.registry.CustomExceptionHandler;
import com.podevs.android.pokeman.registry.RegistryActivity;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Settings extends PreferenceFragment {
    private static final Pattern                               hex            = Pattern.compile("[#][A-F0-9]{6}");
    private static final String[]                              keys           = {"flashColor", "soundVolume", "shouldWrite", "pokemonNumber", "copyandpaste", "localize"};
    private final Preference.OnPreferenceChangeListener changeListener = (preference, newValue) -> {
        String key = preference.getKey();
        if ("flashColor".equals(key)) {
            return dealWithFlashColor(newValue.toString());
        }
        if ("pokemonNumber".equals(key)) {
            return dealWithPokemonNumber(newValue.toString());
        }
        if ("soundVolume".equals(key)) {
            return dealWithVolume(newValue.toString());
        }
        if ("shouldWrite".equals(key)) {
            CustomExceptionHandler.shouldWrite = (Boolean) newValue;
            if ((Boolean) newValue) {
                makeToast(Environment.getExternalStorageDirectory().getAbsolutePath());
            }
            return true;
        }
        if ("copyandpaste".equals(key)) {
            Boolean val = (Boolean) newValue;
            MessageListAdapter.copyandpaste = val;
            if (val) {
                CheckBoxPreference p = (CheckBoxPreference) findPreference("shouldTryTapMenu");
                if (p.isChecked()) {
                    p.setChecked(false);
                }
            }
        }
        if ("localize".equals(key)) {
            RegistryActivity.localize_assets = (Boolean) newValue;
        }
        return true;
    };

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        addPreferencesFromResource(R.xml.settings);
        setListeners();
    }

    private void setListeners() {
        for (String key : keys) {
            Preference p = findPreference(key);
            p.setOnPreferenceChangeListener(changeListener);
        }
    }

    private Boolean dealWithFlashColor(String color) {
        if (color.length() != 7) {
            makeToast("Enter a valid color Hex String" + "\n" + "Example: #00AF09");
        } else {
            Matcher m = hex.matcher(color);
            if (m.matches()) {
                makeToast(color);
                return true;
            }
        }
        makeToast("Enter a valid color Hex String" + "\n" + "Example: #00AF09");
        return false;
    }

    private void makeToast(String s) {
        if (getActivity() != null) {
            Toast.makeText(getActivity(), s, Toast.LENGTH_SHORT).show();
        } else {
            JxLogger.d("NULL ACTIVITY: Could not create toast");
        }
    }

    private Boolean dealWithPokemonNumber(String number) {
        try {
            int i = AggrxNumbers.parseInt(number,0);
            if (718 >= i && i > 0) {
                makeToast("Pokemon: " + number);
                return true;
            }
            return false;
        } catch (Exception e) {
            makeToast("Enter a valid pokemon number");
            return false;
        }
    }

    private Boolean dealWithVolume(String number) {
        try {
            int i = AggrxNumbers.parseInt(number,0);
            if (i <= 100 && i >= 0) {
                makeToast("Volume: " + number);
                return true;
            }
            return false;
        } catch (Exception e) {
            makeToast("Select a value between 0 and 100");
            return false;
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
    }
}
