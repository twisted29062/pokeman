package com.podevs.android.pokeman.teambuilder;

import android.app.AlertDialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.CheckBox;
import android.widget.ListView;

import androidx.fragment.app.Fragment;

import com.podevs.android.pokeman.R;
import com.podevs.android.pokeman.poke.TeamPoke;
import com.podevs.android.pokeman.pokeinfo.HiddenPowerInfo;
import com.podevs.android.pokeman.pokeinfo.MoveInfo;
import com.podevs.android.pokeman.pokeinfo.PokemonInfo;

import java.util.ArrayList;

public class MoveChooserFragment extends Fragment {
    public  MoveChooserListener  listener          = null;
    private ListView             moveList          = null;
    private MoveListAdapter      moveAdapter       = null;
    private ArrayAdapter<String> moveChoiceAdapter = null;
    private ArrayList<String>    names             = null;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.movelist, container, false);

        moveList = v.findViewById(R.id.moves);
        moveAdapter = new MoveListAdapter();
        moveAdapter.setPoke(poke());

        moveList.setAdapter(moveAdapter);

        AutoCompleteTextView moveChoice = v.findViewById(R.id.moveChoice);
        moveChoiceAdapter = new ArrayAdapter<>(getActivity(), android.R.layout.simple_dropdown_item_1line);
        updateNames();
        moveChoice.setAdapter(moveChoiceAdapter);

        moveChoice.setOnItemClickListener((arg0, arg1, arg2, arg3) -> moveList.setSelection(names.indexOf(moveChoiceAdapter.getItem(arg2))));

        moveList.setOnItemClickListener((arg0, arg1, arg2, arg3) -> {
            int move = (Short) moveAdapter.getItem(arg2);
            if (!poke().hasMove(move) && poke().addMove(move)) {
                ((CheckBox) arg1.findViewById(R.id.check)).setChecked(true);

                /* Hidden Power */
                if (move == 237) {
                    buildHiddenPowerDialog();
                } else if (move == 216) { /* return */
                    poke().happiness = (byte) 255;
                }

                if (listener != null) {
                    listener.onMovesetChanged(move == 216);
                }
            } else if (poke().removeMove(move)) {
                ((CheckBox) arg1.findViewById(R.id.check)).setChecked(false);

                /* Hidden Power */
                if (move == 237 && poke().gen().num < 7) {
                    for (int i = 0; i < 6; i++) {
                        poke().DVs[i] = 31;
                    }
                } else if (move == 216) { /* return */
                    poke().happiness = 0;
                }

                if (listener != null) {
                    listener.onMovesetChanged(move == 237 || move == 216);
                }
            }
        });

        moveList.setOnItemLongClickListener((parent, view, position, id) -> {
            int                 move    = (Short) moveAdapter.getItem(position);
            AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
            builder.setMessage(moveAdapter.moveInfo(move));
            builder.create().show();
            return false;
        });

        return v;
    }

    protected void buildHiddenPowerDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        builder.setTitle(R.string.hiddenpower_choice)
            .setSingleChoiceItems(R.array.hp_array, poke().hiddenPowerType() - 1, null)
            .setPositiveButton(R.string.ok, (dialog, which) -> {
                ListView lw   = ((AlertDialog) dialog).getListView();
                int      type = lw.getCheckedItemPosition() + 1;
                if (!poke().isHackmon && type == 1 && ((poke().uID().main >= 716 && poke().uID().main <= 721) || (poke().uID().main >= 785 && poke().uID().main <= 802))) {
                    poke().removeMove(237);

                    AlertDialog.Builder errorMsg = new AlertDialog.Builder(getActivity());
                    errorMsg.setTitle("Invalid hidden power type")
                        .setMessage(PokemonInfo.name(poke().uID) + " cannot have hidden power Fighting.")
                        .setPositiveButton("Okay", (dialog1, which1) -> {

                        });
                    errorMsg.create().show();
                } else if (poke().gen().num < 7) {
                    byte[] config;
                    if (!poke().isHackmon && (type == 2 || type == 3 || type == 5) && ((poke().uID().main >= 716 && poke().uID().main <= 721) || (poke().uID().main >= 785 && poke().uID().main <= 802))) {
                        config = HiddenPowerInfo.possibilitiesForType(type, poke().gen)[1];
                    } else {
                        config = HiddenPowerInfo.configurationForType(type, poke().gen);
                    }
                    if (config != null) {
                        poke().DVs = config;
                    }
                } else if (poke().validHiddenPowerType(type)) {
                    poke().hiddenPowerType = (byte) type;
                }

                if (listener != null) {
                    listener.onMovesetChanged(true);
                }
                moveAdapter.notifyDataSetChanged();
            });
        builder.create().show();
    }

    @Override
    public void onPause() {
        super.onPause();
    }

    public void updateNames() {
        if (poke().isHackmon) {
            names = MoveInfo.makeList(MoveInfo.getAllMoves());
        } else {
            names = MoveInfo.makeList(PokemonInfo.moves(poke().uID, poke().gen.num, poke().gen.subNum));
        }
        if (moveChoiceAdapter != null) {
            moveChoiceAdapter.clear();
            moveChoiceAdapter.addAll(names);
        }
    }

    private TeamPoke poke() {
        return ((EditPokemonActivity) getActivity()).getPoke();
    }

    public void updatePoke() {
        updateNames();
        moveAdapter.notifyDataSetChanged();
    }


    public interface MoveChooserListener {
        void onMovesetChanged(boolean stats);
    }
}
