package com.podevs.android.widgets;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.DialogFragment;
import android.app.SearchManager;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.DialogInterface;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.SearchView;

import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;

import com.podevs.android.pokeman.R;

public class FilterableChooser extends LinearLayout {
    public FilterableChooser(Context context) {
        super(context);
        initView();
    }

    public FilterableChooser(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        initView();
    }

    public FilterableChooser(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        initView();
    }

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    public FilterableChooser(Context context, AttributeSet attrs, int defStyleAttr, int defStyleRes) {
        super(context, attrs, defStyleAttr, defStyleRes);
        initView();
    }

    void initView() {

    }

    private FilterableArrayAdapter<?> adapter;

    public void setAdapter(FilterableArrayAdapter<?> adapter) {
        this.adapter = adapter;

        _searchableListDialog = FilterableChooserDialog.newInstance
                (adapter, position -> {
                    setSelection(position);

                    if (itemClicked!=null){
                        itemClicked.onItemClicked(position);
                    }
                });
    }

    ItemClicked itemClicked;

    public void setItemClicked(ItemClicked itemClicked) {
        this.itemClicked = itemClicked;
    }

    public void setSelection(int index) {
        if (adapter == null) {
            return;
        }
        View view = null;
        if (this.getChildCount() > 0) {
            view = this.getChildAt(0);
        }
        if (view!=null) {
            ViewGroup parent = (ViewGroup) view.getParent();
            if (parent != null) {
                parent.removeView(view);
            }
        }
        view = adapter.getView(index, view, this);

        addView(view);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        if (event.getAction() == MotionEvent.ACTION_UP) {
            if (_searchableListDialog.isAdded()) {
                return true;
            }
            _searchableListDialog.show(scanForActivity(getContext()).getFragmentManager(), "TAG");

        }
        return true;//return super.onTouchEvent(event);
    }

    private FilterableChooserDialog _searchableListDialog;

    @Override
    public boolean performClick() {

        return super.performClick();
    }

    private Activity scanForActivity(Context cont) {
        if (cont == null)
            return null;
        else if (cont instanceof Activity)
            return (Activity) cont;
        else if (cont instanceof ContextWrapper)
            return scanForActivity(((ContextWrapper) cont).getBaseContext());

        return null;
    }

    public interface ItemClicked {
        void onItemClicked(int position);
    }

    public static class FilterableChooserDialog extends DialogFragment implements
            SearchView.OnQueryTextListener, SearchView.OnCloseListener {

        public static FilterableChooserDialog newInstance(FilterableArrayAdapter adapter, FilterableChooser.ItemClicked itemClicked) {
            FilterableChooserDialog chooserDialog = new
                    FilterableChooserDialog();
            chooserDialog._filterableArrayAdapter = adapter;
            chooserDialog._itemClicked = itemClicked;

            //Bundle args = new Bundle();
            //args.putSerializable(ITEMS, (Serializable) items);

            //chooserDialog.setArguments(args);
            return chooserDialog;
        }


        private ListView _listViewItems;
        private SearchView _searchView;

        FilterableArrayAdapter _filterableArrayAdapter;

        @Override
        public void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);

        }

        @Override
        public View onCreateView(LayoutInflater inflater, ViewGroup container,
                                 Bundle savedInstanceState) {
            getDialog().getWindow().setSoftInputMode(WindowManager.LayoutParams
                    .SOFT_INPUT_STATE_HIDDEN);
            return super.onCreateView(inflater, container, savedInstanceState);
        }

        private String _strTitle;
        private String _strPositiveButtonText;
        private DialogInterface.OnClickListener _onClickListener;

        @Override
        public Dialog onCreateDialog(Bundle savedInstanceState) {

            // Getting the layout inflater to inflate the view in an alert dialog.
            LayoutInflater inflater = LayoutInflater.from(getActivity());

            // Crash on orientation change #7
            // Change Start
            // Description: As the instance was re initializing to null on rotating the device,
            // getting the instance from the saved instance
//            if (null != savedInstanceState) {
//                // _searchableItem = (SearchableListDialog.SearchableItem) savedInstanceState.getSerializable("item");
//            }
            // Change End

            View rootView = inflater.inflate(R.layout.filterable_chooser_dialog, null);
            setData(rootView);

            AlertDialog.Builder alertDialog = new AlertDialog.Builder(getActivity());
            alertDialog.setView(rootView);

            String strPositiveButton = _strPositiveButtonText == null ? "CLOSE" : _strPositiveButtonText;
            alertDialog.setPositiveButton(strPositiveButton, _onClickListener);

            String strTitle = _strTitle == null ? "Select Item" : _strTitle;
            alertDialog.setTitle(strTitle);

            final AlertDialog dialog = alertDialog.create();
            dialog.getWindow().setSoftInputMode(WindowManager.LayoutParams
                    .SOFT_INPUT_STATE_HIDDEN);
            return dialog;
        }

        private void setData(View rootView) {
            SearchManager searchManager = (SearchManager) getActivity().getSystemService(Context
                    .SEARCH_SERVICE);

            _searchView = (SearchView) rootView.findViewById(com.toptoche.searchablespinnerlibrary.R.id.search);
            _searchView.setSearchableInfo(searchManager.getSearchableInfo(getActivity().getComponentName
                    ()));
            _searchView.setIconifiedByDefault(false);
            _searchView.setOnQueryTextListener(this);
            _searchView.setOnCloseListener(this);
            _searchView.clearFocus();
            InputMethodManager mgr = (InputMethodManager) getActivity().getSystemService(Context
                    .INPUT_METHOD_SERVICE);
            mgr.hideSoftInputFromWindow(_searchView.getWindowToken(), 0);


            //List items = (List) getArguments().getSerializable(ITEMS);
            _listViewItems = rootView.findViewById(R.id.listItems);

            //create the adapter by passing your ArrayList data
            //listAdapter = new ArrayAdapter(getActivity(), android.R.layout.simple_list_item_1,  items);
            //attach the adapter to the list
            ArrayAdapter adapter = _filterableArrayAdapter.filterResult("");

            _listViewItems.setAdapter(adapter);

            _listViewItems.setTextFilterEnabled(true);

            _listViewItems.setOnItemClickListener((parent, view, position, id) -> {
                Object item = adapter.getItem(position);
                int positionInAll = _filterableArrayAdapter.getPosition(item);
                // _searchableItem.onSearchableItemClicked(listAdapter.getItem(position), position);
                if (_itemClicked != null) {
                    _itemClicked.onItemClicked(positionInAll);
                }
                getDialog().dismiss();
            });
        }

        FilterableChooser.ItemClicked _itemClicked;

        public void setTitle(String strTitle) {
            _strTitle = strTitle;
        }

        public void setPositiveButton(String strPositiveButtonText) {
            _strPositiveButtonText = strPositiveButtonText;
        }

        public void setPositiveButton(String strPositiveButtonText, DialogInterface.OnClickListener onClickListener) {
            _strPositiveButtonText = strPositiveButtonText;
            _onClickListener = onClickListener;
        }

        /// SearchView.OnQueryTextListener, SearchView.OnCloseListener
        @Override
        public boolean onClose() {
            return false;
        }

        @Override
        public boolean onQueryTextSubmit(String s) {
            _searchView.clearFocus();
            return true;
        }

        @Override
        public boolean onQueryTextChange(String s) {
            ArrayAdapter adapter;
            if (TextUtils.isEmpty(s)) {
                  adapter = _filterableArrayAdapter.filterResult("");
            } else {
                  adapter = _filterableArrayAdapter.filterResult(s);
            }
            _listViewItems.setAdapter(adapter);
            _listViewItems.setOnItemClickListener((parent, view, position, id) -> {
                Object item = adapter.getItem(position);
                int positionInAll = _filterableArrayAdapter.getPosition(item);
                // _searchableItem.onSearchableItemClicked(listAdapter.getItem(position), position);
                if (_itemClicked != null) {
                    _itemClicked.onItemClicked(positionInAll);
                }
                getDialog().dismiss();
            });
            return false;
        }
    }
}
