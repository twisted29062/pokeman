package com.podevs.android.pokeman.poke;

import android.text.TextUtils;

import com.aggrx.scaffold.AggrxNumbers;
import com.podevs.android.utilities.Bais;
import com.podevs.android.utilities.Baos;
import com.podevs.android.utilities.SerializeBytes;

/**
 * Implementation of pokemon dex number into a readable form for coding
 * 格式:889:1:A
 */

public class UniqueID implements SerializeBytes {

    /**
     * The international dex number
     */

    public short main = 0;

    /**
     * The forme number
     */

    public byte sub = 0;

    /*
     * 其他部分
     */
    private String other = "";

    /**
     * Constructor from Bais
     *
     * @param msg Bais information
     * @see Bais
     */

    public UniqueID(Bais msg) {
        main = msg.readShort();
        sub = msg.readByte();
    }

    /**
     * Constructor from two int
     *
     * @param s pokeNum
     * @param b subNum
     */

    public UniqueID(int s, int b) {
        main = (short) s;
        sub = (byte) b;
    }

    /**
     * Blank Constructor. num = 0 sub = 0
     */
    public UniqueID() {
        main = 0;
        sub = 0;
    }

    /**
     * Constructor from string. Most likely from asset files
     *
     * @param str String of pokemon number. Example - "3:1" Mega Venasaur
     */

    public UniqueID(String str) {
        // main:sub:x
        if (TextUtils.isEmpty(str)) {
            return;
        }
        String[] parts = str.split(":");
        if (parts.length == 0) {
            return;
        }
        if (parts.length == 1) {
            main = (short) AggrxNumbers.parseInt(parts[0], 0);
        } else {
            main = (short) AggrxNumbers.parseInt(parts[0], 0);
            sub = (byte) AggrxNumbers.parseInt(parts[1], 0);
            if (parts.length > 2) {
                other = parts[2];
            }
        }
//        int colon = str.indexOf(':');
//        mainNum = (short) AggrxNumbers.parseInt(str.substring(0, colon));
//        try {
//            subNum = (byte) AggrxNumbers.parseInt(str.substring(colon + 1));
//        } catch (NumberFormatException e) {
//            subNum = 0;
//        }
    }

    /**
     * Constructor from int. pokeNum = i modulo 65536. subNum = i right shift 16 bytes
     *
     * @param i int
     */

    public UniqueID(int i) {
        main = (short) (i % (1 << 16));
        sub = (byte) (i >> 16);
    }

    /**
     * Get hash code
     *
     * @return pokeNum + subNum shifted left 16 bytes
     */

    @Override
    public int hashCode() {
        return hashCode(main, sub);//int) pokeNum + subNum * 65536;
    }

    public String hashCodeString() {
        return main + ":" + sub;
    }

    public String id() {
        if (sub == 0) {
            return main + "";
        } else {
            return main + ":" + sub;
        }

//        if (TextUtils.isEmpty(other))
//            return mainNum + ":" + subNum;
//        else
//            return mainNum + ":" + subNum + ":" + other;
    }


    /**
     * Overrides equals() method
     *
     * @param other Object to compare
     * @return returns true if other equals this UniqueID
     */

    @Override
    public boolean equals(Object other) {
        try {
            UniqueID o = (UniqueID) other;
            return main == o.main && sub == o.sub;
        } catch (ClassCastException e) {
            return false;
        }
    }

    /**
     * @return pokeNum + (subNum == 0 ? "" : "_" + subNum);
     */
    @Override
    public String toString() {
        return "" + this.main + (this.sub == 0 ? "" : "_" + this.sub);
    }

    /**
     * @return pokeNum
     */

    public int originalHashCode() {
        return (int) main;
    }

    public String originalHashCodeString() {
        return main + "";
    }

    /**
     * Unused.
     *
     * @param mainNum pokNum
     * @param subNum  subNum
     * @return mainNum + subNum shifted left 16 bytes
     */

    public int hashCode(int mainNum, int subNum) {
        // main:sub
        return mainNum + subNum * 65536;
    }

    /**
     * Writes Unique ID to Baos
     *
     * @param bytes
     * @see com.podevs.android.utilities.Baos
     */

    @Override
    public void serializeBytes(Baos bytes) {
        bytes.putShort(main);
        bytes.write(sub);
    }

    /**
     * @return new UniqueID with same pokeNum but 0 subNum
     */

    public UniqueID original() {
        return new UniqueID(main);
    }
}
