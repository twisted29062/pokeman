package com.podevs.android.pokeman.battle;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.pm.PackageManager.NameNotFoundException;
import android.content.res.Resources;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.SystemClock;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnLongClickListener;
import android.view.View.OnTouchListener;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.content.res.AppCompatResources;
import androidx.viewpager.widget.PagerAdapter;
import androidx.viewpager.widget.ViewPager;

import com.jx.scaffold.JxLogger;
import com.android.launcher.DragController;
import com.android.launcher.DragLayer;
import com.android.launcher.PokeDragIcon;
import com.podevs.android.pokeman.Command;
import com.podevs.android.pokeman.NetworkService;
import com.podevs.android.pokeman.R;
import com.podevs.android.pokeman.TextProgressBar;
import com.podevs.android.pokeman.app.BaseActivity;
import com.podevs.android.pokeman.chat.ChatActivity;
import com.podevs.android.pokeman.poke.PokeEnums.Status;
import com.podevs.android.pokeman.poke.ShallowBattlePoke;
import com.podevs.android.pokeman.poke.ShallowShownPoke;
import com.podevs.android.pokeman.poke.UniqueID;
import com.podevs.android.pokeman.pokeinfo.GenderInfo;
import com.podevs.android.pokeman.pokeinfo.InfoConfig;
import com.podevs.android.pokeman.pokeinfo.ItemInfo;
import com.podevs.android.pokeman.pokeinfo.MoveInfo;
import com.podevs.android.pokeman.pokeinfo.PokemonInfo;
import com.podevs.android.pokeman.pokeinfo.TypeInfo;
import com.podevs.android.utilities.Baos;

import java.io.IOException;
import java.io.InputStream;

import pl.droidsonroids.gif.GifDrawable;


@SuppressLint("DefaultLocale")
public class BattleActivity extends BaseActivity implements MyResultReceiver.Receiver {

    // public final static int SWIPE_TIME_THRESHOLD = 100;
    // private static final String         TAG          = "Battle";
    private static final ComponentName servName = new ComponentName("com.podevs.android.pokemonresources", "com.podevs.android.pokemonresources.SpriteService");
    public Battle activeBattle = null;
    public NetworkService netServ = null;
    public final HpAnimator hpAnimator = new HpAnimator();
    public final boolean[] samePokes = new boolean[2];
    DragLayer mDragLayer;
    ViewPager realViewSwitcher;
    RelativeLayout battleView;
    final TextProgressBar[][] hpBars = new TextProgressBar[2][3];
    final TextView[][] currentPokeNames = new TextView[2][3];
    final TextView[][] currentPokeLevels = new TextView[2][3];
    final ImageView[][] currentPokeGenders = new ImageView[2][3];
    final ImageView[][] currentPokeStatuses = new ImageView[2][3];
    final TextView[] attackNames = new TextView[4];
    final TextView[] attackPPs = new TextView[4];
    final RelativeLayout[] attackLayouts = new RelativeLayout[4];
    final ImageView[][] targetIcons = new ImageView[2][3];
    final TextView[][] targetNames = new TextView[2][3];
    final RelativeLayout[][] targetLayouts = new RelativeLayout[2][3];
    final TextView[] timers = new TextView[2];
    final PokeDragIcon[] myArrangePokeIcons = new PokeDragIcon[6];
    final ImageView[] oppArrangePokeIcons = new ImageView[6];
    final ListedPokemon[] pokeList = new ListedPokemon[6];
    TextView infoView;
    ScrollView infoScroll;
    final TextView[] names = new TextView[2];
    final ImageView[][] pokeballs = new ImageView[2][6];
    final pl.droidsonroids.gif.GifImageView[][] pokeSprites = new pl.droidsonroids.gif.GifImageView[2][3];
    RelativeLayout struggleLayout;
    LinearLayout attackRow1;
    LinearLayout attackRow2;
    LinearLayout targetRow1;
    LinearLayout targetRow2;
    SpectatingBattle battle = null;
    boolean useAnimSprites = true;
    boolean megaClicked = false;
    boolean burstClicked = false;
    boolean zmoveClicked = false;
    BattleMove lastClickedMove;
    int currentChoiceSlot = 0;
    final BattleChoice[] myChoices = new BattleChoice[3];
    boolean isSelectingTarget = false;
    Resources resources;
    public final OnLongClickListener moveListener = new OnLongClickListener() {
        @Override
        public boolean onLongClick(View v) {
            int id = v.getId();
            for (int i = 0; i < 4; i++) {
                if (id == attackLayouts[i].getId() && !"No Move".equals(attackNames[i])) {
                    lastClickedMove = activeBattle.myTeam.pokes[currentChoiceSlot].moves[i];
                    if (zmoveClicked) {
                        setAttackButtonEnabled(i, activeBattle.allowZMoves[currentChoiceSlot][i]);
                        if (lastClickedMove.power > 0 && activeBattle.allowZMoves[currentChoiceSlot][i]) {
                            lastClickedMove.power = MoveInfo.zPower(lastClickedMove.num());
                            lastClickedMove.accuracy = 101;
                            if (lastClickedMove.num == 237) { //Hidden Power
                                lastClickedMove.type = 0;
                            }
                            lastClickedMove.num = ItemInfo.zCrystalMove(activeBattle.myTeam.pokes[currentChoiceSlot].item);
                        }
                    }
                    showDialog(BattleDialog.MoveInfo.ordinal());
                    return true;
                }
            }
            return false;
        }
    };
    int me, opp;

    public final OnClickListener battleListener = new OnClickListener() {
        @Override
        public void onClick(View v) {
            int id = v.getId();
            // Check to see if click was on attack button
            for (int i = 0; i < 4; i++) {
                if (id == attackLayouts[i].getId()) {
                    attackClicked((byte) i);
                    if (zmoveClicked) {
                        zmoveClicked = false;
                        updateButtons();
                    }
                }
            }
            // Check to see if click was on pokelist button
            for (int i = 0; i < 6; i++) {
                if (id == pokeList[i].whole.getId()) {
                    BattleChoice.SwitchChoice sc = new BattleChoice.SwitchChoice((byte) i);
                    myChoices[currentChoiceSlot] = new BattleChoice((byte) battle.slot(me, currentChoiceSlot), sc, BattleChoice.ChoiceType.SwitchType);
                    realViewSwitcher.setCurrentItem(0, true);
                    zmoveClicked = false;
                    goToNextChoice();
                }
            }
            // Check to see if click was on target button
            for (int i = 0; i < 2; i++) {
                for (int j = 0; j < 3; j++) {
                    if (id == targetLayouts[i][j].getId()) {
                        targetClicked((byte) battle.slot(i, j));
                    }
                }
            }

            updateButtons();
        }
    };
    public final OnLongClickListener spriteListener = new OnLongClickListener() {
        @Override
        public boolean onLongClick(View v) {
            if (v == null) {
                return false;
            }

            pl.droidsonroids.gif.GifImageView[] mySprites = pokeSprites[me];
            if (mySprites == null) {
                return false;
            }

            if (isSampleSpriteWebView(v, mySprites[0])
                    || isSampleSpriteWebView(v, mySprites[1])
                    || isSampleSpriteWebView(v, mySprites[2])
                /*v.getId() == mySprites[0].getId() || v.getId() == mySprites[1].getId() || v.getId() == mySprites[2].getId()*/) {
                showDialog(BattleDialog.MyDynamicInfo.ordinal());
            } else {
                showDialog(BattleDialog.OppDynamicInfo.ordinal());
            }
            return true;
        }
    };
    View mainLayout, teamLayout;
    boolean connected = false;
    private MyResultReceiver mRecvr;
    private final Handler handler = new Handler();
    private final Runnable updateTimeTask = new Runnable() {
        @Override
        public void run() {
            for (int i = 0; i < 2; i++) {
                int seconds;
                if (battle.ticking[i]) {
                    long millis = SystemClock.uptimeMillis() - battle.startingTime[i];
                    seconds = battle.remainingTime[i] - (int) (millis / 1000);
                } else {
                    seconds = battle.remainingTime[i];
                }

                if (seconds < 0) {
                    seconds = 0;
                } else if (seconds > 300) {
                    seconds = 300;
                }

                int minutes = (seconds / 60);
                seconds = seconds % 60;
                timers[i].setText(String.format("%02d:%02d", minutes, seconds));
            }
            handler.postDelayed(this, 200);
        }
    };
    public final ServiceConnection connection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName className, IBinder service) {
            netServ = ((NetworkService.LocalBinder) service).getService();
            connected = true;

            int battleId = getIntent().getIntExtra("battleId", 0);
            battle = netServ.activeBattles.get(battleId);
            if (battle == null) {
                battle = netServ.spectatedBattles.get(battleId);
            }
            JxLogger.e("Binding at State Time: " + (System.currentTimeMillis() - battle.startTime));

            if (battle == null) {
                startActivity(new Intent(BattleActivity.this, ChatActivity.class));
                finish();

                netServ.closeBattle(battleId); //remove the possibly ongoing notification
                return;
            }

            /* Is it a spectating battle or not? */
            try {
                activeBattle = (Battle) battle;
            } catch (ClassCastException ex) {
                ex.printStackTrace();
            }

            if (isSpectating()) {
                /* If it's a spectating battle, we remove the info view's bottom margin */
                RelativeLayout.LayoutParams params = (RelativeLayout.LayoutParams) infoScroll.getLayoutParams();
                params.setMargins(params.leftMargin, params.topMargin, params.rightMargin,
                        ((RelativeLayout.LayoutParams) attackRow2.getLayoutParams()).bottomMargin);
                infoScroll.setLayoutParams(params);
            } else {
                teamLayout = getLayoutInflater().inflate(R.layout.battle_teamscreen, null);

                for (int i = 0; i < 4; i++) {
                    attackNames[i] = mainLayout.findViewById(resources.getIdentifier("attack" + (i + 1) + "Name", "id", InfoConfig.PKG_NAME));
                    attackPPs[i] = mainLayout.findViewById(resources.getIdentifier("attack" + (i + 1) + "PP", "id", InfoConfig.PKG_NAME));
                    attackLayouts[i] = mainLayout.findViewById(resources.getIdentifier("attack" + (i + 1) + "Layout", "id", InfoConfig.PKG_NAME));
                    attackLayouts[i].setOnClickListener(battleListener);
                    attackLayouts[i].setOnLongClickListener(moveListener);
                }
                for (int i = 0; i < 6; i++) {
                    ViewGroup whole = teamLayout.findViewById(resources.getIdentifier("pokeViewLayout" + (i + 1), "id", InfoConfig.PKG_NAME));
                    pokeList[i] = new ListedPokemon(whole);
                    whole.setOnClickListener(battleListener);
                    whole.setOnLongClickListener(v -> {
                        int id = v.getId();
                        for (int i1 = 0; i1 < 6; i1++) {
                            if (id == pokeList[i1].whole.getId()) {
                                BattlePoke poke = activeBattle.myTeam.pokes[i1];
                                Dialog simpleDialog = new Dialog(BattleActivity.this);
                                simpleDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
                                simpleDialog.setContentView(R.layout.dynamic_info_layout);

                                TextView t = simpleDialog.findViewById(R.id.nameTypeView);
                                t.setText(poke.nameAndType());
                                t = simpleDialog.findViewById(R.id.statNamesView);
                                t.setText(battle.dynamicInfo[me].stats());
                                t = simpleDialog.findViewById(R.id.statNumsView);
                                t.setText(poke.printStats());

                                simpleDialog.setCanceledOnTouchOutside(true);
                                simpleDialog.setOnCancelListener(dialog -> simpleDialog.dismiss());
                                simpleDialog.findViewById(R.id.dynamic_info_layout).setOnClickListener(v1 -> simpleDialog.dismiss());
                                simpleDialog.show();
                            }
                        }
                        return true;
                    });
                }

                /* Well it helps you keep track what your opponent has seen!
				// Pre-load PokeBall and sprite info
				for (int i = 0; i < 6; i++) {
					battle.pokes[battle.me][i].uID = activeBattle.myTeam.pokes[i].uID;
				}
				*/

                /* Changed to two pages */
                realViewSwitcher.getAdapter().notifyDataSetChanged();
            }

            battleView.setBackgroundResource(resources.getIdentifier("bg" + battle.background, "drawable", InfoConfig.PKG_NAME));

            // Set the UI to display the correct info
            me = battle.me;
            opp = battle.opp;
            // We don't know which timer is which until the battle starts,
            // so set them here.
            timers[me] = mainLayout.findViewById(R.id.timerB);
            timers[opp] = mainLayout.findViewById(R.id.timerA);

            names[me] = mainLayout.findViewById(R.id.nameB);
            names[opp] = mainLayout.findViewById(R.id.nameA);

            for (int i = 0; i < 6; i++) {
                pokeballs[me][i] = mainLayout.findViewById(resources.getIdentifier("poke_ball_" + (i + 1) + "B", "id", InfoConfig.PKG_NAME));
                pokeballs[opp][i] = mainLayout.findViewById(resources.getIdentifier("poke_ball_" + (i + 1) + "A", "id", InfoConfig.PKG_NAME));
            }
            updatePokeBalls();

            names[me].setText(battle.players[me].nick());
            names[opp].setText(battle.players[opp].nick());

            hpBars[me][0] = battleView.findViewById(R.id.hpBarB1);
            hpBars[me][1] = battleView.findViewById(R.id.hpBarB2);
            hpBars[me][2] = battleView.findViewById(R.id.hpBarB3);

            hpBars[opp][0] = battleView.findViewById(R.id.hpBarA1);
            hpBars[opp][1] = battleView.findViewById(R.id.hpBarA2);
            hpBars[opp][2] = battleView.findViewById(R.id.hpBarA3);

            currentPokeNames[me][0] = battleView.findViewById(R.id.currentPokeNameB1);
            currentPokeNames[opp][0] = battleView.findViewById(R.id.currentPokeNameA1);
            currentPokeNames[me][1] = battleView.findViewById(R.id.currentPokeNameB2);
            currentPokeNames[opp][1] = battleView.findViewById(R.id.currentPokeNameA2);
            currentPokeNames[me][2] = battleView.findViewById(R.id.currentPokeNameB3);
            currentPokeNames[opp][2] = battleView.findViewById(R.id.currentPokeNameA3);

            currentPokeLevels[me][0] = battleView.findViewById(R.id.currentPokeLevelB1);
            currentPokeLevels[opp][0] = battleView.findViewById(R.id.currentPokeLevelA1);
            currentPokeLevels[me][1] = battleView.findViewById(R.id.currentPokeLevelB2);
            currentPokeLevels[opp][1] = battleView.findViewById(R.id.currentPokeLevelA2);
            currentPokeLevels[me][2] = battleView.findViewById(R.id.currentPokeLevelB3);
            currentPokeLevels[opp][2] = battleView.findViewById(R.id.currentPokeLevelA3);

            currentPokeGenders[me][0] = battleView.findViewById(R.id.currentPokeGenderB1);
            currentPokeGenders[opp][0] = battleView.findViewById(R.id.currentPokeGenderA1);
            currentPokeGenders[me][1] = battleView.findViewById(R.id.currentPokeGenderB2);
            currentPokeGenders[opp][1] = battleView.findViewById(R.id.currentPokeGenderA2);
            currentPokeGenders[me][2] = battleView.findViewById(R.id.currentPokeGenderB3);
            currentPokeGenders[opp][2] = battleView.findViewById(R.id.currentPokeGenderA3);

            currentPokeStatuses[me][0] = battleView.findViewById(R.id.currentPokeStatusB1);
            currentPokeStatuses[opp][0] = battleView.findViewById(R.id.currentPokeStatusA1);
            currentPokeStatuses[me][1] = battleView.findViewById(R.id.currentPokeStatusB2);
            currentPokeStatuses[opp][1] = battleView.findViewById(R.id.currentPokeStatusA2);
            currentPokeStatuses[me][2] = battleView.findViewById(R.id.currentPokeStatusB3);
            currentPokeStatuses[opp][2] = battleView.findViewById(R.id.currentPokeStatusA3);

            if (battle.numberOfSlots == 1) {
                battleView.findViewById(R.id.pokeInfoA2).setVisibility(View.GONE);
                battleView.findViewById(R.id.pokeInfoB2).setVisibility(View.GONE);
                battleView.findViewById(R.id.pokeInfoA3).setVisibility(View.GONE);
                battleView.findViewById(R.id.pokeInfoB3).setVisibility(View.GONE);
                ((RelativeLayout.LayoutParams) battleView.findViewById(R.id.pokeInfoB1).getLayoutParams()).addRule(RelativeLayout.ALIGN_PARENT_BOTTOM);
            } else if (battle.numberOfSlots == 2) {
                battleView.findViewById(R.id.pokeInfoA3).setVisibility(View.GONE);
                battleView.findViewById(R.id.pokeInfoB3).setVisibility(View.GONE);
                ((RelativeLayout.LayoutParams) battleView.findViewById(R.id.pokeInfoB2).getLayoutParams()).addRule(RelativeLayout.ALIGN_PARENT_BOTTOM);
            }

            for (int i = 0; i < 3; i++) {
                targetIcons[me][i] = mainLayout.findViewById(resources.getIdentifier("targetB" + (i + 1) + "Icon", "id", InfoConfig.PKG_NAME));
                targetIcons[me][i].setImageDrawable(PokemonInfo.iconDrawable(new UniqueID(0)));
                targetNames[me][i] = mainLayout.findViewById(resources.getIdentifier("targetB" + (i + 1) + "Name", "id", InfoConfig.PKG_NAME));
                targetLayouts[me][i] = mainLayout.findViewById(resources.getIdentifier("targetB" + (i + 1) + "Layout", "id", InfoConfig.PKG_NAME));
                targetLayouts[me][i].setOnClickListener(battleListener);
                targetIcons[opp][i] = mainLayout.findViewById(resources.getIdentifier("targetA" + (i + 1) + "Icon", "id", InfoConfig.PKG_NAME));
                targetIcons[opp][i].setImageDrawable(PokemonInfo.iconDrawable(new UniqueID(0)));
                targetNames[opp][i] = mainLayout.findViewById(resources.getIdentifier("targetA" + (i + 1) + "Name", "id", InfoConfig.PKG_NAME));
                targetLayouts[opp][i] = mainLayout.findViewById(resources.getIdentifier("targetA" + (i + 1) + "Layout", "id", InfoConfig.PKG_NAME));
                targetLayouts[opp][i].setOnClickListener(battleListener);
            }

            for (int i = 0; i < battle.numberOfSlots; i++) {
                targetLayouts[me][i].setVisibility(View.VISIBLE);
                targetLayouts[opp][i].setVisibility(View.VISIBLE);
            }

            if (battle.numberOfSlots == 1) {
                pokeSprites[me][0] = battleView.findViewById(R.id.pokeSpriteB2);
                pokeSprites[opp][0] = battleView.findViewById(R.id.pokeSpriteA2);
                battleView.findViewById(R.id.pokeSpriteA1).setVisibility(View.GONE);
                battleView.findViewById(R.id.pokeSpriteB1).setVisibility(View.GONE);
                battleView.findViewById(R.id.pokeSpriteA3).setVisibility(View.GONE);
                battleView.findViewById(R.id.pokeSpriteB3).setVisibility(View.GONE);
            } else if (battle.numberOfSlots == 2) {
                pokeSprites[me][0] = battleView.findViewById(R.id.pokeSpriteB2);
                pokeSprites[opp][0] = battleView.findViewById(R.id.pokeSpriteA1);
                pokeSprites[me][1] = battleView.findViewById(R.id.pokeSpriteB3);
                pokeSprites[opp][1] = battleView.findViewById(R.id.pokeSpriteA2);
                battleView.findViewById(R.id.pokeSpriteA3).setVisibility(View.GONE);
                battleView.findViewById(R.id.pokeSpriteB1).setVisibility(View.GONE);
                ((ViewGroup.MarginLayoutParams) pokeSprites[me][0].getLayoutParams()).setMargins(0, 0, 0, 0);
                ((ViewGroup.MarginLayoutParams) pokeSprites[opp][1].getLayoutParams()).setMargins(0, 0, 0, 0);
            } else if (battle.numberOfSlots == 3) {
                pokeSprites[me][0] = battleView.findViewById(R.id.pokeSpriteB1);
                pokeSprites[opp][0] = battleView.findViewById(R.id.pokeSpriteA1);
                pokeSprites[me][1] = battleView.findViewById(R.id.pokeSpriteB2);
                pokeSprites[opp][1] = battleView.findViewById(R.id.pokeSpriteA2);
                pokeSprites[me][2] = battleView.findViewById(R.id.pokeSpriteB3);
                pokeSprites[opp][2] = battleView.findViewById(R.id.pokeSpriteA3);

                /*if (!isSpectating()) {
                    ((ViewGroup.MarginLayoutParams) infoScroll.getLayoutParams()).setMargins(4, 0, 4, 128);
                }
                ((ViewGroup.MarginLayoutParams)attackRow1.getLayoutParams()).setMargins(0, -126, 0, 79);
                ((ViewGroup.MarginLayoutParams)attackRow2.getLayoutParams()).setMargins(0, -77, 0, 32);*/
            }

            for (int i = 0; i < 2; i++) {
                for (int j = 0; j < battle.numberOfSlots; j++) {
                    pokeSprites[i][j].setOnLongClickListener(spriteListener);
                    pokeSprites[i][j].setBackgroundColor(0);
                }
            }


            infoView.setOnLongClickListener(view -> {
                EditText input = new EditText(BattleActivity.this);
                new AlertDialog.Builder(BattleActivity.this)
                        .setTitle("Battle Chat")
                        .setMessage("Send Battle Message")
                        .setView(input)
                        .setPositiveButton("Send", (i, j) -> {
                            String message = input.getText().toString();
                            if (message.length() > 0) {
                                Baos msg = new Baos();
                                msg.putInt(battle.bID);
                                msg.putString(message);
                                if (activeBattle != null) {
                                    netServ.socket.sendMessage(msg, Command.BattleChat);
                                } else {
                                    netServ.socket.sendMessage(msg, Command.SpectateBattleChat);
                                }
                            }
                        }).setNegativeButton(R.string.title_cancel_button, (arg0, arg1) -> {
                }).show();
                return false;
            });

            // Don't set battleActivity until after we've finished
            // getting UI elements. Otherwise there's a race condition if Battle
            // wants to update one of our UI elements we haven't gotten yet.
            synchronized (battle) {
                battle.activity = BattleActivity.this;
            }

            // Load scrollback
            infoView.setText(battle.hist);
            updateBattleInfo(true);

            // Prompt a UI update of the pokemon
            updateMyPoke(0);
            updateOppPoke(opp, 0);
            if (ChallengeEnums.Mode.values()[battle.conf.mode].numberOfSlots() >= 2) {
                updateMyPoke(1);
                updateOppPoke(opp, 1);
            }
            if (ChallengeEnums.Mode.values()[battle.conf.mode].numberOfSlots() >= 3) {
                updateMyPoke(2);
                updateOppPoke(opp, 2);
            }

            // Enable or disable buttons
            updateButtons();

            // Start timer updating
            handler.postDelayed(updateTimeTask, 100);

            checkRearrangeTeamDialog();

            JxLogger.e("Connection finished at State Time: " + (System.currentTimeMillis() - battle.startTime));
            //    Runtime.getRuntime().gc();
        }

        @Override
        public void onServiceDisconnected(ComponentName className) {
            battle.activity = null;
            netServ = null;
        }
    };

    /**
     * Called when the activity is first created.
     */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        JxLogger.w("Battle id: " + getIntent().getIntExtra("battleId", -1));
        super.onCreate(savedInstanceState);
        mRecvr = new MyResultReceiver(new Handler());
        mRecvr.setReceiver(this);
        try {
            getPackageManager().getApplicationInfo("com.podevs.android.pokemonresources", 0);
        } catch (NameNotFoundException e) {
            JxLogger.d("Animated sprites not found");
            useAnimSprites = false;
        }

        bindService(new Intent(this, NetworkService.class), connection, Context.BIND_AUTO_CREATE);

        resources = getResources();
        realViewSwitcher = new ViewPager(this);
        mainLayout = getLayoutInflater().inflate(R.layout.battle_mainscreen, null);

        //if (mainLayout.findViewById(R.id.smallBattleWindow) != null) {
        /* Small screen, set full screen otherwise pokemon are cropped */
        //  requestWindowFeature(Window.FEATURE_NO_TITLE);
        //}

        realViewSwitcher.setAdapter(new MyAdapter());
        setContentView(realViewSwitcher);

        infoView = mainLayout.findViewById(R.id.infoWindow);
        infoScroll = mainLayout.findViewById(R.id.infoScroll);
        battleView = mainLayout.findViewById(R.id.battleScreen);

        struggleLayout = mainLayout.findViewById(R.id.struggleLayout);
        attackRow1 = mainLayout.findViewById(R.id.attackRow1);
        attackRow2 = mainLayout.findViewById(R.id.attackRow2);
        targetRow1 = mainLayout.findViewById(R.id.targetRowA);
        targetRow2 = mainLayout.findViewById(R.id.targetRowB);

        struggleLayout.setOnClickListener(v -> attackClicked((byte) -1));

        setUncaughtHandler();
    }

    public void attackClicked(byte zone) {
        //netServ.socket.sendMessage(activeBattle.constructAttack((byte)-1, megaClicked, zmoveClicked), Command.BattleMessage);
        BattleChoice.AttackChoice ac = new BattleChoice.AttackChoice(zone, (byte) opp, megaClicked || burstClicked, zmoveClicked);
        myChoices[currentChoiceSlot] = new BattleChoice((byte) battle.slot(me, currentChoiceSlot), ac, BattleChoice.ChoiceType.AttackType);
        if (battle.numberOfSlots == 1) {
            goToNextChoice();
        } else {
            MoveInfo.Target t;
            if (zone == -1) { //struggle
                t = MoveInfo.Target.ChosenTarget;
            } else {
                t = MoveInfo.target(activeBattle.myTeam.pokes[currentChoiceSlot].moves[zone].num());
            }
            if (t == MoveInfo.Target.ChosenTarget || t == MoveInfo.Target.PartnerOrUser || t == MoveInfo.Target.Partner || t == MoveInfo.Target.MeFirstTarget || t == MoveInfo.Target.IndeterminateTarget
                    || activeBattle.numberOfSlots == 3) {
                updateTargetButtons(activeBattle.myTeam.pokes[currentChoiceSlot].moves[zone].num());
                switchToTargetView();
            } else {
                goToNextChoice();
            }
        }
    }

    public void switchToTargetView() {
        isSelectingTarget = true;

        attackRow1.setVisibility(View.GONE);
        attackRow2.setVisibility(View.GONE);
        targetRow1.setVisibility(View.VISIBLE);
        targetRow2.setVisibility(View.VISIBLE);
    }

    public void updateTargetButtons(int move) {
        for (int i = 0; i < activeBattle.numberOfSlots; i++) {
            targetIcons[me][i].setImageDrawable(PokemonInfo.iconDrawable(activeBattle.currentPoke(me, i).uID));
            targetIcons[opp][i].setImageDrawable(PokemonInfo.iconDrawable(activeBattle.currentPoke(opp, i).uID));
            targetNames[me][i].setText(PokemonInfo.name(activeBattle.currentPoke(me, i).uID));
            targetNames[opp][i].setText(PokemonInfo.name(activeBattle.currentPoke(opp, i).uID));

            setTargetButtonEnabled(me, i, false);
            setTargetButtonEnabled(opp, i, false);
            targetLayouts[me][i].setBackgroundResource((R.drawable.battle_border_button));
            targetLayouts[opp][i].setBackgroundResource((R.drawable.battle_border_button));
        }

        MoveInfo.Target target = MoveInfo.target(move);
        if (target == null) {
            return;
        }
        switch (target) {
            case All:
                for (int i = 0; i < 2; i++) {
                    for (int j = 0; j < battle.numberOfSlots; j++) {
                        if (areAdjacent(currentChoiceSlot, j)) {
                            setTargetButtonEnabled(i, j, true);
                            targetLayouts[i][j].setBackgroundResource(R.drawable.battle_border_button_blue);
                        }
                    }
                }
                break;
            case AllButSelf:
                for (int i = 0; i < 2; i++) {
                    for (int j = 0; j < battle.numberOfSlots; j++) {
                        if ((i != me || j != currentChoiceSlot) && areAdjacent(currentChoiceSlot, j)) {
                            setTargetButtonEnabled(i, j, true);
                            targetLayouts[i][j].setBackgroundResource(R.drawable.battle_border_button_blue);
                        }
                    }
                }
                break;
            case Opponents:
                for (int i = 0; i < 2; i++) {
                    for (int j = 0; j < battle.numberOfSlots; j++) {
                        if (i == opp && areAdjacent(currentChoiceSlot, j)) {
                            setTargetButtonEnabled(i, j, true);
                            targetLayouts[i][j].setBackgroundResource(R.drawable.battle_border_button_blue);
                        }
                    }
                }
                break;
            case OpposingTeam:
                for (int i = 0; i < 2; i++) {
                    for (int j = 0; j < battle.numberOfSlots; j++) {
                        if (i == opp) {
                            setTargetButtonEnabled(i, j, true);
                            targetLayouts[i][j].setBackgroundResource(R.drawable.battle_border_button_blue);
                        }
                    }
                }
                break;
            case TeamParty:
            case TeamSide:
                for (int i = 0; i < 2; i++) {
                    for (int j = 0; j < battle.numberOfSlots; j++) {
                        if (i == me) {
                            setTargetButtonEnabled(i, j, true);
                            targetLayouts[i][j].setBackgroundResource(R.drawable.battle_border_button_blue);
                        }
                    }
                }
                break;
            case IndeterminateTarget:
            case ChosenTarget:
                for (int i = 0; i < 2; i++) {
                    for (int j = 0; j < battle.numberOfSlots; j++) {
                        if ((i != me || j != currentChoiceSlot) &&
                                (((MoveInfo.flags(move) & MoveInfo.Flags.FarReachFlag.getValue()) > 0) || areAdjacent(currentChoiceSlot, j))) {
                            setTargetButtonEnabled(i, j, true);
                        }
                    }
                }
                break;
            case PartnerOrUser:
                for (int i = 0; i < 2; i++) {
                    for (int j = 0; j < battle.numberOfSlots; j++) {
                        if (i == me && areAdjacent(currentChoiceSlot, j)) {
                            setTargetButtonEnabled(i, j, true);
                        }
                    }
                }
                break;
            case MeFirstTarget:
                for (int i = 0; i < 2; i++) {
                    for (int j = 0; j < battle.numberOfSlots; j++) {
                        if (i == opp && areAdjacent(currentChoiceSlot, j)) {
                            setTargetButtonEnabled(i, j, true);
                        }
                    }
                }
                break;
            case Partner:
                for (int i = 0; i < 2; i++) {
                    for (int j = 0; j < battle.numberOfSlots; j++) {
                        if (i == me && j != currentChoiceSlot && areAdjacent(currentChoiceSlot, j)) {
                            setTargetButtonEnabled(i, j, true);
                        }
                    }
                }
                break;
            case User:
            case RandomTarget:
            case Field:
                setTargetButtonEnabled(me, currentChoiceSlot, true);
                targetLayouts[me][currentChoiceSlot].setBackgroundResource(R.drawable.battle_border_button_blue);
                break;
            default:
                break;
        }
    }

    public boolean areAdjacent(int slot1, int slot2) {
        return Math.abs(slot1 - slot2) <= 1;
    }

    void setTargetButtonEnabled(int player, int num, boolean enabled) {
        targetLayouts[player][num].setEnabled(enabled);
        targetNames[player][num].setEnabled(enabled);
        targetNames[player][num].setShadowLayer((float) 1.5, 1, 1, resources.getColor(
                enabled ? R.color.poke_text_shadow_enabled : R.color.poke_text_shadow_disabled));
        targetIcons[player][num].setEnabled(enabled);
    }

    public void goToNextChoice() {
        Baos b = new Baos();
        b.putInt(battle.bID);
        b.putBaos(myChoices[currentChoiceSlot]);
        netServ.socket.sendMessage(b, Command.BattleMessage);

        currentChoiceSlot++;
        if (currentChoiceSlot >= activeBattle.numberOfSlots) {
            activeBattle.clicked = true;
        }
        updateButtons();
    }

    public void updateButtons() {
        if (isSpectating()) {
            return;
        }
        runOnUiThread(() -> {
            if (activeBattle.clicked) {
                for (int i = 0; i < 4; i++) {
                    setAttackButtonEnabled(i, false);
                }
                for (int i = 0; i < 6; i++) {
                    pokeList[i].setEnabled(i, false);
                }
            } else {
                if (!isSelectingTarget) {
                    if (!checkStruggle()) {
                        for (int i = 0; i < 4; i++) {
                            if (activeBattle.allowAttack[currentChoiceSlot]) {
                                BattleMove newMove = activeBattle.displayedMoves[i] = new BattleMove(activeBattle.myTeam.pokes[currentChoiceSlot].moves[i]);
                                if (zmoveClicked) {
                                    if (newMove.power > 0 && activeBattle.allowZMoves[currentChoiceSlot][i]) {
                                        newMove.num = ItemInfo.zCrystalMove(activeBattle.myTeam.pokes[currentChoiceSlot].item);
                                    }
                                    setAttackButtonEnabled(i, activeBattle.allowZMoves[currentChoiceSlot][i]);
                                } else {
                                    setAttackButtonEnabled(i, activeBattle.allowAttacks[currentChoiceSlot][i]);
                                }
                                attackNames[i].setText(MoveInfo.zName(newMove.num(), zmoveClicked));
                                String type;
                                if (newMove.num == 237) {
                                    type = TypeInfo.name(activeBattle.myTeam.pokes[currentChoiceSlot].hiddenPowerType());
                                } else {
                                    type = TypeInfo.name(MoveInfo.type(newMove.num()));
                                }
                                type = type.toLowerCase();
                                attackLayouts[i].setBackgroundResource(resources.getIdentifier(type + "_type_button",
                                        "drawable", InfoConfig.PKG_NAME));
                            } else {
                                setAttackButtonEnabled(i, false);
                            }
                        }
                    }
                }
                megaClicked = false;
                burstClicked = false;
                for (int i = 0; i < 6; i++) {
                    if (activeBattle.myTeam.pokes[i].currentHP > 0 && activeBattle.myTeam.pokes[i].status() != Status.Koed.poValue() && !activeBattle.clicked) {
                        boolean alreadySwitched = false;
                        for (int j = 0; j < currentChoiceSlot; j++) {
                            if (myChoices[j].choiceType == BattleChoice.ChoiceType.SwitchType && ((BattleChoice.SwitchChoice) myChoices[j].choice).pokeSlot == i) {
                                alreadySwitched = true;
                                break;
                            }
                        }
                        if (!alreadySwitched && i >= activeBattle.numberOfSlots) {
                            pokeList[i].setEnabled(i, activeBattle.allowSwitch[currentChoiceSlot]);
                        } else {
                            pokeList[i].setEnabled(i, false);
                        }
                    } else {
                        pokeList[i].setEnabled(i, false);
                    }
                }
            }
        });
    }

    public boolean isSpectating() {
        return activeBattle == null;
    }

    public boolean checkStruggle() {
        // This method should hide moves, show the button if necessary and return whether it showed the button
        boolean struggle = activeBattle.shouldStruggle[currentChoiceSlot];
        if (struggle) {
            attackRow1.setVisibility(View.GONE);
            attackRow2.setVisibility(View.GONE);
            struggleLayout.setVisibility(View.VISIBLE);
        } else {
            attackRow1.setVisibility(View.VISIBLE);
            attackRow2.setVisibility(View.VISIBLE);
            struggleLayout.setVisibility(View.GONE);
        }
        return struggle;
    }

    void setAttackButtonEnabled(int num, boolean enabled) {
        /*
        if (enabled) {
            if (!attackLayouts[num].isEnabled()) {
                JxLogger.e("%s", "Enabling button " + num + " at State Time: " + (System.currentTimeMillis() - battle.startTime));
            }
        } else {
            if (attackLayouts[num].isEnabled()) {
                JxLogger.e("%s", "Disabling button " + num + " at State Time: " + (System.currentTimeMillis() - battle.startTime));
            }
        }
        */
        attackLayouts[num].setEnabled(enabled);
        attackNames[num].setEnabled(enabled);
        attackNames[num].setShadowLayer((float) 1.5, 1, 1, resources.getColor(
                enabled ? R.color.poke_text_shadow_enabled : R.color.poke_text_shadow_disabled));
        attackPPs[num].setEnabled(enabled);
        attackPPs[num].setShadowLayer((float) 1.5, 1, 1, resources.getColor(
                enabled ? R.color.pp_text_shadow_enabled : R.color.pp_text_shadow_disabled));
    }

    private void setUncaughtHandler() {
        BattleExceptionHandler exceptionHandler = new BattleExceptionHandler(this);
        Thread.currentThread().setUncaughtExceptionHandler(exceptionHandler);
        runOnUiThread(() -> Thread.currentThread().setUncaughtExceptionHandler(exceptionHandler));
    }

    @Override
    public void onResume() {
        // XXX we might want more stuff here
        super.onResume();
        if (battle != null) {
            checkRearrangeTeamDialog();
        }
    }

    private void checkRearrangeTeamDialog() {
        if (netServ != null && netServ.isBattling() && battle.shouldShowPreview) {
            try {
                Thread.sleep(200);
            } catch (Exception e) {
                e.printStackTrace();
            }
            showDialog(BattleDialog.RearrangeTeam.ordinal());
        }
    }

    @Override
    public void onDestroy() {
        unbindService(connection);
        super.onDestroy();
    }

    boolean isSampleSpriteWebView(View left, View right) {
        return left != null && right != null && (left.getId() == right.getId());
    }

    public void setHpBarTo(int player, int slot, int goal) {
        hpAnimator.setGoal(player, slot, goal);
        hpAnimator.setHpBarToGoal();
    }

    public void animateHpBarTo(int player, int slot, int goal, int change) {
        hpAnimator.setGoal(player, slot, goal);
        new Thread(hpAnimator).start();
    }

    public void updateBattleInfo(boolean scroll) {
        runOnUiThread(() -> {
            if (battle == null) {
                return;
            }
            synchronized (battle.histDelta) {
                infoView.append(battle.histDelta);
                if (battle.histDelta != null) {
                    infoScroll.post(() -> infoScroll.smoothScrollTo(0, infoView.getMeasuredHeight()));
                }
                infoScroll.invalidate();
                battle.hist.append(battle.histDelta);
                battle.histDelta.clear();
            }
        });
    }

    public void updatePokes(byte player, byte slot) {
        // JxLogger.e("%s", PokemonInfo.cacheStatus());
        if (player == me) {
            updateMyPoke(slot);
        } else {
            updateOppPoke(player, slot);
        }
    }

    public void updatePokeBalls() {
        runOnUiThread(() -> {
            for (int i = 0; i < 2; i++) {
                for (int j = 0; j < 6; j++) {
                    ImageView imageView = pokeballs[i][j];
                    ShallowBattlePoke battlePoke = battle.pokes[i][j];
                    Drawable drawable = battlePoke.uID.main != 0
                            ? PokemonInfo.iconDrawableCache(battlePoke.uID)
                            : PokemonInfo.iconDrawablePokeBallStatus();
                    if (drawable == null) {
                        continue;
                    }
                    // drawable.setBounds(0, 0, 24, 24);
                    imageView.setImageDrawable(drawable);
                    imageView.setColorFilter(statusTint(battlePoke.status()));
                }
            }
            /// PorterDuff.Mode.MULTIPLY;
        });
    }

    public int statusTint(int status) {
        switch (status) {
            case 0:
                return 1;
            case 31:
                return 0x7D000000;
            case 1:
                return 0x7DF8D030;
            case 2:
                return 0x7D888888;
            case 3:
                return 0x7D98D8D8;
            case 4:
                return 0x7DF08030;
            case 5:
                return 0x7DA040A0;
            case 6:
                return 0x7DC8C8C8;
            default:
                return 0;
        }
    }

    public void updatePokeBall(int player, int poke) {
        runOnUiThread(() -> {
            ImageView imageView = pokeballs[player][poke];
            ShallowBattlePoke battlePoke = battle.pokes[player][poke];
            imageView.setImageDrawable((
                    battlePoke.uID.main != 0
                            ? PokemonInfo.iconDrawableCache(battlePoke.uID)
                            : PokemonInfo.iconDrawablePokeBallStatus()
            ));
            imageView.setColorFilter(statusTint(battlePoke.status()));
        });
    }

    private String getAnimSprite(ShallowBattlePoke poke, boolean front) {
        String res;
        UniqueID uID;
        if (poke.specialSprites.isEmpty()) {
            uID = poke.uID;
        } else {
            uID = poke.specialSprites.peek();
        }

        if (uID == null) {
            return "";
        }

        if (poke.uID.main < 0) {
            res = null;
        } else {
            String sexy = poke.gender == GenderInfo.Gender.Female.ordinal() ? "f" : "";
            String direct = front ? "_front" : "_back";
            String sub = uID.sub == 0 ? "" : "_" + uID.sub;
            String shiny = poke.shiny ? "s" : "";
            res = String.format("anim%03d", uID.main) + sub + sexy + direct + shiny + ".gif";
        }
        return res;
    }

    public void updateCurrentPokeListEntry() {
        runOnUiThread(() -> {
            synchronized (battle) {
                BattlePoke battlePoke = activeBattle.myTeam.pokes[0];
                pokeList[0].hp.setText(battlePoke.currentHP + "/" + battlePoke.totalHP);
            }
            // TODO: Status ailments and stuff
        });
    }

    public void updateMovePP(int moveNum) {
        runOnUiThread(() -> {
            BattleMove move = activeBattle.displayedMoves[moveNum];
            attackPPs[moveNum].setText("PP " + move.currentPP + "/" + move.totalPP);
        });
    }

    @Override
    public void onReceiveResult(int resultCode, Bundle resultData) {
        if (resultCode != Activity.RESULT_OK) {
            return;
        }
        String path = resultData.getString("path");
        JxLogger.i("%s %s", path, resultData.getString("sprite"));

        if (resultData.getBoolean("me")) {
            loadSpriteImage(pokeSprites[me][0], resultData.getString("sprite"), true);
// pokeSprites[me][0].loadDataWithBaseURL(path, "<head><style type=\"text/css\">body{background-position:center bottom;background-repeat:no-repeat; background-image:url('" + resultData.getString("sprite") + "');}</style><body></body>", "text/html", "utf-8", null);
            loadSpriteImage(pokeSprites[me][1], resultData.getString("sprite"), true);
//  pokeSprites[me][1].loadDataWithBaseURL(path, "<head><style type=\"text/css\">body{background-position:center bottom;background-repeat:no-repeat; background-image:url('" + resultData.getString("sprite") + "');}</style><body></body>", "text/html", "utf-8", null);
            loadSpriteImage(pokeSprites[me][2], resultData.getString("sprite"), true);
// pokeSprites[me][2].loadDataWithBaseURL(path, "<head><style type=\"text/css\">body{background-position:center bottom;background-repeat:no-repeat; background-image:url('" + resultData.getString("sprite") + "');}</style><body></body>", "text/html", "utf-8", null);
        } else {
            loadSpriteImage(pokeSprites[opp][0], resultData.getString("sprite"), false);
            // pokeSprites[opp][0].loadDataWithBaseURL(path, "<head><style type=\"text/css\">body{background-position:center bottom;background-repeat:no-repeat; background-image:url('" + resultData.getString("sprite") + "');}</style><body></body>", "text/html", "utf-8", null);
            loadSpriteImage(pokeSprites[opp][1], resultData.getString("sprite"), false);
// pokeSprites[opp][1].loadDataWithBaseURL(path, "<head><style type=\"text/css\">body{background-position:center bottom;background-repeat:no-repeat; background-image:url('" + resultData.getString("sprite") + "');}</style><body></body>", "text/html", "utf-8", null);
            loadSpriteImage(pokeSprites[opp][2], resultData.getString("sprite"), false);
// pokeSprites[opp][2].loadDataWithBaseURL(path, "<head><style type=\"text/css\">body{background-position:center bottom;background-repeat:no-repeat; background-image:url('" + resultData.getString("sprite") + "');}</style><body></body>", "text/html", "utf-8", null);
        }
    }

    void loadSpriteImage(pl.droidsonroids.gif.GifImageView view, String path, boolean isMe) {
        if (TextUtils.isEmpty(path)) {
            view.setImageResource(R.drawable.empty_sprite);
            return;
        }
        if (TextUtils.equals(path, "empty_sprite")) {
            view.setImageResource(R.drawable.empty_sprite);
        }
//            int lastDot = path.lastIndexOf('.');
//            String res = path;
//            if (lastDot != -1) {
//                res = path.substring(0, path.indexOf('.'));
//            }
        //int resID = resources.getIdentifier(res, "drawable", InfoConfig.pkgName);
        //if (resID > 0) {

        if (path.contains("sub_front.png")) {
            view.setImageResource(R.drawable.sub_front);
            return;
        }
        InfoConfig.stream(path, null, stream -> {
            if (path.endsWith("gif")) {
                GifDrawable gifFromAssets = null;
                try {
                    gifFromAssets = new GifDrawable(stream);
                } catch (IOException e) {
                    e.printStackTrace();
                }
                view.setImageDrawable(gifFromAssets);
                // view.setImageResource(resID);
            } else {
//                    Drawable drawable = Drawable.createFromStream(getAssets().open("sprite/" + path), null);
//                    view.setImageDrawable(drawable);
                view.setImageDrawable(Drawable.createFromStream(stream, null));
            }
            //} else {
            //    JxLogger.w("bad sprite: %s", path);
            //}
        }, streamWithFailed -> {
            if (isMe) {
                view.setImageResource(R.drawable.sub_back);
            } else {
                view.setImageResource(R.drawable.sub_front);
            }
        });


    }

    public void updateMyPoke(int slot) {
        if (isSpectating()) {
            updateOppPoke(me, slot);
            return;
        }
        runOnUiThread(() -> {
            ShallowBattlePoke poke = battle.currentPoke(me, slot);
            poke.shiny = activeBattle.myTeam.pokes[slot].shiny; // This is a very stupid way to do it. ShallowBattleTeam never gives shiny correctly?
            // Load correct move set and name
            if (!samePokes[me]) {
                currentPokeNames[me][slot].setText(poke.rnick);
                currentPokeLevels[me][slot].setText(getString(R.string.LevelPrefix) + poke.level);
                currentPokeGenders[me][slot].setImageDrawable(PokemonInfo.genderDrawableCache((int) poke.gender));
            }

            currentPokeStatuses[me][slot].setImageResource(resources.getIdentifier("battle_status" + poke.status(), "drawable", InfoConfig.PKG_NAME));
            setHpBarTo(me, slot, poke.lifePercent);

            for (int i = 0; i < 4; i++) {
                BattleMove move = activeBattle.myTeam.pokes[slot].moves[i];
                updateMovePP(i);
                attackNames[i].setText(move.toString());
                String type;
                if (move.num == 237) {
                    type = TypeInfo.name(activeBattle.myTeam.pokes[slot].hiddenPowerType());
                } else {
                    type = TypeInfo.name(MoveInfo.type(move.num()));
                }
                type = type.toLowerCase();
                attackLayouts[i].setBackgroundResource(resources.getIdentifier(type + "_type_button",
                        "drawable", InfoConfig.PKG_NAME));
            }

            if (!samePokes[me]) {
                String sprite = null;
                if (battle.shouldShowPreview || poke.status() == Status.Koed.poValue()) {
                    sprite = "empty_sprite.png";
                } else if (poke.sub) {
                    sprite = "sub_back.png";
                } else {
                    if (useAnimSprites) {
                        Intent data = new Intent();
                        data.setComponent(servName);
                        data.putExtra("me", true);
                        data.putExtra("sprite", getAnimSprite(poke, false));
                        data.putExtra("cb", mRecvr);
                        startService(data);
                    } else {
                        sprite = PokemonInfo.sprite(poke, false);
                    }
                }

                if (sprite != null) {
                    loadSpriteImage(pokeSprites[me][slot], sprite, false);
                    // pokeSprites[me][slot].loadDataWithBaseURL("file:///android_res/drawable/", "<head><style type=\"text/css\">body{background-position:center bottom;background-repeat:no-repeat; background-image:url('" + sprite + "');}</style><body></body>", "text/html", "utf-8", null);
                }
            } else {
                samePokes[me] = true;
            }
        });
        updateTeam();
    }

    public void updateOppPoke(int opp, int slot) {
        runOnUiThread(() -> {
            ShallowBattlePoke poke = battle.currentPoke(opp, slot);
            // Load correct moveset and name
            if (poke != null) {
                if (!samePokes[opp]) {
                    currentPokeNames[opp][slot].setText(poke.rnick);
                    currentPokeLevels[opp][slot].setText(getString(R.string.LevelPrefix) + poke.level);
                    currentPokeGenders[opp][slot].setImageDrawable(PokemonInfo.genderDrawableCache((int) poke.gender));
                }

                currentPokeStatuses[opp][slot].setImageResource(resources.getIdentifier("battle_status" + poke.status(), "drawable", InfoConfig.PKG_NAME));
                setHpBarTo(opp, slot, poke.lifePercent);

                if (!samePokes[opp]) {
                    String sprite = null;
                    if (battle.shouldShowPreview || poke.status() == Status.Koed.poValue()) {
                        sprite = "empty_sprite.png";
                    } else if (poke.sub) {
                        sprite = opp == me ? "sub_back.png" : "sub_front.png";
                    } else {
                        if (useAnimSprites) {
                            Intent data = new Intent();
                            data.setComponent(servName);
                            data.putExtra("me", false);
                            data.putExtra("sprite", getAnimSprite(poke, opp != me));
                            data.putExtra("cb", mRecvr);
                            startService(data);
                        } else {
                            sprite = PokemonInfo.sprite(poke, opp != me);
                        }
                    }

                    if (sprite != null) {
                        loadSpriteImage(pokeSprites[opp][slot], sprite, false);//pokeSprites[opp][slot].loadDataWithBaseURL("file:///android_res/drawable/", "<head><style type=\"text/css\">body{background-position:center bottom;background-repeat:no-repeat; background-image:url('" + sprite + "');}</style><body></body>", "text/html", "utf-8", null);
                    }
                } else {
                    samePokes[opp] = true;
                }
            }
        });
    }

    public void updateTeam() {
        runOnUiThread(() -> {
            for (int i = 0; i < 6; i++) {
                BattlePoke poke = activeBattle.myTeam.pokes[i];
                pokeList[i].update(poke, activeBattle.allowSwitch[currentChoiceSlot] && !activeBattle.clicked && poke.currentHP > 0 && poke.status() != Status.Koed.poValue());
            }
        });
    }

    public void updateMoves(short attack) {
        if (!isSpectating()) {
            activeBattle.pokes[opp][0].addMove(attack, (byte) 1);
        }
    }

    public void updateMoves(byte player, byte spot, short attack, byte pp) {
        activeBattle.pokes[player][spot].addMove(attack, pp);
    }

    public void switchToPokeViewer() {
        runOnUiThread(() -> realViewSwitcher.setCurrentItem(1, true));
    }

    /*
    public OnTouchListener dialogListener = new OnTouchListener() {
        public boolean onTouch(View v, MotionEvent e) {
            int id = v.getId();
            for(int i = 0; i < 6; i++) {
                if(id == myArrangePokeIcons[i].getId() && e.getAction() == MotionEvent.ACTION_DOWN) {
                    Object dragInfo = v;
                    mDragLayer.startDrag(v, myArrangePokeIcons[i], dragInfo, DragController.DRAG_ACTION_MOVE);
                    break;
                }
            }
            return true;
        }
    };*/

    @Override
    public void onBackPressed() {
        startActivity(new Intent(BattleActivity.this, ChatActivity.class));
        finish();
    }

    public void targetClicked(byte target) {
        if (myChoices[currentChoiceSlot].choiceType == BattleChoice.ChoiceType.AttackType) {
            ((BattleChoice.AttackChoice) myChoices[currentChoiceSlot].choice).attackTarget = target;
        }
        switchToMoveView();
        goToNextChoice();
    }

    public void switchToMoveView() {
        isSelectingTarget = false;

        attackRow1.setVisibility(View.VISIBLE);
        attackRow2.setVisibility(View.VISIBLE);
        targetRow1.setVisibility(View.GONE);
        targetRow2.setVisibility(View.GONE);
    }

    public void end() {
        runOnUiThread(this::finish);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        super.onCreateOptionsMenu(menu);
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(isSpectating() ? R.menu.spectatingbattleoptions : R.menu.battleoptions, menu);

        menu.findItem(R.id.sounds).setChecked(getSharedPreferences("battle", MODE_PRIVATE).getBoolean("pokemon_cries", true));
        return true;
    }

    @Override
    public boolean onPrepareOptionsMenu(Menu menu) {
        super.onPrepareOptionsMenu(menu);

        if (!isSpectating()) {
            if (activeBattle.gotEnd) {
                menu.findItem(R.id.close).setVisible(true);
                menu.findItem(R.id.cancel).setVisible(false);
                menu.findItem(R.id.forfeit).setVisible(false);
                menu.findItem(R.id.draw).setVisible(false);
            } else {
                /* No point in canceling if no action done */
                menu.findItem(R.id.close).setVisible(false);
                menu.findItem(R.id.cancel).setVisible(currentChoiceSlot > 0);
            }

            boolean necrozmaForme = activeBattle.myTeam.pokes[currentChoiceSlot].uID().main == 800
                    && (activeBattle.myTeam.pokes[currentChoiceSlot].uID().sub == 1 || activeBattle.myTeam.pokes[currentChoiceSlot].uID().sub == 2);

            menu.findItem(R.id.megavolve).setVisible(
                    !activeBattle.clicked && (activeBattle.allowMega[currentChoiceSlot] && !necrozmaForme));
            menu.findItem(R.id.megavolve).setChecked(megaClicked);

            if (megaClicked) {
                menu.findItem(R.id.megavolve).setShowAsAction(MenuItem.SHOW_AS_ACTION_NEVER);
            } else {
                menu.findItem(R.id.megavolve).setShowAsAction(MenuItem.SHOW_AS_ACTION_IF_ROOM | MenuItem.SHOW_AS_ACTION_WITH_TEXT);
            }

            menu.findItem(R.id.ultraburst).setVisible(
                    !activeBattle.clicked && (activeBattle.allowMega[currentChoiceSlot] && necrozmaForme));
            menu.findItem(R.id.ultraburst).setChecked(burstClicked);

            if (burstClicked) {
                menu.findItem(R.id.ultraburst).setShowAsAction(MenuItem.SHOW_AS_ACTION_NEVER);
            } else {
                menu.findItem(R.id.ultraburst).setShowAsAction(MenuItem.SHOW_AS_ACTION_IF_ROOM | MenuItem.SHOW_AS_ACTION_WITH_TEXT);
            }

            menu.findItem(R.id.zmove).setVisible(
                    !activeBattle.clicked && activeBattle.allowZMove[currentChoiceSlot]);
            menu.findItem(R.id.zmove).setChecked(zmoveClicked);
            if (zmoveClicked) {
                menu.findItem(R.id.zmove).setShowAsAction(MenuItem.SHOW_AS_ACTION_NEVER);
            } else {
                menu.findItem(R.id.zmove).setShowAsAction(MenuItem.SHOW_AS_ACTION_IF_ROOM | MenuItem.SHOW_AS_ACTION_WITH_TEXT);
            }
            menu.findItem(R.id.shifttocenter).setVisible(!activeBattle.clicked && activeBattle.numberOfSlots == 3 && currentChoiceSlot != 1);
        }
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int itemId = item.getItemId();
        if (itemId == R.id.zmove) {
            item.setChecked(!item.isChecked());
            zmoveClicked = item.isChecked();
            if (zmoveClicked) {
                item.setShowAsAction(MenuItem.SHOW_AS_ACTION_NEVER);
            } else {
                item.setShowAsAction(MenuItem.SHOW_AS_ACTION_IF_ROOM | MenuItem.SHOW_AS_ACTION_WITH_TEXT);
            }
            updateButtons();
        } else if (itemId == R.id.ultraburst) {
            item.setChecked(!item.isChecked());
            burstClicked = item.isChecked();
            if (burstClicked) {
                item.setShowAsAction(MenuItem.SHOW_AS_ACTION_NEVER);
            } else {
                item.setShowAsAction(MenuItem.SHOW_AS_ACTION_IF_ROOM | MenuItem.SHOW_AS_ACTION_WITH_TEXT);
            }
        } else if (itemId == R.id.megavolve) {
            item.setChecked(!item.isChecked());
            megaClicked = item.isChecked();
            if (megaClicked) {
                item.setShowAsAction(MenuItem.SHOW_AS_ACTION_NEVER);
            } else {
                item.setShowAsAction(MenuItem.SHOW_AS_ACTION_IF_ROOM | MenuItem.SHOW_AS_ACTION_WITH_TEXT);
            }
        } else if (itemId == R.id.shifttocenter) {
            BattleChoice.MoveToCenterChoice mtc = new BattleChoice.MoveToCenterChoice();
            myChoices[currentChoiceSlot] = new BattleChoice((byte) battle.slot(me, currentChoiceSlot), mtc, BattleChoice.ChoiceType.CenterMoveType);
            zmoveClicked = false;
            goToNextChoice();
        } else if (itemId == R.id.cancel) {
            netServ.socket.sendMessage(activeBattle.constructCancel(), Command.BattleMessage);
            currentChoiceSlot = 0;
        } else if (itemId == R.id.forfeit) {
            if (netServ != null && netServ.isBattling() && !battle.gotEnd) {
                showDialog(BattleDialog.ConfirmForfeit.ordinal());
            }
        } else if (itemId == R.id.close) {
            if (isSpectating()) {
                netServ.stopWatching(battle.bID);
            } else {
                endBattle();
            }
        } else if (itemId == R.id.draw) {
            netServ.socket.sendMessage(activeBattle.constructDraw(), Command.BattleMessage);
        } else if (itemId == R.id.sounds) {
            item.setChecked(!item.isChecked());
            getSharedPreferences("battle", Context.MODE_PRIVATE).edit().putBoolean("pokemon_cries", item.isChecked()).apply();
        } else if (itemId == R.id.debug) {
            showDialog(BattleDialog.Debug.ordinal());
        }
        return true;
    }

	/*
    void setLayoutEnabled(ViewGroup v, boolean enabled) {
    	v.setEnabled(enabled);
    	v.getBackground().setAlpha(enabled ? 255 : 128);
    }
    
    void setTextViewEnabled(TextView v, boolean enabled) {
    	v.setEnabled(enabled);
    	v.setTextColor(v.getTextColors().withAlpha(enabled ? 255 : 128).getDefaultColor());
    }
    */

    void endBattle() {
        if (netServ != null && netServ.socket != null && connected/*netServ.socket.isConnected()*/) {
            Baos bID = new Baos();
            bID.putInt(battle.bID);
            netServ.socket.sendMessage(bID, Command.BattleFinished);
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    @Override
    protected Dialog onCreateDialog(int id) {
        int player = me;
        AlertDialog dialog;
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        LayoutInflater inflater = (LayoutInflater) getSystemService(LAYOUT_INFLATER_SERVICE);
        switch (BattleDialog.values()[id]) {
            case RearrangeTeam:
                return buildRearrangeTeam(id, builder, inflater);
            case ConfirmForfeit:
                builder.setMessage("Really Forfeit?")
                        .setCancelable(true)
                        .setPositiveButton("Forfeit", (dialog14, which) -> endBattle())
                        .setNegativeButton(R.string.title_cancel_button, null);
                return builder.create();
            case OppDynamicInfo:
                player = opp;
            case MyDynamicInfo:
                if (netServ != null && battle != null && battle.dynamicInfo[player] != null) {
                    Dialog simpleDialog = new Dialog(this);
                    simpleDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
                    simpleDialog.setContentView(R.layout.dynamic_info_layout);

                    TextView t = simpleDialog.findViewById(R.id.nameTypeView);
                    t.setText(((player == me && !isSpectating()) ? activeBattle.myTeam.pokes[0]
                            : battle.currentPoke(player, 0)).nameAndType());
                    t = simpleDialog.findViewById(R.id.statNamesView);
                    t.setText(battle.dynamicInfo[player].statsAndHazards());
                    t = simpleDialog.findViewById(R.id.statNumsView);
                    if (player == me && !isSpectating()) {
                        t.setText(activeBattle.myTeam.pokes[0].printStats());
                    } else if (player != me && !isSpectating()) {
                        t.setText(activeBattle.currentPoke(player, 0).statString(battle.dynamicInfo[player].boosts));
                        t = simpleDialog.findViewById(R.id.moveString);
                        t.setText(activeBattle.currentPoke(opp, 0).movesString());
                    }
                    //	t.setVisibility(View.GONE);
                    t = simpleDialog.findViewById(R.id.statBoostView);
                    String s = battle.dynamicInfo[player].boosts();
                    if (!"\n\n\n\n".equals(s)) {
                        t.setText(s);
                    } else {
                        t.setVisibility(View.GONE);
                    }
                    simpleDialog.setCanceledOnTouchOutside(true);
                    simpleDialog.setOnCancelListener(dialog13 -> removeDialog(id));
                    simpleDialog.findViewById(R.id.dynamic_info_layout).setOnClickListener(v -> simpleDialog.cancel());
                    return simpleDialog;
                }
                return null;
            case MoveInfo:
                dialog = builder.setTitle(lastClickedMove.toString())
                        .setMessage(lastClickedMove.descAndEffects())
                        .setOnCancelListener(dialog12 -> removeDialog(id))
                        .create();
                dialog.setCanceledOnTouchOutside(true);
                return dialog;
            case Debug:
                String debug = battle.packetStack.toReadableString();
                Dialog simpleDialog = new Dialog(this);
                simpleDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
                simpleDialog.setContentView(R.layout.debug_layout);

                TextView t = simpleDialog.findViewById(R.id.debug_text);
                t.setText(debug);

                simpleDialog.setCanceledOnTouchOutside(true);
                simpleDialog.setOnCancelListener(dialog1 -> removeDialog(id));

                return simpleDialog;
            default:
                return new Dialog(this);
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    private Dialog buildRearrangeTeam(int id, AlertDialog.Builder builder, LayoutInflater inflater) {
        AlertDialog dialog;
        View layout = inflater.inflate(R.layout.re_arrange_team_dialog, findViewById(R.id.drag_my_poke_layout));
        TextView nameAndType = layout.findViewById(R.id.nameTypeView);
        TextView statNames = layout.findViewById(R.id.statNamesView);
        TextView statNums = layout.findViewById(R.id.statNumsView);
        TextView moves = layout.findViewById(R.id.moveString);

        builder.setView(layout)
                .setPositiveButton("Done", (dialog15, which) -> {
                    netServ.socket.sendMessage(activeBattle.constructRearrange(), Command.BattleMessage);
                    battle.shouldShowPreview = false;
                    removeDialog(id);
                })
                .setCancelable(false);
        dialog = builder.create();

        mDragLayer = layout.findViewById(R.id.drag_my_poke);
                /*
                mDragLayer.addDragListener(new DragController.DragListener() {
                    @Override
                    public void onDragStart(View v, DragSource source, Object info, int dragAction) {

                    }

                    @Override
                    public void onDragEnd() {
                        nameAndType.setText(activeBattle.myTeam.pokes[0].nameAndType());
                        String s = "HP:";
                        s += "\nAttack:";
                        s += "\nDefense:";
                        s += "\nSp. Att:";
                        s += "\nSp. Def:";
                        s += "\nSpeed:";
                        statNames.setText(s);
                        statNums.setText(activeBattle.myTeam.pokes[0].printStats());
                        moves.setText(activeBattle.myTeam.pokes[0].movesString());
                    }
                });*/
        for (int i = 0; i < 6; i++) {
            BattlePoke poke = activeBattle.myTeam.pokes[i];
            myArrangePokeIcons[i] = layout.findViewById(resources.getIdentifier("my_arrange_poke" + (i + 1), "id", InfoConfig.PKG_NAME));
            myArrangePokeIcons[i].setOnTouchListener(dialogListener(nameAndType, statNames, statNums, moves));
            myArrangePokeIcons[i].setImageDrawable(PokemonInfo.iconDrawableCache(poke.uID));
            myArrangePokeIcons[i].num = i;
            myArrangePokeIcons[i].battleActivity = this;

            ShallowShownPoke oppPoke = activeBattle.oppTeam.pokes[i];
            oppArrangePokeIcons[i] = layout.findViewById(resources.getIdentifier("foe_arrange_poke" + (i + 1), "id", InfoConfig.PKG_NAME));
            oppArrangePokeIcons[i].setImageDrawable(PokemonInfo.iconDrawableCache(oppPoke.uID));
            oppArrangePokeIcons[i].setOnTouchListener(oppdialogListener(nameAndType, statNames, statNums, moves, i));
        }
        BattlePoke poke = activeBattle.myTeam.pokes[0];
        nameAndType.setText(poke.nameAndType());
        String s = "HP:";
        s += "\nAttack:";
        s += "\nDefense:";
        s += "\nSp. Att:";
        s += "\nSp. Def:";
        s += "\nSpeed:";
        statNames.setText(s);
        statNums.setText(poke.printStats());
        moves.setText(poke.movesString());
        return dialog;
    }

    public OnTouchListener dialogListener(TextView nameAndType, TextView statNames, TextView statNums, TextView moves) {
        return (v, event) -> {
            int id = v.getId();
            for (int i = 0; i < 6; i++) {
                if (id == myArrangePokeIcons[i].getId() && event.getAction() == MotionEvent.ACTION_DOWN) {
                    int num = myArrangePokeIcons[i].num;
                    nameAndType.setText(activeBattle.myTeam.pokes[num].nameAndType());
                    String s = "HP:";
                    s += "\nAttack:";
                    s += "\nDefense:";
                    s += "\nSp. Att:";
                    s += "\nSp. Def:";
                    s += "\nSpeed:";
                    statNames.setText(s);
                    statNums.setText(activeBattle.myTeam.pokes[num].printStats());
                    moves.setText(activeBattle.myTeam.pokes[num].movesString());
                    mDragLayer.startDrag(v, myArrangePokeIcons[i], event, DragController.DRAG_ACTION_MOVE);
                    break;
                }
            }
            return true;
        };
    }

    public OnTouchListener oppdialogListener(TextView nameAndType, TextView statNames, TextView statNums, TextView moves, int index) {
        return (v, event) -> {
            if (event.getAction() == MotionEvent.ACTION_DOWN) {
                nameAndType.setText(activeBattle.oppTeam.pokes[index].nameAndType());
                String s = "HP:";
                s += "\nAttack:";
                s += "\nDefense:";
                s += "\nSp. Att:";
                s += "\nSp. Def:";
                s += "\nSpeed:";
                statNames.setText(s);
                statNums.setText(activeBattle.oppTeam.pokes[index].statString());
                moves.setText(activeBattle.oppTeam.pokes[index].moves());
            }
            return true;
        };
    }

    public void notifyRearrangeTeamDialog() {
        runOnUiThread(this::checkRearrangeTeamDialog);
    }

    public enum BattleDialog {
        RearrangeTeam,
        ConfirmForfeit,
        OppDynamicInfo,
        MyDynamicInfo,
        MoveInfo,
        Debug
    }

    class HpAnimator implements Runnable {
        int player, slot, goal;
        boolean finished;

        public void setGoal(int player, int slot, int goal) {
            this.player = player;
            this.slot = slot;
            this.goal = goal;
            finished = false;
        }

        @Override
        public void run() {
            while (goal < hpBars[player][slot].getProgress()) {
                runOnUiThread(() -> {
                    hpBars[player][slot].incrementProgressBy(-1);
                    hpBars[player][slot].setText(hpBars[player][slot].getProgress() + "%");
                    checkHpColor();
                });
                try {
                    Thread.sleep(30);
                } catch (InterruptedException e) {
                    // TODO Auto-generated catch block
                }
            }
            while (goal > hpBars[player][slot].getProgress()) {
                runOnUiThread(() -> {
                    hpBars[player][slot].incrementProgressBy(1);
                    hpBars[player][slot].setText(hpBars[player][slot].getProgress() + "%");
                    checkHpColor();
                });
                try {
                    Thread.sleep(30);
                } catch (InterruptedException e) {
                    // TODO Auto-generated catch block
                }
            }

            synchronized (battle) {
                battle.notify();
            }
        }

        void checkHpColor() {
            runOnUiThread(() -> {
                int progress = hpBars[player][slot].getProgress();
                Rect bounds = hpBars[player][slot].getProgressDrawable().getBounds();
                if (progress > 50) {
                    hpBars[player][slot].setProgressDrawable(AppCompatResources.getDrawable(BattleActivity.this, R.drawable.green_progress));
                } else if (progress > 20) {
                    hpBars[player][slot].setProgressDrawable(AppCompatResources.getDrawable(BattleActivity.this, R.drawable.yellow_progress));
                } else {
                    hpBars[player][slot].setProgressDrawable(AppCompatResources.getDrawable(BattleActivity.this, R.drawable.red_progress));
                }
                hpBars[player][slot].getProgressDrawable().setBounds(bounds);
                // XXX the hp bars won't display properly unless I do this. Spent many hours trying
                // to figure out why
                int increment = (hpBars[player][slot].getProgress() == 100) ? -1 : 1;
                hpBars[player][slot].incrementProgressBy(increment);
                hpBars[player][slot].incrementProgressBy(-1 * increment);
            });
        }

        public void setHpBarToGoal() {
            runOnUiThread(() -> {
                hpBars[player][slot].setProgress(goal);
                hpBars[player][slot].setText(hpBars[player][slot].getProgress() + "%");
                checkHpColor();
            });
        }
    }

    public class MyAdapter extends PagerAdapter {
        @Override
        public int getCount() {
            return isSpectating() ? 1 : 2;
        }

        @NonNull
        @Override
        public Object instantiateItem(@NonNull ViewGroup container, int position) {
            switch (position) {
                case 0:
                    container.addView(mainLayout);
                    return mainLayout;
                case 1:
                    container.addView(teamLayout);
                    return teamLayout;
                default:
                    return null;
            }
        }

        @Override
        public void destroyItem(ViewGroup container, int position, @NonNull Object object) {
            container.removeView((View) object);
        }

        @Override
        public boolean isViewFromObject(@NonNull View arg0, @NonNull Object arg1) {
            return arg0 == arg1;
        }
    }

    private static class BattleExceptionHandler implements Thread.UncaughtExceptionHandler {
        final BattleActivity mActivity;
        private final Thread.UncaughtExceptionHandler defaultHandler;

        public BattleExceptionHandler(BattleActivity mActivity) {
            this.mActivity = mActivity;
            defaultHandler = Thread.getDefaultUncaughtExceptionHandler();
        }

        @Override
        public void uncaughtException(@NonNull Thread thread, @NonNull Throwable ex) {
            boolean isSpectating = mActivity.isSpectating();

            BattlePacket packet;
            if (isSpectating) {
                packet = mActivity.activeBattle.lastPacket;
            } else {
                packet = mActivity.battle.lastPacket;
            }
            boolean validPacket = (packet != null);

            if (validPacket) {
                new Thread() {
                    @Override
                    public void run() {
                        Looper.prepare();
                        Toast.makeText(mActivity, ex.getClass().getName() + "\n" + packet.toCompactString() + "\n" + packet.toString(), Toast.LENGTH_LONG).show();
                        Looper.loop();
                    }
                }.start();

                try {
                    Thread.sleep(10000);
                } catch (InterruptedException dontcare) {
                    // don't care
                }
            }

            defaultHandler.uncaughtException(thread, ex);
        }
    }
}
