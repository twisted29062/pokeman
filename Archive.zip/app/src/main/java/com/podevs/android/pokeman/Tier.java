package com.podevs.android.pokeman;

import android.annotation.TargetApi;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Build;
import android.widget.ArrayAdapter;

import androidx.annotation.NonNull;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

public class Tier {
    public byte            level      = 0;
    public String          name       = "null";
    public ArrayList<Tier> subTiers;
    public Tier            parentTier = null;

    public Tier(byte level, String name) {
        this.level = level;
        this.name = name;
        subTiers = new ArrayList<>();
    }

    public Tier() {
        subTiers = new ArrayList<>();
    }

    @NonNull @Override public String toString() {
        return name + (subTiers.size() > 0 ? "..." : "");
    }

    public void addSubTier(Tier t) {
        subTiers.add(t);
    }

    public void reset() {
        subTiers = new ArrayList<>();
    }

    public ArrayAdapter<Tier> getArrayAdapter(Context c, int textViewResId) {
        return new ArrayAdapter<>(c, textViewResId, subTiers);
    }

    @TargetApi(Build.VERSION_CODES.HONEYCOMB)
    public void save(Context ctx) {
        SharedPreferences prefs = ctx.getSharedPreferences("tiers", Context.MODE_PRIVATE);

        prefs.edit().putStringSet("list", getTierSet()).apply();
    }

    private Set<String> getTierSet() {
        Set<String> ret = new HashSet<>();

        getTierSet(ret);

        return ret;
    }

    private void getTierSet(Set<String> ret) {
        if (subTiers.size() > 0) {
            for (Tier t : subTiers) {
                t.getTierSet(ret);
            }
        } else {
            ret.add(name);
        }
    }
}
