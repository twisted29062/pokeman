package com.podevs.android.pokeman.pokeinfo;

import com.podevs.android.pokeman.R;

public class StatsInfo {
    static private final String[] SHORTCUTS = {
            "HP",
            "Att",
            "Def",
            "SpA",
            "SpD",
            "Spe"
    };
    static private final int[] RES_SHORTCUTS = {
            R.string.stat_hp_short,
            R.string.stat_attack_short,
            R.string.stat_defense_short,
            R.string.stat_spAttack_short,
            R.string.stat_spDefense_short,
            R.string.stat_speed_short
    };

    static public String shortcut(int pos) {
        return SHORTCUTS[pos];
    }

    static public int shortcutRes(int pos) {
        return RES_SHORTCUTS[pos];
    }

    public enum Stats {
        /*HP*/
        Hp, //0
        /*物攻*/
        Attack, //1
        /*物防*/
        Defense, //2
        /*特攻*/
        SpAttack, //3
        /*特防*/
        SpDefense, //4
        /*速度*/
        Speed //5
    }
}
