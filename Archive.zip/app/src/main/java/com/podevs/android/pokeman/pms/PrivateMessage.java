package com.podevs.android.pokeman.pms;

import android.widget.ListView;

import com.podevs.android.pokeman.player.PlayerInfo;
import com.podevs.android.utilities.PokeStrings;

import java.util.LinkedList;

/**
 * Data containing the information of a private message
 */
public class PrivateMessage {
    protected ListView privateList = null;
    PrivateMessageListener listener;
    final LinkedList<Message>    messages = new LinkedList<>();
    final PlayerInfo             me;
    PlayerInfo other;

    public PrivateMessage(PlayerInfo other, PlayerInfo me) {
        this.other = other;
        this.me = me;
    }

    public void addMessage(PlayerInfo info, String message, Boolean timeStamp) {
        if (info.id == this.id() && !"???".equals(info.nick())) {
            this.other = info;
        }

        if (!message.trim().isEmpty()) {
            if (timeStamp) {
                message = "(" + PokeStrings.timeStamp() + ") " + message;
            }

            if (!messages.isEmpty()) {
                Message lastMessage = messages.getLast();
                if (lastMessage != null && lastMessage.sender == info) {
                    lastMessage.append(message);
                } else {
                    messages.add(new Message(info, message));
                }
            } else {
                messages.add(new Message(info, message));
            }

            if (listener != null) {
                listener.onNewMessage(messages.getLast());
            }
        }
    }

    private int id() {
        return other.id;
    }

    @Override
    public int hashCode() {
        return id();
    }

    interface PrivateMessageListener {
        void onNewMessage(Message message);
    }

    public static class Message {
        final PlayerInfo sender;
        String     message;

        public Message(PlayerInfo info, String message) {
            this.sender = info;
            this.message = message;
        }

        void append(String s) {
            message = message + "\n" + s;
        }
    }
}