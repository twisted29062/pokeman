package com.podevs.android.pokeman.teambuilder;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.podevs.android.pokeman.R;
import com.podevs.android.pokeman.poke.Gen;
import com.podevs.android.pokeman.poke.UniqueID;
import com.podevs.android.pokeman.pokeinfo.PokemonInfo;
import com.podevs.android.pokeman.pokeinfo.TypeInfo;

public class FormListAdapter extends ArrayAdapter<UniqueID> {
    final static String pkgName = "com.podevs.android.poAndroid";
    final LayoutInflater inflater;
    private final Gen gen;


    public FormListAdapter(Activity spinner, int id, Gen gen) {
        super(spinner, id);

        this.gen = gen;

        inflater = (LayoutInflater) spinner.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public void clear() {
        super.clear();
    }

    @NonNull
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        return getCustomView(position, convertView, parent);
    }

    @Override
    public View getDropDownView(int position, View convertView, ViewGroup parent) {
        return getCustomView(position, convertView, parent);
    }

    public View getCustomView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = inflater.inflate(R.layout.forminlist_item, parent, false);
        }

        UniqueID uID = getItem(position);

        ((TextView) convertView.findViewById(R.id.poke_name)).setText(PokemonInfo.name(uID));
        ((ImageView) convertView.findViewById(R.id.type1)).setImageResource(TypeInfo.typeRes(PokemonInfo.type1(uID, gen.num)));

        int       type2  = PokemonInfo.type2(uID, gen.num);
        ImageView itype2 = convertView.findViewById(R.id.type2);

        itype2.setImageResource(TypeInfo.typeRes(type2));
        itype2.setVisibility(type2 == TypeInfo.Type.Curse.ordinal() ? View.INVISIBLE : View.VISIBLE);

        return convertView;
    }
}