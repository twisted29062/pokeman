package com.podevs.android.pokeman.pokeinfo;

import android.content.Context;
import android.text.TextUtils;

import com.aggrx.scaffold.AggrxFiles;
import com.aggrx.scaffold.AggrxNumbers;
import com.jx.scaffold.JxFileUtils;
import com.podevs.android.pokeman.poke.UniqueID;

import java.util.ArrayList;
import java.util.List;

/**
 * @author wangchao9
 */
public class InfoFiller {
    static void fill(String file, Filler filler) {
        JxFileUtils.assertStream(getContext(), file, stream -> {
            List<String> lines = AggrxFiles.readUtf8Lines(stream, new ArrayList<>());
            for (String str : lines) {
                if (TextUtils.isEmpty(str)) {
                    continue;
                }
                if ((int) str.charAt(0) == 0xFEFF) {
                    str = str.substring(1);
                }
                if (TextUtils.isEmpty(str)) {
                    continue;
                }

                int spaceIndex = str.indexOf(' ');
                if (spaceIndex < 0) {
                    continue;
                }

                String substring = str.substring(0, spaceIndex);
                String substring1 = str.substring(spaceIndex + 1);
                filler.fill(AggrxNumbers.parseInt(substring, 0), substring1, substring);
            }
        }, null);

//        InputStream assetsDB;
//        try {
//            assetsDB = getContext().getAssets().open(file);
//        } catch (IOException e) {
//            e.printStackTrace();
//            return;
//        }
//
//        BufferedReader buf = null;
//        try {
//            buf = new BufferedReader(new InputStreamReader(assetsDB, "UTF-8"));
//        } catch (UnsupportedEncodingException e2) {
//            e2.printStackTrace();
//        }
//
//        try {
//            while (buf.ready()) {
//                String str = buf.readLine();
//                /*
//                 * Test for BOM
//                 */
//                if (str == null) {
//                    break;
//                }
//                if (str.length() > 0 && (int) str.charAt(0) == 0xFEFF) {
//                    str = str.substring(1);
//                }
//
//                int spaceIndex = str.indexOf(' ');
//
//                if (spaceIndex < 0) {
//                    break;
//                }
//
//                String substring = str.substring(0, spaceIndex);
//                String substring1 = str.substring(spaceIndex + 1);
//                filler.fill(AggrxNumbers.parseInt(substring, 0), substring1, substring);
//            }
//        } catch (IOException e1) {
//            e1.printStackTrace();
//        }
//
//        try {
//            assetsDB.close();
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
    }

    private static Context getContext() {
        return InfoConfig.context;
    }

    static void plainFill(String file, Filler filler) {
        JxFileUtils.assertStream(getContext(), file, stream -> {
            List<String> lines = AggrxFiles.readUtf8Lines(stream, new ArrayList<>());
            for (String str : lines) {
                if (TextUtils.isEmpty(str)) {
                    continue;
                }
                if ((int) str.charAt(0) == 0xFEFF) {
                    str = str.substring(1);
                }
                if (TextUtils.isEmpty(str)) {
                    continue;
                }
                filler.fill(AggrxNumbers.parseInt(str, 0), null, str);
            }
        }, null);

//        InputStream assetsDB = null;
//        try {
//            assetsDB = getContext().getAssets().open(file);
//        } catch (IOException e) {
//            e.printStackTrace();
//            return;
//        }
//
//        BufferedReader buf = null;
//        try {
//            buf = new BufferedReader(new InputStreamReader(assetsDB, "UTF-8"));
//        } catch (UnsupportedEncodingException e2) {
//            e2.printStackTrace();
//        }
//
//        try {
//            while (buf.ready()) {
//                String str = buf.readLine();
//                /*
//                 * Test for BOM
//                 */
//                if (str == null) {
//                    break;
//                }
//                if (str.length() > 0 && (int) str.charAt(0) == 0xFEFF) {
//                    str = str.substring(1);
//                }
//
//                filler.fill(AggrxNumbers.parseInt(str, 0), null, str);
//            }
//        } catch (IOException e1) {
//            e1.printStackTrace();
//        }
//
//        try {
//            assetsDB.close();
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
    }

    static void uID_fill(String file, OptionsFiller filler) {
        JxFileUtils.assertStream(getContext(), file, stream -> {
            List<String> lines = AggrxFiles.readUtf8Lines(stream, new ArrayList<>());
            for (String str : lines) {
                if (TextUtils.isEmpty(str)) {
                    continue;
                }
                if ((int) str.charAt(0) == 0xFEFF) {
                    str = str.substring(1);
                }
                if (TextUtils.isEmpty(str)) {
                    continue;
                }

                int spaceIndex = str.indexOf(' ');

                if (spaceIndex < 0) {
                    continue;
                }

                int index1 = str.indexOf(':');
                int index2 = str.lastIndexOf(':', spaceIndex);

                String substring1 = str.substring(spaceIndex + 1);
                if (index2 == index1) {
                    String substring = str.substring(0, spaceIndex);
                    filler.fill(new UniqueID(substring).hashCode(), substring1, null, substring);
                } else {
                    String substring = str.substring(0, index2);
                    String substring2 = str.substring(index2 + 1, spaceIndex);
                    filler.fill(new UniqueID(substring).hashCode(), substring1, substring2, substring);
                }
            }
        }, null);

//        InputStream assetsDB = null;
//        try {
//            assetsDB = getContext().getAssets().open(file);
//        } catch (IOException e) {
//            e.printStackTrace();
//            return;
//        }
//
//        BufferedReader buf = null;
//        try {
//            buf = new BufferedReader(new InputStreamReader(assetsDB, "UTF-8"));
//        } catch (UnsupportedEncodingException e2) {
//            e2.printStackTrace();
//        }
//
//        try {
//            while (buf.ready()) {
//                String str = buf.readLine();
//                /*
//                 * Test for BOM
//                 */
//                if (str == null) {
//                    break;
////                    throw new IllegalArgumentException("On file " + file);
//                }
//
//                if (str.length() > 0 && (int) str.charAt(0) == 0xFEFF) {
//                    str = str.substring(1);
//                }
//
//                int spaceIndex = str.indexOf(' ');
//
//                if (spaceIndex < 0) {
//                    break;
//                }
//
//                int index1 = str.indexOf(':');
//                int index2 = str.lastIndexOf(':', spaceIndex);
//
//                String substring1 = str.substring(spaceIndex + 1);
//                if (index2 == index1) {
//                    String substring = str.substring(0, spaceIndex);
//                    filler.fill(new UniqueID(substring).hashCode(),
//                            substring1, null, substring);
//                } else {
//                    String substring = str.substring(0, index2);
//                    String substring2 = str.substring(index2 + 1, spaceIndex);
//                    filler.fill(new UniqueID(substring).hashCode(),
//                            substring1, substring2, substring);
//                }
//            }
//        } catch (IOException e1) {
//            e1.printStackTrace();
//        }
//
//        try {
//            assetsDB.close();
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
    }

    static void uID_fill(String file, UidFiller filler) {
        uID_fill(file, filler, false);
    }

    static void uID_fill(String file, UidFiller filler, boolean readAll) {
        JxFileUtils.assertStream(getContext(), file, stream -> {
            List<String> lines = AggrxFiles.readUtf8Lines(stream, new ArrayList<>());
            // int no = 0;
            // int size = lines.size();
            for (String str : lines) {
                // JxLogger.w("process %d/%d %s", no++, size, file);

                try {
                    if (TextUtils.isEmpty(str)) {
                        continue;
                    }
                    if ((int) str.charAt(0) == 0xFEFF) {
                        str = str.substring(1);
                    }
                    if (TextUtils.isEmpty(str)) {
                        continue;
                    }

                    if (str.length() > 0 && (int) str.charAt(0) == 0xFEFF) {
                        str = str.substring(1);
                    }

                    int spaceIndex = str.indexOf(' ');
                    if (spaceIndex < 0) {
                        if (!readAll) {
                            break;
                        } else {
                            filler.fill(new UniqueID(str), "", str);
                            continue;
                        }
                    }

                    String left = str.substring(0, spaceIndex);
                    String right = str.substring(spaceIndex + 1);
                    filler.fill(new UniqueID(left), right, left);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }, null);

//        InputStream assetsDB = null;
//        try {
//            assetsDB = getContext().getAssets().open(file);
//        } catch (IOException e) {
//            e.printStackTrace();
//            return;
//        }
//
//        BufferedReader buf = null;
//        try {
//            buf = new BufferedReader(new InputStreamReader(assetsDB, "UTF-8"));
//        } catch (UnsupportedEncodingException e2) {
//            e2.printStackTrace();
//        }
//
//        try {
//            while (buf.ready()) {
//                String str = buf.readLine();
//                /*
//                 * Test for BOM
//                 */
//                if (str == null) {
//                    break;
//                }
//                if (str.length() > 0 && (int) str.charAt(0) == 0xFEFF) {
//                    str = str.substring(1);
//                }
//
//                int spaceIndex = str.indexOf(' ');
//
//                if (spaceIndex < 0) {
//                    if (!readAll) {
//                        break;
//                    } else {
//                        filler.fill(new UniqueID(str).hashCode(), "", str);
//                        continue;
//                    }
//                }
//
//                String substring = str.substring(0, spaceIndex);
//                String substring1 = str.substring(spaceIndex + 1);
//                filler.fill(new UniqueID(substring).hashCode(), substring1, substring);
//            }
//        } catch (IOException e1) {
//            e1.printStackTrace();
//        }
//
//        try {
//            assetsDB.close();
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
    }

    public interface Filler {
        void fill(int i, String s, String origin);
    }

    public interface UidFiller {
        void fill(UniqueID i, String s, String origin);
    }

    public interface OptionsFiller {
        void fill(int i, String s, String options, String origin);
    }

    public static abstract class UidFillerByte implements UidFiller {
        @Override
        public void fill(UniqueID i, String s, String origin) {
            fillByte(i, (byte) AggrxNumbers.parseInt(s, 0), origin);
        }

        abstract void fillByte(UniqueID i, byte b, String origin);
    }

    public static abstract class FillerByte implements Filler {
        @Override
        public void fill(int i, String s, String origin) {
            fillByte(i, (byte) AggrxNumbers.parseInt(s, 0), origin);
        }

        abstract void fillByte(int i, byte b, String origin);
    }

    public static abstract class FillerInt implements Filler {
        @Override
        public void fill(int i, String s, String origin) {
            fillInt(i, AggrxNumbers.parseInt(s, 0));
        }

        abstract void fillInt(int i, int b);
    }
}
