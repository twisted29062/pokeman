package com.podevs.android.pokeman.battle;

import com.podevs.android.pokeman.poke.Gen;
import com.podevs.android.utilities.Bais;
import com.podevs.android.utilities.Baos;
import com.podevs.android.utilities.SerializeBytes;

public class BattleTeam implements SerializeBytes {
    public final BattlePoke[] pokes = new BattlePoke[6];
    // String nick = "";
    // String info = "";
    Gen gen = new Gen();
    // int[] indexes = new int[6];

    public BattleTeam(Bais msg, Gen gen) {
        for (int i = 0; i < 6; i++) {
            pokes[i] = new BattlePoke(msg, gen);
            pokes[i].teamNum = (byte) i;
        }
    }

    @Override public void serializeBytes(Baos b) {
        for (int i = 0; i < 6; i++) {
            b.putBaos(pokes[i]);
        }
    }
}
