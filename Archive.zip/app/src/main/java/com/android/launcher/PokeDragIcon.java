package com.android.launcher;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.view.animation.TranslateAnimation;

import androidx.appcompat.widget.AppCompatImageView;

import com.podevs.android.pokeman.battle.BattleActivity;
import com.podevs.android.pokeman.battle.BattlePoke;

/**
 * @author blox
 */
public class PokeDragIcon extends AppCompatImageView implements DragSource, DropTarget {
    public final int[]          otherIconDim = new int[4];
    public BattleActivity battleActivity;
    public int            num;
    boolean isTarget = false;

    public PokeDragIcon(Context context) {
        super(context);
    }

    public PokeDragIcon(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public PokeDragIcon(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
    }

    @Override public void onDropCompleted(View target, boolean success) {
        // TODO Auto-generated method stub
        if (success) {

            TranslateAnimation otherTa = new TranslateAnimation(0f, getLeft() - target.getLeft(), -1 * (target.getHeight() + 10), 0f);
            otherTa.setDuration(200);
            target.startAnimation(otherTa);

            PokeDragIcon otherIcon = (PokeDragIcon) target;
            otherIcon.otherIconDim[0] = this.getLeft();
            otherIcon.otherIconDim[1] = this.getTop();
            otherIcon.otherIconDim[2] = this.getRight();
            otherIcon.otherIconDim[3] = this.getBottom();
            otherIcon.isTarget = true;

            BattlePoke temp = battleActivity.activeBattle.myTeam.pokes[num];
            battleActivity.activeBattle.myTeam.pokes[num] = battleActivity.activeBattle.myTeam.pokes[otherIcon.num];
            battleActivity.activeBattle.myTeam.pokes[otherIcon.num] = temp;

            int tempNum = num;
            num = otherIcon.num;
            otherIcon.num = tempNum;

            this.layout(target.getLeft(), target.getTop(), target.getRight(), target.getBottom());
        }
    }

    @Override public void onDrop(DragSource source, int x, int y, int xOffset,
                                 int yOffset, Object dragInfo) {
        // TODO Auto-generated method stub

    }

    @Override public void onDragEnter(DragSource source, int x, int y, int xOffset,
                                      int yOffset, Object dragInfo) {
        TranslateAnimation ta = new TranslateAnimation(0f, 0f, 0f, -1 * (getHeight() + 10));
        ta.setDuration(100);
        ta.setFillAfter(true);
        startAnimation(ta);

    }

    @Override public void onDragOver(DragSource source, int x, int y, int xOffset,
                                     int yOffset, Object dragInfo) {
        // TODO Auto-generated method stub

    }

    @Override public void onDragExit(DragSource source, int x, int y, int xOffset,
                                     int yOffset, Object dragInfo) {
        TranslateAnimation ta = new TranslateAnimation(0f, 0f, -1 * (getHeight() + 10), 0f);
        ta.setDuration(100);
        startAnimation(ta);
    }

    @Override public boolean acceptDrop(DragSource source, int x, int y, int xOffset,
                                        int yOffset, Object dragInfo) {
        //Accept all things by default
        return true;
    }

    @Override
    protected void onAnimationEnd() {
        super.onAnimationEnd();
        if (isTarget) {
            this.layout(otherIconDim[0], otherIconDim[1], otherIconDim[2], otherIconDim[3]);
            isTarget = false;
        }
    }
}
